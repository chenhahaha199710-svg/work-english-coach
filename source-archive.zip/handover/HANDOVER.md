# Work English Coach V2 — 完整交接包

**当前线上版本**：`https://moma.ke.com/gw/ob-preview/ob/api/share/display/543ebaacd67144f0b3b150f3f27c3047`
**分发日期**：2026-10-10
**单文件 dist 大小**：528KB（精确 527854 bytes）
**单文件 dist MD5**：`514d3eb8a4a0af2b0917d451fca6cca0`
**S3 路径**：`https://file.ljcdn.com/codelink-web/ob/1789719882840-555a2553-3d57-4420-94ea-f694eb27a0c2.html`

---

## 一、目录结构

```
handover/
├── HANDOVER.md                          ← 本文件
├── V2-UPGRADE-REPORT.md                 ← V2 升级报告（含 18 项验收 / 已知限制）
├── src/                                 ← 模块化源码（构建前的可编辑版本）
│   ├── index.html                       ← HTML 模板（含启动保险 / 降级 / 8秒超时）
│   ├── styles.css                       ← V2 视觉系统（24KB）
│   └── js/
│       ├── db.js                        ← IndexedDB + 内存降级（15KB）
│       ├── store.js                     ← 状态管理（3KB）
│       ├── algorithm.js                 ← 调度 / 复习算法（10KB）
│       ├── lessons-data.js              ← 28 天课程 + 50 条基础知识条目（69KB）
│       ├── corpus-v2.js                 ← 70 条 V2 知识条目（108KB）
│       ├── vocab-data.js                ← 203 个 28 天词汇（148KB）
│       ├── ai-adapter.js                ← 本地 AI 适配器 + AIServiceInterface 预留（10KB）
│       ├── app.js                       ← 启动 / 路由 / Today / 听力（57KB）
│       ├── pages.js                     ← Error Bank / Progress / 等（34KB）
│       ├── pages2.js                    ← Review / Practice / More（31KB）
│       └── vocab.js                     ← 词汇预检 / 学习 / 测验 / 错题（46KB）
└── build/
    ├── build.py                         ← 构建脚本（1.7KB）
    └── dist-index-v528KB-md5-514d3eb8.html  ← 当前线上的同 MD5 校验产物
```

---

## 二、源代码与构建

### 1. 全部模块化源码在 `src/`

每个 JS 文件都是独立可编辑的模块，没有内联打包。`index.html` 通过 `<script src="js/...">` 依次加载；`styles.css` 通过 `<link>` 引入。`build.py` 会把所有 CSS / JS 合并到 `dist/index.html` 单文件中。

**注意**：`build.py` 中维护了一个白名单 `js_files` 列表和一个对应的 `old_scripts` 字符串。任何新增/重命名 JS 文件都需要同步修改这两处。

### 2. 构建命令

```bash
cd src
python3 build.py
# 产物：src/dist/index.html
```

要求：
- Python 3.x（无第三方依赖，标准库 `os` 即可）
- 源码目录与 `build.py` 同级
- 输出目录 `dist/` 自动创建

### 3. 版本对应关系

| 项目 | 状态 |
|------|------|
| 当前 src/ 重现 dist | ✅ MD5 完全一致 |
| `dist-index-v528KB-md5-514d3eb8.html` MD5 | `514d3eb8a4a0af2b0917d451fca6cca0` |
| 重新构建的 `src/dist/index.html` MD5 | `514d3eb8a4a0af2b0917d451fca6cca0` |
| 与线上 S3 文件关系 | S3 文件是同一 `dist/index.html` 的副本 |
| `work-english-coach-backup-v1/` | 旧 V1 备份，**不要使用**作为 V2 来源 |

**版本回溯方式**：
- 当前 dist 文件已备份到 `build/dist-index-v528KB-md5-514d3eb8.html`
- 当前 src/ 可复现相同 MD5
- V1 源码在 `work-english-coach-backup-v1/`，仅作存档，请勿混入 V2 部署

---

## 三、内容与数据

### 4. 全部数据在 src/ 下的可编辑 JS 源文件

| 数据 | 文件 | 数量 | 位置 |
|------|------|------|------|
| 28 天课程定义 | `js/lessons-data.js` | 28 天 | `const DAILY_LESSONS = [...]`（行 569） |
| 基础知识条目 | `js/lessons-data.js` | 50 条 | `const KNOWLEDGE_ITEMS = [...]`（行 42） |
| V2 知识条目 | `js/corpus-v2.js` | 70 条 | `const V2_KNOWLEDGE_ITEMS = [...]`（行 7） |
| 全部知识条目 | 运行时合并 | **120 条** | 运行时：`KNOWLEDGE_ITEMS.push(...V2_KNOWLEDGE_ITEMS)` |
| 词汇 | `js/vocab-data.js` | 203 个 | `const VOCAB_ITEMS = [...]`（行 7） |
| 对话场景 | `js/lessons-data.js` | 13 个 | `const SCENARIOS = [...]` + `const CONVERSATION_SCENARIOS = [...]` |

**数据格式**：

- 课程（DAILY_LESSONS）：`{ day, theme, theme_en, listening, itemIds, patternIds, workPractice, challenge, ... }`
- 知识条目（KNOWLEDGE_ITEMS / V2_KNOWLEDGE_ITEMS）：`{ id, type, english, chinese, example_sentence, natural_alternatives, common_mistakes, usage_note, work_context, scenario_id, difficulty, work_relevance, frequency, reusability, communication_value, skill_key, formality, replaceable_variables, source_file, source_scenario, privacy_check_status }`
- 词汇（VOCAB_ITEMS）：`{ id, word, lemma, pos, chinese, work_meaning, example_en, example_cn, collocations, confusable:[{word,diff}], work_context, related_expression, acceptable_answers, work_relevance, difficulty, day, scenario_id }`

**编辑方式**：直接修改 JS 源文件，重新跑 `build.py` 即可。所有数据数组都是顶层 const，可整体替换为 JSON 后用 fetch 注入（V3 可考虑此架构）。

### 5. 数据库说明

**库名**：`WorkEnglishCoachDB`
**当前版本**：`DB_VERSION = 2`
**位置**：`src/js/db.js` 第 6 行

**11 个 store 字段结构**：

| Store | KeyPath | 用途 | 关键字段 |
|-------|---------|------|---------|
| `knowledgeItems` | `id` | 知识库条目 | 完整 `KNOWLEDGE_ITEMS` 对象 |
| `learningAttempts` | `id` (autoinc) | 学习尝试记录 | `{ item_id, type, started_at, completed_at, user_input, correct, score }` |
| `masteryRecords` | `item_id` | 四级掌握度 | `{ item_id, recognition, recall, usage, transfer, last_updated, state }` |
| `reviewSchedule` | `item_id` | 复习排程 | `{ item_id, next_review_at, interval, ease_factor, streak }` |
| `errorBank` | `id` (autoinc) | 错题库 | `{ id, vocab_id, word, error_type, quiz_type, question, user_answer, user_selected_option, correct_answer, acceptable_answers, explanation, error_tag, work_context, hint_used, answer_revealed, occurrence_count, first_seen_at, last_seen_at, next_review_at, resolved, resolve_streak, learning_item_id, created_at, updated_at }` |
| `dailySessions` | `day` | 每日学习记录 | `{ day, started_at, completed_at, step_results, total_score }` |
| `imports` | `id` (autoinc) | 导入的对话 | `{ id, text, analyzed_at, analysis_result, scenario_id }` |
| `quizAttempts` | `id` (autoinc) | 测验记录 | `{ id, item_id, quiz_type, user_answer, correct, score, timestamp }` |
| `conversationSessions` | `id` (autoinc) | 对话练习 | `{ id, scenario_id, rounds, messages, final_score, completed_at }` |
| `skillScores` | `skill_key` | 能力评分 | `{ skill_key, score, level, last_updated }` |
| `assessments` | `id` (autoinc) | 入门/阶段测评 | `{ id, type, day, answers, score, completed_at }` |

**版本迁移逻辑**（`db.js` 第 92-180 行）：
- `indexedDB.open(DB_NAME, DB_VERSION)` 触发 `onupgradeneeded`
- 当前代码为每个 store 单独判断 `objectStoreNames.contains`，缺则创建
- **V1 → V2 升级**：V2 仅在 V1 基础上新增了 `assessments` store；V1 数据完全保留
- **V2 → 未来 V3**：如果新增 store 只需要在 `STORES` 字典添加并在 `onupgradeneeded` 加 `if (!contains)` 块；不要修改已有 store 的 keyPath，否则需写迁移函数
- **JSON 导入兼容**：`db.js` 的 `exportAllData` / `importAllData` 通过 `_meta.version` 字段标识 schema；导入时新字段缺失会用默认值
- **跨设备迁移**：用户可在 More → 备份/恢复 导出 JSON 备份

### 6. AI 接口层说明

**位置**：`src/js/ai-adapter.js`

#### 6.1 当前实现：`LocalAIAdapter`（基于规则 + 模板）

| 方法 | 输入 | 输出 | 当前实现 |
|------|------|------|---------|
| `analyzeCorpus(text)` | 导入的英文文本字符串 | `{ scenarios, roles, business_objects, problems, causes, actions, metrics, questions, answers, learning_items, needs_confirmation, confidence }` | 关键词匹配（中文/英文双语关键词表）识别场景，提取英文句子作为学习候选，confidence 固定 0.4 |
| `generateDailySession(studyDay, settings, dueItems, newItemCount)` | 学习天数、用户设置、到期复习项、新词数 | `{ day, theme, theme_en, listening, review_items, learn_items, learn_patterns, work_practice, daily_challenge, estimated_minutes }` | 从 DAILY_LESSONS 取当天课程，结合 dueItems 截前 10 |
| `evaluateAnswer(userAnswer, referenceAnswer, opts)` | 用户回答、参考答案、`{ type }` | `{ communication_success, clarity_score, naturalness_score, work_fit_score, better_version, key_expressions, error_tags, feedback }` | 关键词命中率 + 句型匹配 + 长度启发式打分；满 100 分 |
| `generateFollowUp(scenarioId, userResponse, round, history)` | 场景ID、用户回答、当前轮、历史 | `{ next_question, follow_up_reason, task_complete }` 或 `{ task_complete: true, final_feedback }` | 按 `scenario.branches` 关键词匹配；round 超出场景配置时 `task_complete: true` |
| `getOpening(scenarioId)` | 场景ID | 第一个问题字符串 | 从 `scenario.branches` 取 `trigger='start'` 的问题 |
| `summarizeConversation(history)` | 对话历史 | （V1 暂未实现） | 需在 LocalAIAdapter 中补全 |

#### 6.2 预留接口：`AIServiceInterface`（第 194-201 行）

```js
const AIServiceInterface = {
  analyzeCorpus: null,            // (text) => Promise<analysisResult>
  generateDailySession: null,     // (opts) => Promise<session>
  evaluateAnswer: null,            // (answer, reference, opts) => Promise<evaluation>
  generateFollowUp: null,         // (scenarioId, response, round, history) => Promise<followUp>
  summarizeConversation: null     // (history) => Promise<summary>
};
```

#### 6.3 未来接入真 GPT 需要实现的内容

**最小实现**（在 `AIServiceInterface` 上挂接 `RemoteAIAdapter`）：

1. **后端代理**：避免 CORS 和 API Key 暴露。**绝不能**在前端代码、localStorage 或 IndexedDB 中保存 OpenAI API Key。**用户隐私要求已写明**。
2. **统一调用入口**：
   ```js
   const RemoteAIAdapter = {
     isLocal: false,
     async analyzeCorpus(text) { /* POST /api/ai/analyze-corpus */ },
     async generateDailySession(...) { /* POST /api/ai/daily-session */ },
     async evaluateAnswer(...) { /* POST /api/ai/evaluate */ },
     async generateFollowUp(...) { /* POST /api/ai/follow-up */ },
     async summarizeConversation(history) { /* POST /api/ai/summarize */ }
   };
   ```
3. **切换开关**：`const AIAdapter = RemoteAIAdapter;`（在 `ai-adapter.js` 第 204 行）
4. **完整转写发送限制**：根据用户原始要求，**不得将完整会议转写发送到第三方服务，除非用户另行授权**。`analyzeCorpus` 在 V1 仅发送脱敏后的关键词与句子片段；接入 GPT 时必须保持这一约束，必要时先在本地做 PII 替换。
5. **评分合规**：根据用户原始要求，**规则匹配不得描述为 AI 评分**。`evaluateAnswer` 当前输出 4 个 0-100 分数，UI 显示为"能力维度"；接入 GPT 后，文案仍应避免"AI 评分"措辞。
6. **Token 与速率**：所有方法需要超时（建议 8s）、重试（最多 1 次）、降级到 `LocalAIAdapter`。

**不要做的事**：
- 不要在前端直接调用 OpenAI
- 不要把 API Key 写入 `localStorage` / `IndexedDB`
- 不要把完整转写文本上送
- 不要把任何评分描述为"AI 评分"

---

## 四、部署信息

### 7. 线上版本部署方式

**当前部署链路**：

1. 本地 `build.py` 把 src/ 合并为 `dist/index.html`（单文件 528KB）
2. 通过 `moma` CLI 把 `dist/index.html` 上传到内网 S3：
   ```bash
   moma moma-deploy api POST_api_btg_file_upload \
     -F file=dist/index.html \
     --yes --json
   # 返回：{ s3Key, s3Url, originalFileName }
   ```
3. 通过 `moma` CLI 更新 share 链接指向新的 S3 文件：
   ```bash
   moma moma-deploy api POST_api_btg_share_update \
     -d '{"shareToken":"543ebaacd67144f0b3b150f3f27c3047","originalFileS3Url":"<s3Url>","fileName":"index.html"}' \
     --yes --json
   ```

**S3 信息**：
- **当前 s3Key**：`/codelink-web/ob/1789719882840-555a2553-3d57-4420-94ea-f694eb27a0c2.html`
- **当前 s3Url**：`https://file.ljcdn.com/codelink-web/ob/1789719882840-555a2553-3d57-4420-94ea-f694eb27a0c2.html`
- **shareToken**：`543ebaacd67144f0b3b150f3f27c3047`
- **access 模式**：免登直访（无需 token）

**以后如何更新同一个链接**：

✅ **可以更新，且保持链接不变**。流程是：
1. 修改 `src/` 下的源文件
2. `cd src && python3 build.py` 生成新 `dist/index.html`
3. `moma moma-deploy api POST_api_btg_file_upload -F file=dist/index.html --yes`（会得到新 s3Key）
4. `moma moma-deploy api POST_api_btg_share_update -d '{"shareToken":"543ebaacd67144f0b3b150f3f27c3047","originalFileS3Url":"<新s3Url>","fileName":"index.html"}' --yes`
5. 公开访问的 `moma.ke.com` 链接**保持不变**，但内容已更新

**注意**：
- `POST_api_btg_file_upload` 和 `POST_api_btg_share_update` 都是 high-risk-write API，需要 `--yes` 确认
- 推荐先 `--dry-run` 预览
- 更新是即时的，不需要重新生成 share token

### 8. 链接有效期与限制

| 项目 | 状态 |
|------|------|
| 链接是否永久有效 | **基于 moma.ke.com 平台的 share 政策**；share 一旦创建不会自动过期 |
| 是否需要登录 | 否（免登访问） |
| 访问白名单 | 未设置（理论上任何拿到链接的人可访问） |
| 流量 / 频次限制 | 平台默认有限制，具体限值未在 `moma` 文档中明确 |
| 文件大小限制 | 单次上传应受平台限制（当前 528KB 远未触及） |
| 离线可用性 | 取决于 `WorkEnglishCoachDB` 浏览器存储；首次访问需联网 |

**"永久有效"的依据**：share token `543ebaacd67144f0b3b150f3f27c3047` 通过 `POST_api_btg_share_create` 创建后没有设置过期时间，平台默认行为是不主动清理未更新的 share。但：
- 如果 90 天内完全无访问，部分内部平台会做冷存储
- 如果 moma.ke.com 平台下线，链接自然失效
- 如果数据/隐私合规要求变更，平台可能下架 share

**建议的长期维护措施**：
1. 每年 1-2 次访问验证 + 重新部署
2. 重大版本升级时通过 `POST_api_btg_share_update` 推新
3. 保留 build.py + 源码 + 当前 dist 备份

---

## 五、文档

### 9. V2-UPGRADE-REPORT.md

完整升级报告见同级目录 `V2-UPGRADE-REPORT.md`，包含：
- 18 项验收标准对照表
- 修改文件清单
- 数据迁移说明
- 端到端测试结果（词汇预检 → 答错解析 → Error Bank → 再次复习）
- 4 轮 AI Conversation 验证记录
- 视觉系统色值 / 字体 / 布局规范
- 已知限制清单

### 10. 已知问题与未完成项

#### 已完成（2026-10-10 收尾）
- ✅ IndexedDB 降级模式：5 秒 openDB 超时 + 8 秒 wec-boot-timeout + 内存 Map 兜底
- ✅ V2 词汇预检 + 6 种题型 + Error Bank 集成
- ✅ 听力页强制朗读 / 跟读 / 复述已移除（保留可选朗读按钮）
- ✅ AI Conversation 移动端输入栏不遮挡
- ✅ 视觉系统全部 V2 色值与 Georgia 衬线

#### 已知限制（不可消除）
1. **TTS 浏览器差异**：听力训练使用 Web Speech API；部分浏览器（Firefox）不支持时显示文字替代，不增加 Listening 掌握分
2. **STT 浏览器差异**：跟读 / 语音复述功能在 Safari / Firefox 上行为不一致；V2 已取消强制跟读，所以影响有限
3. **IndexedDB 在隐私模式下不可用**：降级模式生效，但刷新后内存数据丢失
4. **降级模式下进度不持久化**：用户需注意"当前进度可能无法保存"提示

#### 已知未完成项（待 V3）
1. **AI Conversation 真实接入 GPT**：`AIServiceInterface` 已预留，`RemoteAIAdapter` 待实现（见第 6.3 节）
2. **词汇 28 天之后的数据扩展**：当前 203 个词汇覆盖 28 天；第 29 天起需扩充 `vocab-data.js`
3. **更多对话场景**：当前 13 个场景，V1 主要覆盖汇报 / 工单 / 延迟；V3 可补充更多行业场景
4. **桌面端独立布局**：当前桌面端主内容保持 480px 阅读宽度，V3 可做更精细的桌面布局
5. **学习数据云同步**：当前仅本地 IndexedDB；如需多设备同步需要后端

#### 平台限制（不归本工程）
- 公开 URL 流量限制（moma.ke.com 平台默认）
- 单文件 528KB 在低端网络下首屏可能慢 1-2s
- 无 CDN 加速（moma.ke.com 内网环境）

---

## 六、交接清单

| 类别 | 项目 | 路径 | 状态 |
|------|------|------|------|
| 源码 | index.html | `src/index.html` | ✅ |
| 源码 | styles.css | `src/styles.css` | ✅ |
| 源码 | 11 个 JS 文件 | `src/js/*.js` | ✅ |
| 构建 | build.py | `build/build.py` | ✅ |
| 构建 | 当前 dist 备份 | `build/dist-index-v528KB-md5-514d3eb8.html` | ✅ |
| 数据 | 28 天课程 | `src/js/lessons-data.js` | ✅ |
| 数据 | 120 条知识库 | `src/js/lessons-data.js` + `src/js/corpus-v2.js` | ✅ |
| 数据 | 203 个词汇 | `src/js/vocab-data.js` | ✅ |
| 文档 | V2 升级报告 | `V2-UPGRADE-REPORT.md` | ✅ |
| 文档 | HANDOVER.md | `HANDOVER.md` | ✅ |

---

## 七、快速验证步骤

接手人验证包是否完整的标准步骤：

```bash
# 1. 验证源码可重现 dist
cd handover/src
python3 build.py
md5sum dist/index.html
# 期望：514d3eb8a4a0af2b0917d451fca6cca0

# 2. 验证 dist 与备份一致
md5sum ../build/dist-index-v528KB-md5-514d3eb8.html dist/index.html
# 期望：两个 MD5 完全相同

# 3. 验证线上版本（curl 头 + 关键内容）
curl -sI "https://file.ljcdn.com/codelink-web/ob/1789719882840-555a2553-3d57-4420-94ea-f694eb27a0c2.html" | head
# 期望：HTTP 200 + Content-Type: text/html
```

**以上三步全过即可确认交接包完整、与线上同步。**
