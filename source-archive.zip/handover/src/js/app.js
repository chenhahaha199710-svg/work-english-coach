// ===== Main App Logic =====

let appSettings = null;
let appState = null;
let currentSession = null;

// ===== 降级模式 UI 提示 =====
function _showFallbackBanner() {
  if (!isFallbackMode()) return;
  var existing = document.getElementById('wec-fallback-banner');
  if (existing) return;
  var reason = getFallbackReason() || 'unknown';
  var reasonText = '';
  if (reason.indexOf('blocked') >= 0) reasonText = '数据库被其他标签页占用';
  else if (reason.indexOf('no_indexeddb') >= 0) reasonText = '浏览器不支持 IndexedDB';
  else if (reason.indexOf('timeout') >= 0) reasonText = '数据库响应超时';
  else if (reason.indexOf('quota') >= 0) reasonText = '存储空间不足';
  else reasonText = '数据持久化不可用';

  var banner = document.createElement('div');
  banner.id = 'wec-fallback-banner';
  banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9999;background:#fff3cd;color:#856404;padding:8px 16px;font-size:13px;text-align:center;border-bottom:1px solid #ffeaa7;';
  banner.innerHTML = '⚠️ ' + reasonText + '，当前进度可能无法保存。' +
    '<button onclick="this.parentElement.style.display=\'none\';" style="margin-left:12px;background:none;border:none;color:#856404;font-weight:600;cursor:pointer;font-size:13px;">关闭</button>';
  document.body.appendChild(banner);
}

// ===== 初始化知识库数据 =====
async function _initKnowledgeData() {
  const itemCount = await dbCount(STORES.knowledgeItems);
  if (itemCount === 0) {
    for (const item of KNOWLEDGE_ITEMS) {
      item.status = 'active';
      item.created_at = new Date().toISOString();
      item.updated_at = new Date().toISOString();
      await dbPut(STORES.knowledgeItems, item);
      const mastery = WEC_Algo.initMastery(item.id);
      await dbPut(STORES.masteryRecords, mastery);
      await dbPut(STORES.reviewSchedule, {
        item_id: item.id,
        next_review_at: Date.now(),
        interval_days: 0,
        review_count: 0,
        mastery_state: 'New'
      });
    }
  } else if (itemCount < KNOWLEDGE_ITEMS.length) {
    const existingItems = await dbGetAll(STORES.knowledgeItems);
    const existingIds = new Set(existingItems.map(i => i.id));
    for (const item of KNOWLEDGE_ITEMS) {
      if (!existingIds.has(item.id)) {
        item.status = 'active';
        item.created_at = new Date().toISOString();
        item.updated_at = new Date().toISOString();
        await dbPut(STORES.knowledgeItems, item);
        const mastery = WEC_Algo.initMastery(item.id);
        await dbPut(STORES.masteryRecords, mastery);
        await dbPut(STORES.reviewSchedule, {
          item_id: item.id,
          next_review_at: Date.now(),
          interval_days: 0,
          review_count: 0,
          mastery_state: 'New'
        });
      }
    }
  }
}

// ===== 初始化能力分数 =====
async function _initSkillScores() {
  const skillCount = await dbCount(STORES.skillScores);
  if (skillCount === 0) {
    for (const skill of SKILL_DIMENSIONS) {
      await dbPut(STORES.skillScores, {
        skill_key: skill.key,
        name: skill.name,
        name_zh: skill.name_zh,
        score: 0,
        evidence_count: 0,
        updated_at: new Date().toISOString()
      });
    }
  } else {
    const existingSkills = await dbGetAll(STORES.skillScores);
    const existingKeys = new Set(existingSkills.map(s => s.skill_key));
    for (const skill of SKILL_DIMENSIONS) {
      if (!existingKeys.has(skill.key)) {
        await dbPut(STORES.skillScores, {
          skill_key: skill.key,
          name: skill.name,
          name_zh: skill.name_zh,
          score: 0,
          evidence_count: 0,
          updated_at: new Date().toISOString()
        });
      }
    }
  }
}

// ===== Init =====
async function initApp() {
  appSettings = loadSettings();
  if (!appSettings.studyStartDate) {
    appSettings.studyStartDate = todayStr();
    try { saveSettings(appSettings); } catch (e) { console.warn('saveSettings failed', e); }
  }
  appState = loadState();

  // 尝试正常初始化；DB 失败时 db.js 自动切换到降级模式
  try {
    await _initKnowledgeData();
    await _initSkillScores();
    router(appState.currentPage || 'today');
  } catch (err) {
    console.error('initApp error:', err);
    if (!isFallbackMode()) {
      enableFallbackMode('init_error:' + ((err && err.message) || 'unknown'));
    }
    // 降级模式下重新初始化内存数据
    try {
      await _initKnowledgeData();
      await _initSkillScores();
      router(appState.currentPage || 'today');
    } catch (err2) {
      console.error('initApp fallback also failed:', err2);
      _showFatalError(err2);
      return;
    }
  }

  // 无论成功还是降级，都标记完成
  if (window.__WEC_BOOT__) window.__WEC_BOOT__.finished = true;
  if (isFallbackMode()) {
    _showFallbackBanner();
  }
}

function _showFatalError(err) {
  var detail = (err && (err.message || err.toString())) || '未知错误';
  var diag = {};
  try { diag = getDBDiagnostics(); } catch(e) {}
  var app = document.getElementById('app');
  if (app) {
    app.innerHTML = '' +
      '<div style="padding: 32px 20px; max-width: 480px; margin: 0 auto; text-align: center;">' +
        '<div style="font-size: 48px; margin-bottom: 12px;">⚠️</div>' +
        '<h2 style="color: #1a2e28; margin-bottom: 12px;">应用启动失败</h2>' +
        '<p style="color: #5a6e68; font-size: 14px; line-height: 1.6; margin-bottom: 16px;">' +
          'IndexedDB 不可用且内存模式也失败了。请尝试刷新或清理浏览器数据后重试。' +
        '</p>' +
        '<details style="text-align:left; margin-bottom:24px; background:#f0f2f1; padding:12px; border-radius:8px; font-size:12px; color:#5a6e68;">' +
          '<summary style="cursor:pointer; font-weight:600;">诊断信息</summary>' +
          '<pre style="margin-top:8px; white-space:pre-wrap;">' +
            'error: ' + String(detail) + '\n' +
            'diag: ' + JSON.stringify(diag, null, 2) +
          '</pre>' +
        '</details>' +
        '<button id="wec-retry-btn2" style="background: #1a6b4e; color: white; border: none; padding: 12px 24px; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer; margin-right: 8px;">🔄 重试</button>' +
        '<button id="wec-clear-btn" style="background: transparent; color: #5a6e68; border: 1px solid #d4e0db; padding: 12px 24px; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer;">清理数据并重试</button>' +
      '</div>';
    var retryBtn = document.getElementById('wec-retry-btn2');
    if (retryBtn) retryBtn.addEventListener('click', function () { location.reload(); });
    var clearBtn = document.getElementById('wec-clear-btn');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      if (window.confirm('将清空 IndexedDB 与 localStorage 后重启。继续？')) {
        try { if (typeof indexedDB !== 'undefined' && indexedDB) indexedDB.deleteDatabase('WorkEnglishCoachDB'); } catch (e) {}
        try { localStorage.clear(); } catch (e) {}
        location.reload();
      }
    });
  }
  if (window.__WEC_BOOT__) {
    window.__WEC_BOOT__.failed = detail;
    window.__WEC_BOOT__.finished = true;
  }
}

// ===== Router =====
function router(page, params = {}) {
  appState.currentPage = page;
  appState.params = params;
  saveState(appState);

  // 更新底部导航
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === page);
  });

  const app = document.getElementById('app');
  switch(page) {
    case 'today': renderToday(app); break;
    case 'review': renderReview(app); break;
    case 'practice': renderProgress(app); break;
    case 'progress': renderProgress(app); break;
    case 'more': renderMore(app); break;
    case 'learn': renderLearn(app, params); break;
    case 'work-practice': renderWorkPractice(app, params); break;
    case 'daily-challenge': renderDailyChallenge(app, params); break;
    case 'quiz': renderQuiz(app); break;
    case 'conversation': renderConversation(app); break;
    case 'knowledge-base': renderKnowledgeBase(app); break;
    case 'error-bank': renderErrorBank(app); break;
    case 'settings': renderSettingsPage(app); break;
    case 'import': renderImportPage(app); break;
    case 'backup': renderBackupPage(app); break;
    case 'listening': renderListening(app, params); break;
    case 'session-summary': renderSessionSummary(app, params); break;
    case 'assessment': renderAssessment(app); break;
    case 'vocab-precheck': startVocabSession(getStudyDay(appSettings)); break;
    default: renderToday(app);
  }
  window.scrollTo(0, 0);
}

// ===== Navigation Helper =====
function navTo(page, params = {}) {
  router(page, params);
}

function showToast(msg) {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 2500);
}

function showModal(contentHTML) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `<div class="modal"><div class="modal-handle"></div>${contentHTML}</div>`;
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) overlay.remove();
  });
  document.body.appendChild(overlay);
  return overlay;
}

function closeModal(el) {
  if (el) el.remove();
  else document.querySelector('.modal-overlay')?.remove();
}

// ===== Icons (SVG) =====
const ICONS = {
  today: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="16" y1="2" x2="16" y2="6"/></svg>',
  review: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9"/><path d="M3 4v5h5"/></svg>',
  practice: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 1 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>',
  progress: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
  more: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/></svg>'
};

// ===== Today Page =====
async function renderToday(app) {
  const studyDay = getStudyDay(appSettings);
  const week = getWeek(studyDay);
  const phase = getWeekPhase(week);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];

  // 检查今天是否已完成
  const todayRecord = await dbGet(STORES.dailySessions, studyDay);
  const isCompleted = todayRecord && todayRecord.completed;

  // 获取到期复习数量
  const dueItems = await WEC_Algo.getDueReviewItems();
  const dueCount = dueItems.length;

  // 获取本周学习天数
  let weekStudyDays = 0;
  for (let d = (week-1)*7+1; d <= studyDay; d++) {
    const rec = await dbGet(STORES.dailySessions, d);
    if (rec && rec.completed) weekStudyDays++;
  }

  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0 8px;">
        <div class="flex items-center justify-between">
          <div>
            <div class="text-secondary text-sm">Today · Day ${studyDay}</div>
            <div class="text-light text-xs mt-sm">${phase.name} · ${phase.range}</div>
          </div>
          <div class="badge badge-primary">${week <= 12 ? '12周中期评估' : week <= 24 ? '24周最终评估' : ''}</div>
        </div>
      </div>

      <div style="text-align:center; padding: 20px 0;">
        <div style="font-size: 48px; font-weight: 700; color: var(--color-primary); font-family: Georgia, serif;">${studyDay}<span style="font-size:20px; color: var(--color-text-light);">/168</span></div>
        <div class="text-secondary text-sm mt-sm">连续学习 ${appSettings.streakDays || 0} 天</div>
      </div>

      <div class="card card-hero">
        <div class="text-secondary text-sm">今日主题</div>
        <h3 style="margin-top: 4px;">${lesson.theme}</h3>
        <div class="text-light text-xs mt-sm">${lesson.theme_en}</div>
        <div style="margin-top: 12px; display:flex; gap:8px; align-items:center; flex-wrap: wrap;">
          <span class="badge badge-mint">⏱ 25 分钟</span>
          <span class="badge ${dueCount > 0 ? 'badge-coral' : 'badge-mint'}">📝 ${dueCount > 0 ? dueCount + ' 个待复习' : '5 个预复习'}</span>
          <span class="badge badge-mint">🔤 今日词汇 15–18 个</span>
        </div>
      </div>

      <div class="card">
        <div class="flex justify-between items-center mb-md">
          <span class="text-secondary text-sm">本周进度</span>
          <span class="text-light text-xs">第 ${week} 周</span>
        </div>
        <div class="progress-bar"><div class="progress-bar-fill" style="width: ${Math.min(100, (studyDay % 7 === 0 ? 7 : studyDay % 7) / 7 * 100)}%"></div></div>
        <div class="text-light text-xs mt-sm">本周已学习 ${weekStudyDays} 天 · ${7 - (studyDay % 7 === 0 ? 7 : studyDay % 7)} 天后周测</div>
      </div>

      <div class="card card-clickable" onclick="startSession()">
        <div class="flex items-center justify-between">
          <div>
            <div style="font-weight: 600; font-size: 18px;">${isCompleted ? '复习今日内容' : '开始今日学习'}</div>
            <div class="text-secondary text-sm mt-sm">词汇预检 → 重点词汇 → 主动回忆 → 工作听力 → 工作表达 → 工作应用</div>
          </div>
          <div style="font-size: 24px; color: var(--color-primary);">→</div>
        </div>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">今日任务</div>
        <div class="list-item">
          <div class="list-item-icon" style="background: var(--color-mint);">🔤</div>
          <div class="list-item-content">
            <div class="list-item-title">词汇预检</div>
            <div class="list-item-subtitle">3 分钟 · 快速筛选认识的词</div>
          </div>
        </div>
        <div class="list-item">
          <div class="list-item-icon" style="background: var(--color-mint);">📚</div>
          <div class="list-item-content">
            <div class="list-item-title">重点词汇</div>
            <div class="list-item-subtitle">5–6 分钟 · 学习不确定和不认识的词</div>
          </div>
        </div>
        <div class="list-item">
          <div class="list-item-icon" style="background: var(--color-mint);">🔄</div>
          <div class="list-item-content">
            <div class="list-item-title">主动回忆</div>
            <div class="list-item-subtitle">4 分钟 · 做题巩固</div>
          </div>
        </div>
        <div class="list-item">
          <div class="list-item-icon" style="background: var(--color-blue-light);">🎧</div>
          <div class="list-item-content">
            <div class="list-item-title">工作听力</div>
            <div class="list-item-subtitle">3 分钟 · 听懂状态与时效</div>
          </div>
        </div>
        <div class="list-item">
          <div class="list-item-icon" style="background: var(--color-purple-light);">💬</div>
          <div class="list-item-content">
            <div class="list-item-title">工作表达</div>
            <div class="list-item-subtitle">4–5 分钟 · ${lesson.itemIds.length} 个 chunks · ${lesson.patternIds.length} 个句型</div>
          </div>
        </div>
        <div class="list-item">
          <div class="list-item-icon" style="background: var(--color-coral-light);">💼</div>
          <div class="list-item-content">
            <div class="list-item-title">工作应用 / 今日挑战</div>
            <div class="list-item-subtitle">${lesson.workPractice.context.slice(0, 30)}...</div>
          </div>
        </div>
      </div>

      <div class="card" style="background: var(--color-bg-subtle); border: 1px solid var(--color-border-light);">
        <div class="text-secondary text-sm">💡 AI 教练提醒</div>
        <div class="text-sm mt-sm" style="line-height: 1.6;">${isCompleted ? '今日已完成！明天继续保持。' : dueCount > 8 ? `今天有 ${dueCount} 个到期复习，建议先完成复习再学新内容。` : '今天内容不多，可以集中精力完成一次完整的学习闭环。'}</div>
      </div>
    </div>
  `;
}

// ===== Start Session =====
async function startSession() {
  const studyDay = getStudyDay(appSettings);
  currentSession = {
    day: studyDay,
    step: 0,
    steps: ['vocab-precheck', 'listening', 'review', 'learn', 'work-practice', 'daily-challenge', 'session-summary'],
    results: {}
  };
  startVocabSession(studyDay);
}

// ===== Listening Page (V2: keywords, comprehension, modes) =====
let listeningState = {
  mode: 'study',      // 'study' or 'test'
  phase: 'keywords', // 'keywords' -> 'listen1' -> 'questions' -> 'listen2' -> 'reveal'
  listenCount: 0,
  questionsAnswered: 0,
  questionsCorrect: 0,
  comprehensionResults: [],
  textRevealed: false
};

async function renderListening(app, params) {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const listening = lesson.listening;

  // 休息日跳过听力
  if (!listening.text) {
    app.innerHTML = `
      <div class="container page">
        ${renderSessionBar(0)}
        <div class="empty-state" style="padding: 60px 20px;">
          <div style="font-size: 48px;">😴</div>
          <h2 style="margin-top: 16px;">休息日</h2>
          <p class="text-secondary mt-sm">今天没有听力任务，休息一下吧。</p>
        </div>
        <button class="btn btn-primary btn-block btn-lg" onclick="nextSessionStep()">下一步 →</button>
      </div>
    `;
    return;
  }

  // 初始化听力状态
  listeningState = {
    mode: appSettings.listeningMode || 'study',
    phase: 'keywords',
    listenCount: 0,
    questionsAnswered: 0,
    questionsCorrect: 0,
    comprehensionResults: [],
    textRevealed: false
  };

  renderListeningPhase(app);
}

function renderListeningPhase(app) {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const listening = lesson.listening;
  const keywords = listening.keywords || [];
  const questions = listening.comprehension_questions || [];
  const sessionBar = currentSession ? renderSessionBar(0) : '';

  // 学习模式：显示关键词预习；测试模式：跳过关键词
  if (listeningState.phase === 'keywords') {
    if (listeningState.mode === 'test') {
      // 测试模式直接进入听力
      listeningState.phase = 'listen1';
      renderListeningPhase(app);
      return;
    }

    app.innerHTML = `
      <div class="container page">
        ${sessionBar}
        <div style="padding: 20px 0;">
          <div class="badge badge-mint mb-md">Step 1 of 5 · 听力热身</div>
          <h2>${listening.title || '听力热身'}</h2>
          <p class="text-secondary text-sm mt-sm">先预习关键词组，再听音频</p>
        </div>

        <div class="card">
          <div class="flex justify-between items-center mb-md">
            <span class="text-secondary text-sm">🔑 关键词组预习</span>
            <div class="flex gap-sm">
              <button class="btn btn-ghost btn-sm ${listeningState.mode === 'study' ? 'btn-active' : ''}" onclick="switchListeningMode('study')">学习模式</button>
              <button class="btn btn-ghost btn-sm ${listeningState.mode === 'test' ? 'btn-active' : ''}" onclick="switchListeningMode('test')">测试模式</button>
            </div>
          </div>
          <div class="keyword-list">
            ${keywords.map(kw => `
              <div class="keyword-item">
                <div class="keyword-english">${kw}</div>
                <button class="btn btn-ghost btn-sm" onclick="SpeechUtils.speak('${kw.replace(/'/g, "\\'")}', {rate: 0.9})">🔊</button>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="card" style="background: var(--color-bg-subtle);">
          <div class="text-secondary text-sm">📋 听力目标</div>
          <div class="text-sm mt-sm" style="line-height: 1.6;">
            1. 以0.8倍速听第一遍，不显示全文<br>
            2. 回答3个理解问题<br>
            3. 以正常速度听第二遍<br>
            4. 查看全文并高亮关键词
          </div>
        </div>

        <button class="btn btn-primary btn-block btn-lg mt-lg" onclick="startListeningPhase1()">开始听第一遍 →</button>
      </div>
    `;
    return;
  }

  // 第一遍听力（0.8倍速，不显示全文）
  if (listeningState.phase === 'listen1') {
    app.innerHTML = `
      <div class="container page">
        ${sessionBar}
        <div style="padding: 20px 0;">
          <div class="badge badge-mint mb-md">Step 1 of 5 · 第一遍听力</div>
          <h2>🎧 0.8倍速听力</h2>
          <p class="text-secondary text-sm mt-sm">先听一遍，不显示文本</p>
        </div>

        <div class="card listening-player">
          <div class="text-secondary text-sm mb-md">点击播放，以0.8倍速听第一遍</div>
          <div class="flex gap-md items-center flex-wrap">
            <button class="btn btn-primary" id="tts-play-1" onclick="playListeningSlow()">▶ 0.8× 播放</button>
            <button class="btn btn-ghost btn-sm" onclick="stopListening()">⏹ 停止</button>
            <span class="badge badge-mint" id="listen1-status">未播放</span>
          </div>
        </div>

        <div class="card" id="listen1-feedback" style="display:none;">
          <div class="text-secondary text-sm mb-md">听力理解如何？</div>
          <div class="flex gap-md">
            <button class="btn btn-outline flex-1" onclick="replayListeningSlow()">🔄 再听一遍</button>
            <button class="btn btn-primary flex-1" onclick="proceedToQuestions()">回答理解题 →</button>
          </div>
          <div class="mt-md">
            <div class="text-light text-xs mb-sm">没听懂？可以选择"基本没听懂"进入学习模式</div>
            <button class="btn btn-ghost btn-sm btn-block" onclick="notUnderstood()">基本没听懂 😟</button>
          </div>
        </div>

        <div class="flex gap-md mt-lg">
          <button class="btn btn-outline flex-1" onclick="navTo('today')">退出</button>
        </div>
      </div>
    `;
    return;
  }

  // 理解问题
  if (listeningState.phase === 'questions') {
    const qIdx = listeningState.questionsAnswered;
    if (qIdx >= questions.length) {
      // 所有问题回答完毕
      listeningState.phase = 'listen2';
      renderListeningPhase(app);
      return;
    }
    const q = questions[qIdx];

    app.innerHTML = `
      <div class="container page">
        ${sessionBar}
        <div style="padding: 20px 0;">
          <div class="badge badge-mint mb-md">Step 1 of 5 · 理解题</div>
          <h2>理解问题 ${qIdx + 1} / ${questions.length}</h2>
        </div>

        <div class="card">
          <div style="font-size: 18px; font-weight: 600; line-height: 1.6;">${q.q}</div>
        </div>

        <div class="card">
          <div class="text-secondary text-sm mb-md">选择正确答案</div>
          <div class="comprehension-options">
            ${q.options.map((opt, i) => `
              <button class="comprehension-option" onclick="answerComprehension(${i})" id="opt-${i}">
                <span class="option-letter">${String.fromCharCode(65 + i)}</span>
                <span class="option-text">${opt}</span>
              </button>
            `).join('')}
          </div>
        </div>

        <div class="card" id="comprehension-feedback" style="display:none;">
          <div id="feedback-content"></div>
          <button class="btn btn-primary btn-block mt-md" onclick="nextComprehension()" id="next-q-btn">${qIdx < questions.length - 1 ? '下一题 →' : '听第二遍 →'}</button>
        </div>
      </div>
    `;
    return;
  }

  // 第二遍听力（正常速度）
  if (listeningState.phase === 'listen2') {
    app.innerHTML = `
      <div class="container page">
        ${sessionBar}
        <div style="padding: 20px 0;">
          <div class="badge badge-mint mb-md">Step 1 of 5 · 第二遍听力</div>
          <h2>🎧 正常速度听力</h2>
          <p class="text-secondary text-sm mt-sm">理解题已完成 ${listeningState.questionsCorrect}/${listeningState.questionsAnswered} 正确</p>
        </div>

        <div class="card listening-player">
          <div class="text-secondary text-sm mb-md">以正常速度再听一遍</div>
          <div class="flex gap-md items-center flex-wrap">
            <button class="btn btn-primary" id="tts-play-2" onclick="playListeningNormal()">▶ 1.0× 播放</button>
            <button class="btn btn-ghost btn-sm" onclick="stopListening()">⏹ 停止</button>
          </div>
        </div>

        <button class="btn btn-primary btn-block btn-lg mt-lg" onclick="revealListeningText()">显示全文 →</button>
      </div>
    `;
    return;
  }

  // 显示全文 + 关键词高亮 + 跟读 + 复述
  if (listeningState.phase === 'reveal') {
    let highlightedText = listening.text;
    if (keywords && keywords.length > 0) {
      keywords.forEach(kw => {
        const escaped = kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp('(' + escaped + ')', 'gi');
        highlightedText = highlightedText.replace(regex, '<span class="listening-highlight">$1</span>');
      });
    }

    app.innerHTML = `
      <div class="container page">
        ${sessionBar}
        <div style="padding: 20px 0;">
          <div class="badge badge-mint mb-md">Step 1 of 5 · 全文与高亮</div>
          <h2>📖 完整文本</h2>
        </div>

        <div class="card">
          <div class="text-secondary text-sm mb-sm">听力全文（关键词已高亮）</div>
          <div class="listening-text" style="line-height: 1.8; font-size: 17px;">${highlightedText}</div>
          <div class="flex gap-sm mt-md">
            <button class="btn btn-ghost btn-sm" onclick="SpeechUtils.speak('${listening.text.replace(/'/g, "\\'")}', {rate: 1.0})">🔊 朗读全文</button>
            <button class="btn btn-ghost btn-sm" onclick="addUncomprehendedToReview()">未掌握的表达加入复习</button>
          </div>
        </div>

        <div class="flex gap-md mt-lg">
          <button class="btn btn-outline flex-1" onclick="navTo('today')">退出</button>
          <button class="btn btn-primary flex-1" onclick="nextSessionStep()">下一步：复习 →</button>
        </div>
      </div>
    `;
    return;
  }
}

function switchListeningMode(mode) {
  listeningState.mode = mode;
  updateSettings({ listeningMode: mode });
  renderListeningPhase(document.getElementById('app'));
}

function startListeningPhase1() {
  listeningState.phase = 'listen1';
  renderListeningPhase(document.getElementById('app'));
  // 自动播放
  setTimeout(() => playListeningSlow(), 300);
}

function playListeningSlow() {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const slowRate = appSettings.listeningSlowRate || 0.8;
  SpeechUtils.speak(lesson.listening.text, { rate: slowRate });
  listeningState.listenCount++;
  const status = document.getElementById('listen1-status');
  if (status) { status.textContent = '播放中...'; status.className = 'badge badge-gold'; }
  // 显示反馈区
  setTimeout(() => {
    const fb = document.getElementById('listen1-feedback');
    if (fb) fb.style.display = 'block';
    if (status) { status.textContent = '已播放'; status.className = 'badge badge-mint'; }
  }, 2000);
}

function replayListeningSlow() {
  playListeningSlow();
}

function proceedToQuestions() {
  listeningState.phase = 'questions';
  renderListeningPhase(document.getElementById('app'));
}

function notUnderstood() {
  // 基本没听懂：切换到学习模式、0.8倍速、关键词提示
  listeningState.mode = 'study';
  updateSettings({ listeningMode: 'study', listeningSlowRate: 0.8 });
  showToast('已切换到学习模式，建议用0.8倍速再听一遍');
  // 重新听
  playListeningSlow();
}

function answerComprehension(optionIdx) {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const questions = lesson.listening.comprehension_questions || [];
  const q = questions[listeningState.questionsAnswered];
  const correctIdx = q.options.indexOf(q.a);

  const isCorrect = optionIdx === correctIdx;
  listeningState.questionsAnswered++;
  if (isCorrect) listeningState.questionsCorrect++;
  listeningState.comprehensionResults.push({ question: q.q, answer: q.options[optionIdx], correct: q.a, isCorrect });

  // 显示所有选项的对错
  q.options.forEach((opt, i) => {
    const el = document.getElementById('opt-' + i);
    if (!el) return;
    el.disabled = true;
    if (i === correctIdx) {
      el.classList.add('correct');
    } else if (i === optionIdx) {
      el.classList.add('incorrect');
    }
  });

  // 显示反馈
  const fb = document.getElementById('comprehension-feedback');
  const fbContent = document.getElementById('feedback-content');
  if (fb && fbContent) {
    fbContent.innerHTML = `
      <div class="${isCorrect ? 'text-mint' : 'text-coral'}" style="font-weight: 600;">
        ${isCorrect ? '✓ 正确！' : '✗ 不正确'}
      </div>
      <div class="text-secondary text-sm mt-sm">正确答案：${q.a}</div>
    `;
    fb.style.display = 'block';
  }
}

function nextComprehension() {
  renderListeningPhase(document.getElementById('app'));
}

function playListeningNormal() {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  SpeechUtils.speak(lesson.listening.text, { rate: 1.0 });
}

function revealListeningText() {
  listeningState.phase = 'reveal';
  listeningState.textRevealed = true;
  renderListeningPhase(document.getElementById('app'));
}

function startShadowing() {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  SpeechUtils.speak(lesson.listening.text, { rate: 0.9 });
  const result = document.getElementById('shadowing-result');
  if (result) result.style.display = 'block';
  showToast('正在播放，请跟读');
}

function retellVoiceInput() {
  if (!SpeechUtils.isSTTAvailable()) {
    showToast('当前浏览器不支持语音识别，请用文本输入');
    return;
  }
  showToast('正在录音...说英语后停止');
  const input = document.getElementById('retell-answer');
  SpeechUtils.startRecognition({
    onresult: (e) => {
      input.value = Array.from(e.results).map(r => r[0].transcript).join('');
    },
    onend: () => showToast('录音结束'),
    onerror: () => showToast('语音识别出错')
  });
}

async function addUncomprehendedToReview() {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const itemIds = lesson.itemIds || [];
  let added = 0;
  for (const itemId of itemIds) {
    const mastery = await dbGet(STORES.masteryRecords, itemId);
    if (mastery && mastery.mastery_state !== 'Mastered') {
      // 加入次日复习
      await dbPut(STORES.reviewSchedule, {
        item_id: itemId,
        next_review_at: Date.now() + 86400000,
        interval_days: 1,
        review_count: mastery.review_count || 0,
        mastery_state: mastery.mastery_state || 'Learning'
      });
      added++;
    }
  }
  showToast(added > 0 ? `已将 ${added} 个表达加入明日复习` : '今日表达已全部掌握');
}

function stopListening() { SpeechUtils.stop(); }
function updateTTSRate(val) { updateSettings({ speechRate: parseFloat(val) }); }

// ===== Session Bar =====
function renderSessionBar(currentStep) {
  const steps = ['听力', '复习', '学习', '练习', '挑战', '总结'];
  let dots = '';
  for (let i = 0; i < steps.length; i++) {
    const cls = i < currentStep ? 'done' : (i === currentStep ? 'active' : '');
    dots += `<div class="session-step-dot ${cls}"></div>`;
  }
  return `<div class="session-bar"><div class="session-steps">${dots}</div><button class="btn btn-ghost btn-sm" onclick="navTo('today')">退出</button></div>`;
}

function nextSessionStep() {
  if (!currentSession) { navTo('today'); return; }
  currentSession.step++;
  if (currentSession.step >= currentSession.steps.length) {
    completeSession();
    return;
  }
  const stepName = currentSession.steps[currentSession.step];
  navTo(stepName, { session: true });
}

// ===== Review Page =====
let currentReviewItems = [];
let currentReviewIdx = 0;
let reviewAnswerVisible = false;

async function renderReview(app) {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const allItems = await dbGetAll(STORES.knowledgeItems);
  const itemMap = {};
  allItems.forEach(i => itemMap[i.id] = i);
  const allMastery = await dbGetAll(STORES.masteryRecords);
  const masteryMap = {};
  allMastery.forEach(m => masteryMap[m.item_id] = m);

  // 优先加载到期复习项
  const dueItems = await WEC_Algo.getDueReviewItems();

  if (dueItems.length > 0) {
    // 有到期复习：取到期项，最多10个
    currentReviewItems = dueItems.slice(0, 10).map(s => ({
      item: itemMap[s.item_id],
      mastery: masteryMap[s.item_id] || WEC_Algo.initMastery(s.item_id),
      schedule: s
    })).filter(r => r.item);
  } else {
    // 没有到期复习：从当天课程的表达中选5个做预练习
    // 这样复习内容与当天学习内容一致，降低负担
    currentReviewItems = lesson.itemIds.slice(0, 5).map(id => {
      const item = itemMap[id];
      if (!item) return null;
      return { item, mastery: masteryMap[id] || WEC_Algo.initMastery(id) };
    }).filter(Boolean);
  }

  currentReviewIdx = 0;
  renderReviewCard(app);
}

function renderReviewCard(app) {
  if (currentReviewIdx >= currentReviewItems.length) {
    renderReviewComplete(app);
    return;
  }

  const { item, mastery } = currentReviewItems[currentReviewIdx];
  reviewAnswerVisible = false;
  const sessionBar = currentSession ? renderSessionBar(1) : '';

  // 随机选择题型
  const questionTypes = ['cn-to-en', 'fill-blank', 'sentence-reorder', 'scenario-answer'];
  const qType = questionTypes[Math.floor(Math.random() * questionTypes.length)];

  let questionHTML = '';
  switch(qType) {
    case 'cn-to-en':
      questionHTML = `
        <div class="text-secondary text-sm mb-sm">看到中文，说出/写出英文</div>
        <div style="font-size: 20px; font-weight: 600; padding: 16px; background: var(--color-bg-subtle); border-radius: 12px;">${item.chinese}</div>
        <div class="text-light text-xs mt-sm">提示：${item.chunk || item.example_sentence?.split(' ').slice(0,3).join(' ') + '...'}</div>
      `;
      break;
    case 'fill-blank':
      const words = item.example_sentence.split(' ');
      const blankIdx = Math.min(words.length - 1, Math.floor(words.length / 2));
      const blankWord = words[blankIdx];
      const sentenceWithBlank = words.map((w, i) => i === blankIdx ? '____' : w).join(' ');
      questionHTML = `
        <div class="text-secondary text-sm mb-sm">填空：补全句子</div>
        <div style="font-size: 17px; padding: 16px; background: var(--color-bg-subtle); border-radius: 12px; line-height: 1.8;">${sentenceWithBlank}</div>
        <div class="text-light text-xs mt-sm">缺失的词：${blankWord.length} 个字母</div>
      `;
      break;
    case 'sentence-reorder':
      const shuffled = item.example_sentence.split(' ').sort(() => Math.random() - 0.5);
      questionHTML = `
        <div class="text-secondary text-sm mb-sm">重组句子：按正确顺序排列</div>
        <div style="display:flex; flex-wrap:wrap; gap:8px; padding:16px; background:var(--color-bg-subtle); border-radius:12px;">
          ${shuffled.map(w => `<span class="chip">${w}</span>`).join('')}
        </div>
        <div class="text-light text-xs mt-sm">中文：${item.chinese}</div>
      `;
      break;
    case 'scenario-answer':
      questionHTML = `
        <div class="text-secondary text-sm mb-sm">根据场景自行回答</div>
        <div style="padding:16px; background:var(--color-bg-subtle); border-radius:12px;">
          <div class="text-secondary text-sm">场景</div>
          <div style="font-size:16px; margin-top:4px;">${item.work_context}</div>
          <div class="text-secondary text-sm mt-md">任务</div>
          <div style="font-size:16px; margin-top:4px;">用包含「${item.english}」的表达回答</div>
        </div>
      `;
      break;
  }

  app.innerHTML = `
    <div class="container page">
      ${sessionBar}
      <div style="padding: 20px 0;">
        <div class="flex justify-between items-center">
          <h2>主动复习</h2>
          <span class="badge badge-primary">${currentReviewIdx + 1} / ${currentReviewItems.length}</span>
        </div>
      </div>

      <div class="card">
        ${questionHTML}
      </div>

      <div class="card">
        <textarea id="review-answer" placeholder="输入你的回答..." style="min-height: 100px;"></textarea>
        <div class="flex gap-sm mt-sm">
          <button class="btn btn-ghost btn-sm flex-1" onclick="useVoiceInput()">🎤 语音</button>
          <button class="btn btn-ghost btn-sm flex-1" onclick="showHint('${item.id}')">💡 提示</button>
          <button class="btn btn-ghost btn-sm flex-1" onclick="showReviewAnswer()">查看答案</button>
        </div>
      </div>

      <div class="card" id="review-answer-card" style="display:none;">
        <div class="text-secondary text-sm mb-sm">参考答案</div>
        <div style="font-size: 18px; font-weight: 600; color: var(--color-primary);">${item.english}</div>
        <div class="text-secondary text-sm mt-sm">${item.example_sentence}</div>
        ${item.common_mistakes ? `<div class="text-coral text-xs mt-sm">⚠️ 常见错误：${item.common_mistakes.join(' · ')}</div>` : ''}
        ${item.usage_note ? `<div class="text-light text-xs mt-sm">💡 ${item.usage_note}</div>` : ''}

        <div class="text-secondary text-sm mt-md mb-sm">你的回答怎么样？</div>
        <div class="rating-group">
          <button class="rating-btn again" onclick="rateReview('again')">忘记</button>
          <button class="rating-btn hard" onclick="rateReview('hard')">困难</button>
          <button class="rating-btn good" onclick="rateReview('good')">掌握</button>
          <button class="rating-btn easy" onclick="rateReview('easy')">轻松</button>
        </div>
      </div>

      ${!currentSession ? `
        <div class="flex gap-md mt-lg">
          <button class="btn btn-outline flex-1" onclick="navTo('today')">返回</button>
        </div>
      ` : ''}
    </div>
  `;
}

function showReviewAnswer() {
  document.getElementById('review-answer-card').style.display = 'block';
  reviewAnswerVisible = true;
}

function showHint(itemId) {
  const item = KNOWLEDGE_ITEMS.find(i => i.id === itemId);
  if (!item) return;
  showToast(`💡 提示：${item.chunk || item.natural_alternatives?.[0] || item.english.slice(0, 10) + '...'}`);
}

function useVoiceInput() {
  if (!SpeechUtils.isSTTAvailable()) {
    showToast('当前浏览器不支持语音识别，请使用文本输入');
    return;
  }
  showToast('正在录音...说英语后停止');
  const input = document.getElementById('review-answer');
  SpeechUtils.startRecognition({
    onresult: (e) => {
      const text = Array.from(e.results).map(r => r[0].transcript).join('');
      input.value = text;
    },
    onend: () => showToast('录音结束'),
    onerror: () => showToast('语音识别出错，请用文本输入')
  });
}

async function rateReview(rating) {
  if (currentReviewIdx >= currentReviewItems.length) return;
  const { item, mastery, schedule } = currentReviewItems[currentReviewIdx];

  // 记录学习尝试
  const answer = document.getElementById('review-answer')?.value || '';
  const startTime = Date.now();
  const dimension = rating === 'easy' ? 'recall' : (rating === 'again' ? 'recognition' : 'recall');

  await dbPut(STORES.learningAttempts, {
    id: uuid(),
    item_id: item.id,
    date: todayStr(),
    rating,
    success: rating === 'good' || rating === 'easy',
    response_time: Date.now() - startTime,
    hint_used: !reviewAnswerVisible,
    answer_mode: 'text',
    answer_text: answer,
    dimension: dimension
  });

  // 更新掌握记录
  const updatedMastery = WEC_Algo.updateMastery(mastery, rating, {
    dimension,
    responseTime: Date.now() - startTime,
    hintUsed: !reviewAnswerVisible,
    answerMode: 'text'
  });
  await dbPut(STORES.masteryRecords, updatedMastery);

  // 更新复习排程
  await dbPut(STORES.reviewSchedule, {
    item_id: item.id,
    next_review_at: updatedMastery.next_review_at,
    interval_days: updatedMastery.interval_days,
    review_count: updatedMastery.review_count,
    mastery_state: updatedMastery.mastery_state
  });

  // 更新能力分数
  await updateSkillScore(item.skill_key || 'give_updates', rating === 'good' || rating === 'easy');

  // 如果答错，加入错题库
  if (rating === 'again' || rating === 'hard') {
    await dbPut(STORES.errorBank, {
      id: uuid(),
      original_answer: answer,
      better_answer: item.english,
      error_type: rating === 'again' ? 'recall_failure' : 'difficult',
      error_tag: dimension + '_weakness',
      explanation: item.usage_note || '',
      scenario_id: item.scenario_id,
      learning_item_id: item.id,
      occurrence_count: 1,
      first_seen_at: new Date().toISOString(),
      last_seen_at: new Date().toISOString(),
      next_review_at: Date.now() + 86400000,
      resolved: false
    });
  }

  currentReviewIdx++;
  renderReviewCard(document.getElementById('app'));
}

function renderReviewComplete(app) {
  const isSession = !!currentSession;
  app.innerHTML = `
    <div class="container page">
      ${isSession ? renderSessionBar(1) : ''}
      <div class="empty-state" style="padding: 60px 20px;">
        <div style="font-size: 48px;">🎉</div>
        <h2 style="margin-top: 16px;">复习完成！</h2>
        <p class="text-secondary mt-sm">已完成 ${currentReviewItems.length} 个表达复习</p>
      </div>
      ${isSession ? `
        <button class="btn btn-primary btn-block btn-lg" onclick="nextSessionStep()">下一步：学习新表达 →</button>
      ` : `
        <button class="btn btn-primary btn-block btn-lg" onclick="navTo('today')">返回首页</button>
      `}
    </div>
  `;
}

async function updateSkillScore(skillKey, isCorrect) {
  if (!skillKey) return;
  const skill = await dbGet(STORES.skillScores, skillKey);
  if (!skill) return;
  skill.evidence_count = (skill.evidence_count || 0) + 1;
  const delta = isCorrect ? 3 : -2;
  skill.score = Math.max(0, Math.min(100, (skill.score || 0) + delta));
  skill.updated_at = new Date().toISOString();
  await dbPut(STORES.skillScores, skill);
}

// ===== Learn Page =====
let currentLearnIdx = 0;
let learnItems = [];

async function renderLearn(app, params) {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const allItems = await dbGetAll(STORES.knowledgeItems);
  const itemMap = {};
  allItems.forEach(i => itemMap[i.id] = i);

  learnItems = lesson.itemIds.map(id => itemMap[id]).filter(Boolean);
  currentLearnIdx = 0;
  renderLearnCard(app);
}

function renderLearnCard(app) {
  if (currentLearnIdx >= learnItems.length) {
    renderLearnComplete(app);
    return;
  }
  const item = learnItems[currentLearnIdx];
  const sessionBar = currentSession ? renderSessionBar(2) : '';

  app.innerHTML = `
    <div class="container page">
      ${sessionBar}
      <div style="padding: 20px 0;">
        <div class="flex justify-between items-center">
          <h2>学习表达</h2>
          <span class="badge badge-primary">${currentLearnIdx + 1} / ${learnItems.length}</span>
        </div>
      </div>

      <div class="card">
        <div class="flex gap-sm" style="margin-bottom: 12px;">
          <span class="badge badge-mint">${item.type}</span>
          <span class="badge badge-gray">${item.work_context}</span>
        </div>

        <div style="font-size: 24px; font-weight: 700; color: var(--color-primary); line-height: 1.4;">${item.english}</div>
        <div class="text-secondary mt-sm" style="font-size: 17px;">${item.chinese}</div>
        ${item.phonetic ? `<div class="text-light text-xs mt-sm">${item.phonetic}</div>` : ''}

        <button class="btn btn-ghost btn-sm mt-md" onclick="SpeechUtils.speak('${item.english.replace(/'/g, "\\'")}', {rate: ${appSettings.speechRate}})">🔊 朗读</button>
      </div>

      ${item.example_sentence ? `
      <div class="card">
        <div class="text-secondary text-sm mb-sm">例句</div>
        <div style="font-size: 17px; line-height: 1.7;">${item.example_sentence}</div>
        <button class="btn btn-ghost btn-sm mt-md" onclick="SpeechUtils.speak('${item.example_sentence.replace(/'/g, "\\'")}', {rate: ${appSettings.speechRate}})">🔊 听例句</button>
      </div>
      ` : ''}

      ${item.natural_alternatives && item.natural_alternatives.length ? `
      <div class="card">
        <div class="text-secondary text-sm mb-sm">自然替换表达</div>
        ${item.natural_alternatives.map(alt => `<div style="padding: 8px 0; border-bottom: 1px solid var(--color-border-light);">• ${alt}</div>`).join('')}
      </div>
      ` : ''}

      ${item.common_mistakes && item.common_mistakes.length ? `
      <div class="card" style="border-left: 3px solid var(--color-coral);">
        <div class="text-coral text-sm mb-sm">⚠️ 常见错误</div>
        ${item.common_mistakes.map(m => `<div class="text-sm" style="padding: 4px 0;">${m}</div>`).join('')}
      </div>
      ` : ''}

      ${item.usage_note ? `
      <div class="card" style="background: var(--color-bg-subtle);">
        <div class="text-secondary text-sm">💡 使用说明</div>
        <div class="text-sm mt-sm" style="line-height: 1.6;">${item.usage_note}</div>
      </div>
      ` : ''}

      ${item.work_context ? `
      <div class="card">
        <div class="text-secondary text-sm">💼 工作场景</div>
        <div class="text-sm mt-sm">${item.work_context}</div>
      </div>
      ` : ''}

      <div class="flex gap-md mt-lg">
        ${currentLearnIdx > 0 ? `<button class="btn btn-outline" onclick="currentLearnIdx--; renderLearnCard(document.getElementById('app'))">上一个</button>` : ''}
        <button class="btn btn-primary flex-1" onclick="nextLearnItem()">${currentLearnIdx < learnItems.length - 1 ? '下一个 →' : '完成学习 →'}</button>
      </div>
    </div>
  `;
}

function nextLearnItem() {
  currentLearnIdx++;
  renderLearnCard(document.getElementById('app'));
}

function renderLearnComplete(app) {
  const isSession = !!currentSession;
  app.innerHTML = `
    <div class="container page">
      ${isSession ? renderSessionBar(2) : ''}
      <div class="empty-state" style="padding: 60px 20px;">
        <div style="font-size: 48px;">📚</div>
        <h2 style="margin-top: 16px;">学习完成！</h2>
        <p class="text-secondary mt-sm">已学习 ${learnItems.length} 个新表达</p>
      </div>
      ${isSession ? `
        <button class="btn btn-primary btn-block btn-lg" onclick="nextSessionStep()">下一步：工作练习 →</button>
      ` : `
        <button class="btn btn-primary btn-block btn-lg" onclick="navTo('today')">返回首页</button>
      `}
    </div>
  `;
}

// ===== Complete Session =====
async function completeSession() {
  const studyDay = getStudyDay(appSettings);
  await dbPut(STORES.dailySessions, {
    day: studyDay,
    date: todayStr(),
    completed: true,
    completed_at: new Date().toISOString(),
    study_minutes: appSettings.dailyMinutes || 25
  });

  updateStreak(appSettings);
  const totalMin = (appSettings.totalStudyMinutes || 0) + (appSettings.dailyMinutes || 25);
  updateSettings({ totalStudyMinutes: totalMin });

  currentSession = null;
  // 清除session页面状态，刷新后回到today
  updateState({ currentPage: 'today', sessionActive: false });
  navTo('session-summary', { completed: true });
}

// ===== Day 0 Assessment Page =====
async function renderAssessment(app) {
  const assessmentCompleted = appSettings.assessmentCompleted || false;

  if (assessmentCompleted) {
    app.innerHTML = `
      <div class="container page">
        <div style="padding: 20px 0;">
          <h2>入门测评</h2>
        </div>
        <div class="empty-state" style="padding: 40px 20px;">
          <div style="font-size: 48px;">✓</div>
          <h2 style="margin-top: 16px;">已完成测评</h2>
          <p class="text-secondary mt-sm">您已完成入门测评，能力分数将随学习进度更新。</p>
        </div>
        <button class="btn btn-primary btn-block btn-lg" onclick="navTo('progress')">查看进度 →</button>
      </div>
    `;
    return;
  }

  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <div class="badge badge-mint mb-md">Day 0</div>
        <h2>入门测评</h2>
        <p class="text-secondary text-sm mt-sm">通过简短测评了解你的英语工作沟通起点</p>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">测评内容</div>
        <div class="text-sm" style="line-height: 1.8;">
          1. 听一段简短的工作汇报（正常语速）<br>
          2. 回答2个理解问题<br>
          3. 用英语写一段30秒的工作状态汇报
        </div>
        <div class="text-light text-xs mt-md">测评结果仅用于设定初始能力基准，不影响学习内容。</div>
      </div>

      <div class="card" id="assessment-start">
        <button class="btn btn-primary btn-block btn-lg" onclick="startAssessment()">开始测评 →</button>
      </div>

      <div class="card" id="assessment-listening" style="display:none;">
        <div class="text-secondary text-sm mb-md">🎧 第一部分：听力理解</div>
        <div class="text-sm mb-md">听以下段落，然后回答问题：</div>
        <div style="padding: 16px; background: var(--color-bg-subtle); border-radius: 12px; font-style: italic; line-height: 1.7;">
          "Let me give you a quick update. The current status of the ticket is in progress. We are currently working on it and expect to resolve it by tomorrow. The main reason for the delay was a supply chain issue. Our next step is to build a backup supplier list."
        </div>
        <button class="btn btn-outline btn-sm mt-md" onclick="SpeechUtils.speak('Let me give you a quick update. The current status of the ticket is in progress. We are currently working on it and expect to resolve it by tomorrow. The main reason for the delay was a supply chain issue. Our next step is to build a backup supplier list.', {rate: 1.0})">🔊 播放</button>

        <div class="mt-md">
          <div class="text-secondary text-sm mb-sm">问题 1：What is the current status of the ticket?</div>
          <div class="comprehension-options">
            <button class="comprehension-option" onclick="assessAnswer(0, 0, 'pending', this)">A. Pending</button>
            <button class="comprehension-option" onclick="assessAnswer(0, 1, 'in progress', this)">B. In progress</button>
            <button class="comprehension-option" onclick="assessAnswer(0, 2, 'resolved', this)">C. Resolved</button>
            <button class="comprehension-option" onclick="assessAnswer(0, 3, 'cancelled', this)">D. Cancelled</button>
          </div>
        </div>

        <div class="mt-md">
          <div class="text-secondary text-sm mb-sm">问题 2：What was the main reason for the delay?</div>
          <div class="comprehension-options">
            <button class="comprehension-option" onclick="assessAnswer(1, 0, 'staff shortage', this)">A. Staff shortage</button>
            <button class="comprehension-option" onclick="assessAnswer(1, 1, 'supply chain issue', this)">B. Supply chain issue</button>
            <button class="comprehension-option" onclick="assessAnswer(1, 2, 'system error', this)">C. System error</button>
            <button class="comprehension-option" onclick="assessAnswer(1, 3, 'owner unavailable', this)">D. Owner unavailable</button>
          </div>
        </div>
      </div>

      <div class="card" id="assessment-speaking" style="display:none;">
        <div class="text-secondary text-sm mb-md">🎤 第二部分：工作状态汇报</div>
        <div class="text-sm mb-md">用英语写一段30秒的工作状态汇报，包括当前状态、原因和下一步。</div>
        <textarea id="assessment-answer" placeholder="用英语写你的工作汇报..." style="min-height: 120px;"></textarea>
        <button class="btn btn-primary btn-block mt-md" onclick="submitAssessment()">提交测评 →</button>
      </div>

      <div class="card" id="assessment-result" style="display:none;">
        <div style="text-align: center; padding: 20px 0;">
          <div style="font-size: 48px;">🎉</div>
          <h2 style="margin-top: 16px;">测评完成！</h2>
        </div>
        <div id="assessment-scores"></div>
        <button class="btn btn-primary btn-block btn-lg mt-lg" onclick="navTo('today')">开始学习 →</button>
      </div>
    </div>
  `;
}

let assessmentAnswers = [-1, -1];
let assessmentSpeakingAnswer = '';

function startAssessment() {
  document.getElementById('assessment-start').style.display = 'none';
  document.getElementById('assessment-listening').style.display = 'block';
}

function assessAnswer(qIdx, optIdx, text, btn) {
  assessmentAnswers[qIdx] = optIdx;
  // 更新选项样式
  const options = btn.parentElement.querySelectorAll('.comprehension-option');
  options.forEach(o => o.classList.remove('selected'));
  btn.classList.add('selected');
  // 两题都答完后显示口语部分
  if (assessmentAnswers[0] >= 0 && assessmentAnswers[1] >= 0) {
    setTimeout(() => {
      document.getElementById('assessment-speaking').style.display = 'block';
      document.getElementById('assessment-speaking').scrollIntoView({ behavior: 'smooth' });
    }, 500);
  }
}

async function submitAssessment() {
  const answer = document.getElementById('assessment-answer').value.trim();
  if (!answer || answer.length < 10) {
    showToast('请写一段英语工作汇报（至少10个词）');
    return;
  }
  assessmentSpeakingAnswer = answer;

  // 计算初始分数
  const listeningCorrect = (assessmentAnswers[0] === 1 ? 1 : 0) + (assessmentAnswers[1] === 1 ? 1 : 0);
  const listeningScore = Math.round((listeningCorrect / 2) * 100);

  // 评估汇报质量（简单规则匹配）
  const hasStatus = /status|in progress|pending|working/i.test(answer);
  const hasReason = /reason|because|due to|caused/i.test(answer);
  const hasNext = /next step|will|plan to|going to|expect/i.test(answer);
  const structureScore = Math.round(((hasStatus ? 1 : 0) + (hasReason ? 1 : 0) + (hasNext ? 1 : 0)) / 3 * 100);
  const wordCount = answer.split(/\s+/).length;
  const fluencyScore = Math.min(100, Math.round(wordCount / 30 * 100));

  // 更新能力分数
  const skills = ['listening', 'give_updates', 'explain_reasons', 'suggest_next', 'continuous_speaking'];
  const scores = {
    listening: listeningScore,
    give_updates: structureScore,
    explain_reasons: hasReason ? 60 : 30,
    suggest_next: hasNext ? 60 : 30,
    continuous_speaking: fluencyScore
  };

  for (const key of skills) {
    const skill = await dbGet(STORES.skillScores, key);
    if (skill) {
      skill.score = scores[key];
      skill.evidence_count = 1;
      skill.updated_at = new Date().toISOString();
      await dbPut(STORES.skillScores, skill);
    }
  }

  // 保存测评记录
  await dbPut(STORES.assessments, {
    assessment_type: 'day0',
    date: todayStr(),
    listening_answers: assessmentAnswers,
    speaking_answer: assessmentSpeakingAnswer,
    scores
  });

  updateSettings({ assessmentCompleted: true });

  // 显示结果
  document.getElementById('assessment-speaking').style.display = 'none';
  const result = document.getElementById('assessment-result');
  result.style.display = 'block';
  document.getElementById('assessment-scores').innerHTML = `
    <div class="flex justify-between mb-sm"><span>听力理解</span><span class="badge ${listeningScore > 60 ? 'badge-mint' : listeningScore > 30 ? 'badge-gold' : 'badge-coral'}">${listeningScore}</span></div>
    <div class="flex justify-between mb-sm"><span>汇报结构</span><span class="badge ${structureScore > 60 ? 'badge-mint' : structureScore > 30 ? 'badge-gold' : 'badge-coral'}">${structureScore}</span></div>
    <div class="flex justify-between mb-sm"><span>原因表达</span><span class="badge ${hasReason ? 'badge-mint' : 'badge-coral'}">${hasReason ? 60 : 30}</span></div>
    <div class="flex justify-between mb-sm"><span>下一步表达</span><span class="badge ${hasNext ? 'badge-mint' : 'badge-coral'}">${hasNext ? 60 : 30}</span></div>
    <div class="flex justify-between mb-sm"><span>表达流畅度</span><span class="badge ${fluencyScore > 60 ? 'badge-mint' : fluencyScore > 30 ? 'badge-gold' : 'badge-coral'}">${fluencyScore}</span></div>
    <div class="text-light text-xs mt-md">这些分数将随你的学习进度持续更新。</div>
  `;
  result.scrollIntoView({ behavior: 'smooth' });
}
