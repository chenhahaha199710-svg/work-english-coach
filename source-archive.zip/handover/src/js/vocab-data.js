// ===== Vocabulary Data: 28 Days of Work English =====
// 200+ vocabulary items for property management / customer service contexts
// Each word covers: word, lemma, pos, chinese, work_meaning, examples, collocations,
// confusable words, work_context, related_expression (KNOWLEDGE_ITEMS id),
// acceptable_answers, work_relevance, difficulty, day, scenario_id

const VOCAB_ITEMS = [
  // ============================================================
  // WEEK 1 (Days 1-7): Reporting status, ticket progress, delays, reasons
  // ============================================================

  // --- Day 1: Reporting Current Status (8 words) ---
  {
    id: 'v-001', word: 'status', lemma: 'status', pos: 'noun', chinese: '状态',
    work_meaning: '工单、任务或问题的当前处理阶段',
    example_en: 'The current status of the ticket is pending.',
    example_cn: '工单的当前状态是待处理。',
    collocations: ['current status', 'update the status', 'check the status', 'change the status'],
    confusable: [{word: 'state', diff: 'state更泛指一般状态，status常指进度或处理阶段'}, {word: 'statue', diff: 'statue是雕像，发音相近但完全不同'}],
    work_context: '工单处理', related_expression: 'ki-001',
    acceptable_answers: ['status', 'statuses'], work_relevance: 5, difficulty: 1, day: 1, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-002', word: 'current', lemma: 'current', pos: 'adjective', chinese: '当前的',
    work_meaning: '指现在正在进行的或此刻有效的',
    example_en: 'The current status of the repair is in progress.',
    example_cn: '维修的当前状态是进行中。',
    collocations: ['current status', 'current situation', 'current progress', 'current issue'],
    confusable: [{word: 'currency', diff: 'currency是货币，current没有货币含义'}, {word: 'present', diff: 'present也可指当前的，但current更常用于正式汇报'}],
    work_context: '通用汇报', related_expression: 'ki-001',
    acceptable_answers: ['current'], work_relevance: 5, difficulty: 1, day: 1, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-003', word: 'progress', lemma: 'progress', pos: 'noun', chinese: '进度',
    work_meaning: '工作向前推进的程度或速度',
    example_en: 'The repair work is currently in progress.',
    example_cn: '维修工作目前正在进行中。',
    collocations: ['in progress', 'make progress', 'track progress', 'progress report'],
    confusable: [{word: 'process', diff: 'process是过程/流程，progress是进度/进展'}, {word: 'project', diff: 'project是项目，progress是进度'}],
    work_context: '工单处理', related_expression: 'ki-006',
    acceptable_answers: ['progress', 'progresses'], work_relevance: 5, difficulty: 1, day: 1, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-004', word: 'pending', lemma: 'pending', pos: 'adjective', chinese: '待处理的',
    work_meaning: '等待批准、确认或处理的状态',
    example_en: 'The ticket is still pending approval.',
    example_cn: '工单仍在等待批准。',
    collocations: ['pending approval', 'pending review', 'pending confirmation', 'still pending'],
    confusable: [{word: 'padding', diff: 'padding是填充物，发音相近但完全不同'}, {word: 'pendant', diff: 'pendant是吊坠，不用于工作场景'}],
    work_context: '工单处理', related_expression: 'ki-005',
    acceptable_answers: ['pending'], work_relevance: 5, difficulty: 1, day: 1, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-005', word: 'assign', lemma: 'assign', pos: 'verb', chinese: '指派',
    work_meaning: '将任务或工单分配给特定的人或团队',
    example_en: 'I have assigned this ticket to the maintenance team.',
    example_cn: '我已将这个工单指派给维修团队。',
    collocations: ['assign to', 'assign a task', 'assign responsibility', 'be assigned'],
    confusable: [{word: 'design', diff: 'design是设计，assign是指派'}, {word: 'resign', diff: 'resign是辞职，assign是指派'}],
    work_context: '工单分配', related_expression: 'ki-008',
    acceptable_answers: ['assign', 'assigns', 'assigned', 'assigning'], work_relevance: 5, difficulty: 1, day: 1, scenario_id: 'sc-confirm'
  },
  {
    id: 'v-006', word: 'update', lemma: 'update', pos: 'verb', chinese: '更新',
    work_meaning: '提供最新信息或修改状态',
    example_en: 'Please update the ticket status after each action.',
    example_cn: '每次操作后请更新工单状态。',
    collocations: ['update the status', 'keep updated', 'provide an update', 'regular updates'],
    confusable: [{word: 'upset', diff: 'upset是心烦的，update是更新'}, {word: 'upgrade', diff: 'upgrade是升级，update是更新'}],
    work_context: '通用汇报', related_expression: 'ki-003',
    acceptable_answers: ['update', 'updates', 'updated', 'updating'], work_relevance: 5, difficulty: 1, day: 1, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-007', word: 'complete', lemma: 'complete', pos: 'verb', chinese: '完成',
    work_meaning: '将任务或工单处理到结束',
    example_en: 'We expect to complete the repair by the end of the day.',
    example_cn: '我们预计在今天结束前完成维修。',
    collocations: ['complete the task', 'complete the repair', 'be completed', 'completion rate'],
    confusable: [{word: 'compete', diff: 'compete是竞争，complete是完成'}, {word: 'complex', diff: 'complex是复杂的，complete是完成'}],
    work_context: '通用汇报', related_expression: 'ki-007',
    acceptable_answers: ['complete', 'completes', 'completed', 'completing'], work_relevance: 5, difficulty: 1, day: 1, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-008', word: 'responsible', lemma: 'responsible', pos: 'adjective', chinese: '负责的',
    work_meaning: '对某事负有责任或义务',
    example_en: 'The person responsible for this case is Zhang Wei.',
    example_cn: '负责这个案件的人是张伟。',
    collocations: ['responsible for', 'person responsible', 'be responsible', 'hold responsible'],
    confusable: [{word: 'response', diff: 'response是名词回应，responsible是形容词负责的'}, {word: 'responsive', diff: 'responsive是响应迅速的，responsible是负责的'}],
    work_context: '责任确认', related_expression: 'ki-009',
    acceptable_answers: ['responsible'], work_relevance: 5, difficulty: 1, day: 1, scenario_id: 'sc-confirm'
  },

  // --- Day 2: Confirming Owner & Deadline (8 words) ---
  {
    id: 'v-009', word: 'deadline', lemma: 'deadline', pos: 'noun', chinese: '截止时间',
    work_meaning: '任务必须完成的最后时间点',
    example_en: 'We need to complete this by the end of the week.',
    example_cn: '我们需要在本周结束前完成这个。',
    collocations: ['meet the deadline', 'miss the deadline', 'extend the deadline', 'set a deadline'],
    confusable: [{word: 'headline', diff: 'headline是标题，deadline是截止时间'}, {word: 'timeline', diff: 'timeline是时间线（整体规划），deadline是具体截止点'}],
    work_context: '时间确认', related_expression: 'ki-010',
    acceptable_answers: ['deadline', 'deadlines'], work_relevance: 5, difficulty: 1, day: 2, scenario_id: 'sc-confirm'
  },
  {
    id: 'v-010', word: 'owner', lemma: 'owner', pos: 'noun', chinese: '业主/负责人',
    work_meaning: '物业业主或任务的责任人',
    example_en: 'The owner has been notified about the repair schedule.',
    example_cn: '业主已被通知维修计划。',
    collocations: ['property owner', 'ticket owner', 'owner confirmation', 'owner communication'],
    confusable: [{word: 'owers', diff: 'owers不是标准词，注意拼写'}, {word: 'order', diff: 'order是订单/命令，owner是业主'}],
    work_context: '业主沟通', related_expression: 'ki-008',
    acceptable_answers: ['owner', 'owners'], work_relevance: 5, difficulty: 1, day: 2, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-011', word: 'confirm', lemma: 'confirm', pos: 'verb', chinese: '确认',
    work_meaning: '核实并确认信息、时间或责任',
    example_en: 'Please confirm the deadline with the maintenance team.',
    example_cn: '请与维修团队确认截止时间。',
    collocations: ['confirm the deadline', 'confirm receipt', 'confirm with', 'please confirm'],
    confusable: [{word: 'conform', diff: 'conform是遵从/符合，confirm是确认'}, {word: 'inform', diff: 'inform是通知，confirm是确认'}],
    work_context: '责任确认', related_expression: 'ki-009',
    acceptable_answers: ['confirm', 'confirms', 'confirmed', 'confirming'], work_relevance: 5, difficulty: 1, day: 2, scenario_id: 'sc-confirm'
  },
  {
    id: 'v-012', word: 'notify', lemma: 'notify', pos: 'verb', chinese: '通知',
    work_meaning: '正式告知某人相关信息',
    example_en: 'We need to notify the owner within 24 hours.',
    example_cn: '我们需要在24小时内通知业主。',
    collocations: ['notify the owner', 'notify within', 'please notify', 'be notified'],
    confusable: [{word: 'notice', diff: 'notice是注意到/通知（较非正式），notify是正式通知'}, {word: 'identify', diff: 'identify是识别，notify是通知'}],
    work_context: '业主沟通', related_expression: 'ki-037',
    acceptable_answers: ['notify', 'notifies', 'notified', 'notifying'], work_relevance: 5, difficulty: 1, day: 2, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-013', word: 'schedule', lemma: 'schedule', pos: 'noun', chinese: '计划/排期',
    work_meaning: '安排好的时间表或计划',
    example_en: 'The repair is scheduled for tomorrow morning.',
    example_cn: '维修安排在明天上午。',
    collocations: ['on schedule', 'ahead of schedule', 'behind schedule', 'scheduled for'],
    confusable: [{word: 'scheme', diff: 'scheme是方案/阴谋，schedule是时间表'}, {word: 'school', diff: 'school是学校，完全不同'}],
    work_context: '时间确认', related_expression: 'ki-010',
    acceptable_answers: ['schedule', 'schedules', 'scheduled', 'scheduling'], work_relevance: 5, difficulty: 1, day: 2, scenario_id: 'sc-confirm'
  },
  {
    id: 'v-014', word: 'receipt', lemma: 'receipt', pos: 'noun', chinese: '收到/回执',
    work_meaning: '确认收到信息或物品',
    example_en: 'Please confirm receipt of this notification.',
    example_cn: '请确认收到此通知。',
    collocations: ['confirm receipt', 'acknowledge receipt', 'upon receipt', 'receipt of'],
    confusable: [{word: 'recipe', diff: 'recipe是食谱，receipt是收据/收到'}, {word: 'receive', diff: 'receive是动词接收，receipt是名词收据'}],
    work_context: '通用汇报', related_expression: 'ki-010',
    acceptable_answers: ['receipt', 'receipts'], work_relevance: 4, difficulty: 1, day: 2, scenario_id: 'sc-confirm'
  },
  {
    id: 'v-015', word: 'acknowledge', lemma: 'acknowledge', pos: 'verb', chinese: '确认收到',
    work_meaning: '确认已收到信息或通知',
    example_en: 'Please acknowledge receipt of this email.',
    example_cn: '请确认收到此邮件。',
    collocations: ['acknowledge receipt', 'please acknowledge', 'acknowledge the issue', 'acknowledge receipt of'],
    confusable: [{word: 'knowledge', diff: 'knowledge是知识，acknowledge是确认收到'}, {word: 'acquaint', diff: 'acquaint是使认识，acknowledge是确认收到'}],
    work_context: '通用汇报', related_expression: 'ki-010',
    acceptable_answers: ['acknowledge', 'acknowledges', 'acknowledged', 'acknowledging'], work_relevance: 4, difficulty: 2, day: 2, scenario_id: 'sc-confirm'
  },
  {
    id: 'v-016', word: 'team', lemma: 'team', pos: 'noun', chinese: '团队',
    work_meaning: '负责某类工作的小组',
    example_en: 'The maintenance team will handle the repair.',
    example_cn: '维修团队将处理维修工作。',
    collocations: ['maintenance team', 'support team', 'team lead', 'assign to the team'],
    confusable: [{word: 'teem', diff: 'teem是充满，team是团队'}, {word: 'term', diff: 'term是术语/学期，team是团队'}],
    work_context: '工单分配', related_expression: 'ki-008',
    acceptable_answers: ['team', 'teams'], work_relevance: 4, difficulty: 1, day: 2, scenario_id: 'sc-confirm'
  },

  // --- Day 3: Describing Ticket Progress (8 words) ---
  {
    id: 'v-017', word: 'ticket', lemma: 'ticket', pos: 'noun', chinese: '工单',
    work_meaning: '记录和跟踪工作请求的电子单据',
    example_en: 'The ticket is currently pending approval.',
    example_cn: '工单目前正在等待批准。',
    collocations: ['open a ticket', 'close a ticket', 'ticket status', 'ticket volume'],
    confusable: [{word: 'ticked', diff: 'ticked是打勾/恼怒，ticket是工单'}, {word: 'stick', diff: 'stick是棍子/粘贴，ticket是工单'}],
    work_context: '工单处理', related_expression: 'ki-005',
    acceptable_answers: ['ticket', 'tickets'], work_relevance: 5, difficulty: 1, day: 3, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-018', word: 'waiting', lemma: 'wait', pos: 'verb', chinese: '等待',
    work_meaning: '期待某事发生或某人回应',
    example_en: 'We are waiting for the owner to confirm the repair plan.',
    example_cn: '我们正在等待业主确认维修方案。',
    collocations: ['waiting for', 'still waiting', 'waiting on', 'wait for confirmation'],
    confusable: [{word: 'weight', diff: 'weight是重量，wait是等待'}, {word: 'wanting', diff: 'wanting是想要/缺乏，waiting是等待'}],
    work_context: '工单处理', related_expression: 'ki-018',
    acceptable_answers: ['wait', 'waits', 'waited', 'waiting'], work_relevance: 5, difficulty: 1, day: 3, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-019', word: 'approval', lemma: 'approval', pos: 'noun', chinese: '批准',
    work_meaning: '正式同意或许可',
    example_en: 'The ticket is pending approval from the manager.',
    example_cn: '工单正在等待经理批准。',
    collocations: ['pending approval', 'get approval', 'await approval', 'approve the plan'],
    confusable: [{word: 'removal', diff: 'removal是移除，approval是批准'}, {word: 'proposal', diff: 'proposal是提案，approval是批准'}],
    work_context: '工单处理', related_expression: 'ki-005',
    acceptable_answers: ['approval', 'approvals'], work_relevance: 5, difficulty: 1, day: 3, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-020', word: 'review', lemma: 'review', pos: 'verb', chinese: '审查/复审',
    work_meaning: '检查和评估工作内容或工单',
    example_en: 'The manager will review the ticket before approval.',
    example_cn: '经理将在批准前审查工单。',
    collocations: ['review the ticket', 'under review', 'review process', 'review and approve'],
    confusable: [{word: 'preview', diff: 'preview是预览，review是复审'}, {word: 'reveal', diff: 'reveal是揭示，review是审查'}],
    work_context: '工单处理', related_expression: 'ki-005',
    acceptable_answers: ['review', 'reviews', 'reviewed', 'reviewing'], work_relevance: 5, difficulty: 1, day: 3, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-021', word: 'begin', lemma: 'begin', pos: 'verb', chinese: '开始',
    work_meaning: '启动某项工作或流程',
    example_en: 'Once approved, the repair work will begin immediately.',
    example_cn: '一旦批准，维修工作将立即开始。',
    collocations: ['begin immediately', 'begin the repair', 'begin working', 'to begin with'],
    confusable: [{word: 'began', diff: 'began是过去式，begin是原形'}, {word: 'begging', diff: 'begging是乞求，beginning是开始'}],
    work_context: '通用汇报', related_expression: 'ki-006',
    acceptable_answers: ['begin', 'begins', 'began', 'begun', 'beginning'], work_relevance: 4, difficulty: 1, day: 3, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-022', word: 'resolve', lemma: 'resolve', pos: 'verb', chinese: '解决',
    work_meaning: '处理完毕并关闭工单或问题',
    example_en: 'We expect to resolve the ticket by tomorrow.',
    example_cn: '我们预计在明天前解决工单。',
    collocations: ['resolve the issue', 'resolve the ticket', 'be resolved', 'resolution rate'],
    confusable: [{word: 'revolve', diff: 'revolve是旋转，resolve是解决'}, {word: 'dissolve', diff: 'dissolve是溶解/解散，resolve是解决'}],
    work_context: '工单处理', related_expression: 'ki-003',
    acceptable_answers: ['resolve', 'resolves', 'resolved', 'resolving'], work_relevance: 5, difficulty: 1, day: 3, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-023', word: 'open', lemma: 'open', pos: 'adjective', chinese: '未解决的/开着的',
    work_meaning: '工单尚未关闭或解决',
    example_en: 'The ticket is still open because we are waiting for the spare part.',
    example_cn: '工单仍然开着，因为我们在等备件。',
    collocations: ['still open', 'open a ticket', 'open ticket', 'close the ticket'],
    confusable: [{word: 'happen', diff: 'happen是发生，open是打开/未解决'}, {word: 'opine', diff: 'opine是发表意见，open是打开'}],
    work_context: '工单处理', related_expression: 'ki-013',
    acceptable_answers: ['open', 'opens', 'opened', 'opening'], work_relevance: 5, difficulty: 1, day: 3, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-024', word: 'close', lemma: 'close', pos: 'verb', chinese: '关闭/结案',
    work_meaning: '将工单标记为已解决并关闭',
    example_en: 'We can close the ticket once the owner confirms the repair.',
    example_cn: '业主确认维修后我们就可以关闭工单。',
    collocations: ['close the ticket', 'close the case', 'be closed', 'mark as closed'],
    confusable: [{word: 'clause', diff: 'clause是条款，close是关闭'}, {word: 'clothes', diff: 'clothes是衣服，close是关闭'}],
    work_context: '工单处理', related_expression: 'ki-007',
    acceptable_answers: ['close', 'closes', 'closed', 'closing'], work_relevance: 5, difficulty: 1, day: 3, scenario_id: 'sc-ticket'
  },

  // --- Day 4: Time & Data Basics (7 words) ---
  {
    id: 'v-025', word: 'rate', lemma: 'rate', pos: 'noun', chinese: '比率',
    work_meaning: '用于衡量工作效率的百分比或比例',
    example_en: 'The completion rate for this week is eighty-five percent.',
    example_cn: '本周的完成率是85%。',
    collocations: ['completion rate', 'resolution rate', 'rate of', 'at a rate of'],
    confusable: [{word: 'ratio', diff: 'ratio是比例（两个数的比），rate是比率/速率'}, {word: 'late', diff: 'late是迟的，rate是比率'}],
    work_context: '数据汇报', related_expression: 'ki-017',
    acceptable_answers: ['rate', 'rates'], work_relevance: 5, difficulty: 1, day: 4, scenario_id: 'sc-data'
  },
  {
    id: 'v-026', word: 'increase', lemma: 'increase', pos: 'verb', chinese: '增加',
    work_meaning: '数量或比率上升',
    example_en: 'The ticket volume increased by ten percent compared to last month.',
    example_cn: '与上月相比，工单量增加了10%。',
    collocations: ['increase by', 'increase significantly', 'an increase of', 'increased compared to'],
    confusable: [{word: 'decrease', diff: 'decrease是减少，increase是增加'}, {word: 'instance', diff: 'instance是例子/实例，increase是增加'}],
    work_context: '数据汇报', related_expression: 'ki-016',
    acceptable_answers: ['increase', 'increases', 'increased', 'increasing'], work_relevance: 5, difficulty: 1, day: 4, scenario_id: 'sc-data'
  },
  {
    id: 'v-027', word: 'decrease', lemma: 'decrease', pos: 'verb', chinese: '减少',
    work_meaning: '数量或比率下降',
    example_en: 'The three-day resolution rate has decreased by eight percent.',
    example_cn: '三日解决率下降了8%。',
    collocations: ['decrease by', 'decrease significantly', 'a decrease of', 'decreased compared to'],
    confusable: [{word: 'increase', diff: 'increase是增加，decrease是减少'}, {word: 'disease', diff: 'disease是疾病，decrease是减少'}],
    work_context: '数据汇报', related_expression: 'ki-016',
    acceptable_answers: ['decrease', 'decreases', 'decreased', 'decreasing'], work_relevance: 5, difficulty: 1, day: 4, scenario_id: 'sc-data'
  },
  {
    id: 'v-028', word: 'compare', lemma: 'compare', pos: 'verb', chinese: '比较',
    work_meaning: '将当前数据与之前的数据对照',
    example_en: 'Compared to last week, our completion rate has improved.',
    example_cn: '与上周相比，我们的完成率有所提升。',
    collocations: ['compared to', 'compare with', 'in comparison', 'comparison to'],
    confusable: [{word: 'compose', diff: 'compose是组成，compare是比较'}, {word: 'company', diff: 'company是公司，compare是比较'}],
    work_context: '数据汇报', related_expression: 'ki-015',
    acceptable_answers: ['compare', 'compares', 'compared', 'comparing'], work_relevance: 5, difficulty: 1, day: 4, scenario_id: 'sc-data'
  },
  {
    id: 'v-029', word: 'volume', lemma: 'volume', pos: 'noun', chinese: '数量/量',
    work_meaning: '工单或业务的总数量',
    example_en: 'In terms of ticket volume, we received fifty-two this week.',
    example_cn: '就工单量而言，我们本周收到了52个。',
    collocations: ['ticket volume', 'high volume', 'volume of', 'in terms of volume'],
    confusable: [{word: 'value', diff: 'value是价值，volume是量/音量'}, {word: 'volunteer', diff: 'volunteer是志愿者，volume是量'}],
    work_context: '数据汇报', related_expression: 'ki-015',
    acceptable_answers: ['volume', 'volumes'], work_relevance: 4, difficulty: 1, day: 4, scenario_id: 'sc-data'
  },
  {
    id: 'v-030', word: 'percent', lemma: 'percent', pos: 'noun', chinese: '百分比',
    work_meaning: '以百分之几表示的数据',
    example_en: 'The completion rate improved by five percent.',
    example_cn: '完成率提升了5%。',
    collocations: ['by percent', 'percent increase', 'percent decrease', 'percent of'],
    confusable: [{word: 'parent', diff: 'parent是父母，percent是百分比'}, {word: 'pervent', diff: 'pervent不是词，注意拼写'}],
    work_context: '数据汇报', related_expression: 'ki-016',
    acceptable_answers: ['percent', 'percents', 'percentage'], work_relevance: 5, difficulty: 1, day: 4, scenario_id: 'sc-data'
  },
  {
    id: 'v-031', word: 'data', lemma: 'data', pos: 'noun', chinese: '数据',
    work_meaning: '用于分析和决策的数字信息',
    example_en: 'Based on the data, our resolution rate has dropped.',
    example_cn: '根据数据，我们的解决率下降了。',
    collocations: ['based on the data', 'data shows', 'data analysis', 'data report'],
    confusable: [{word: 'date', diff: 'date是日期，data是数据'}, {word: 'duty', diff: 'duty是责任，data是数据'}],
    work_context: '数据汇报', related_expression: 'ki-004',
    acceptable_answers: ['data', 'datas', 'datum'], work_relevance: 5, difficulty: 1, day: 4, scenario_id: 'sc-data'
  },

  // --- Day 5: Explaining Delays (7 words) ---
  {
    id: 'v-032', word: 'delay', lemma: 'delay', pos: 'noun', chinese: '延迟',
    work_meaning: '工作未按原计划时间完成',
    example_en: 'There has been a delay in resolving this case.',
    example_cn: '解决这个案件出现了延迟。',
    collocations: ['a delay in', 'the main reason for the delay', 'cause a delay', 'experience a delay'],
    confusable: [{word: 'relay', diff: 'relay是转送/接力，delay是延迟'}, {word: 'delight', diff: 'delight是高兴，delay是延迟'}],
    work_context: '延迟说明', related_expression: 'ki-011',
    acceptable_answers: ['delay', 'delays', 'delayed', 'delaying'], work_relevance: 5, difficulty: 1, day: 5, scenario_id: 'sc-delay'
  },
  {
    id: 'v-033', word: 'reason', lemma: 'reason', pos: 'noun', chinese: '原因',
    work_meaning: '导致某事发生的因素',
    example_en: 'The main reason for the delay is a supply shortage.',
    example_cn: '延迟的主要原因是供应短缺。',
    collocations: ['the main reason', 'the reason why', 'for this reason', 'reason for the delay'],
    confusable: [{word: 'season', diff: 'season是季节，reason是原因'}, {word: 'treason', diff: 'treason是叛国，reason是原因'}],
    work_context: '延迟说明', related_expression: 'ki-012',
    acceptable_answers: ['reason', 'reasons'], work_relevance: 5, difficulty: 1, day: 5, scenario_id: 'sc-reason'
  },
  {
    id: 'v-034', word: 'shortage', lemma: 'shortage', pos: 'noun', chinese: '短缺',
    work_meaning: '物资或人员不足',
    example_en: 'The delay was due to a supply shortage.',
    example_cn: '延迟是由于供应短缺。',
    collocations: ['supply shortage', 'staff shortage', 'material shortage', 'a shortage of'],
    confusable: [{word: 'storage', diff: 'storage是存储，shortage是短缺'}, {word: 'shorten', diff: 'shorten是缩短，shortage是短缺'}],
    work_context: '延迟说明', related_expression: 'ki-014',
    acceptable_answers: ['shortage', 'shortages'], work_relevance: 4, difficulty: 2, day: 5, scenario_id: 'sc-delay'
  },
  {
    id: 'v-035', word: 'supply', lemma: 'supply', pos: 'noun', chinese: '供应',
    work_meaning: '提供所需物资或零件',
    example_en: 'Due to the supply issue, we cannot proceed with the repair.',
    example_cn: '由于供应问题，我们无法继续维修。',
    collocations: ['supply issue', 'supply chain', 'supply shortage', 'spare part supply'],
    confusable: [{word: 'apply', diff: 'apply是申请/应用，supply是供应'}, {word: 'imply', diff: 'imply是暗示，supply是供应'}],
    work_context: '延迟说明', related_expression: 'ki-014',
    acceptable_answers: ['supply', 'supplies', 'supplied', 'supplying'], work_relevance: 5, difficulty: 1, day: 5, scenario_id: 'sc-delay'
  },
  {
    id: 'v-036', word: 'response', lemma: 'response', pos: 'noun', chinese: '回应',
    work_meaning: '对请求或问题的回复',
    example_en: 'We are still waiting for their response.',
    example_cn: '我们仍在等待他们的回应。',
    collocations: ['waiting for a response', 'quick response', 'in response to', 'no response'],
    confusable: [{word: 'respond', diff: 'respond是动词回应，response是名词回应'}, {word: 'respect', diff: 'respect是尊重，response是回应'}],
    work_context: '延迟说明', related_expression: 'ki-018',
    acceptable_answers: ['response', 'responses'], work_relevance: 5, difficulty: 1, day: 5, scenario_id: 'sc-delay'
  },
  {
    id: 'v-037', word: 'issue', lemma: 'issue', pos: 'noun', chinese: '问题',
    work_meaning: '需要处理或解决的困难或故障',
    example_en: 'The supply issue is causing the delay.',
    example_cn: '供应问题导致了延迟。',
    collocations: ['supply issue', 'technical issue', 'raise an issue', 'address the issue'],
    confusable: [{word: 'tissue', diff: 'tissue是纸巾，issue是问题'}, {word: 'asset', diff: 'asset是资产，issue是问题'}],
    work_context: '延迟说明', related_expression: 'ki-014',
    acceptable_answers: ['issue', 'issues'], work_relevance: 5, difficulty: 1, day: 5, scenario_id: 'sc-reason'
  },
  {
    id: 'v-038', word: 'unable', lemma: 'unable', pos: 'adjective', chinese: '无法的',
    work_meaning: '没有能力或条件做某事',
    example_en: 'We are unable to proceed with the repair due to the shortage.',
    example_cn: '由于短缺，我们无法继续维修。',
    collocations: ['unable to', 'currently unable', 'unable to proceed', 'unable to complete'],
    confusable: [{word: 'enable', diff: 'enable是使能够，unable是无法'}, {word: 'stable', diff: 'stable是稳定的，unable是无法的'}],
    work_context: '延迟说明', related_expression: 'ki-011',
    acceptable_answers: ['unable'], work_relevance: 4, difficulty: 1, day: 5, scenario_id: 'sc-delay'
  },

  // --- Day 6: Explaining Reasons (7 words) ---
  {
    id: 'v-039', word: 'cause', lemma: 'cause', pos: 'verb', chinese: '导致',
    work_meaning: '使某事发生',
    example_en: 'The supply shortage caused the delay.',
    example_cn: '供应短缺导致了延迟。',
    collocations: ['cause the delay', 'caused by', 'the cause of', 'root cause'],
    confusable: [{word: 'course', diff: 'course是课程/路线，cause是原因/导致'}, {word: 'because', diff: 'because是因为（连词），cause是导致（动词）'}],
    work_context: '解释原因', related_expression: 'ki-013',
    acceptable_answers: ['cause', 'causes', 'caused', 'causing'], work_relevance: 5, difficulty: 1, day: 6, scenario_id: 'sc-reason'
  },
  {
    id: 'v-040', word: 'alternative', lemma: 'alternative', pos: 'adjective', chinese: '替代的',
    work_meaning: '可替代原方案的另一个选择',
    example_en: 'We are working on finding an alternative supplier.',
    example_cn: '我们正在寻找替代供应商。',
    collocations: ['alternative supplier', 'alternative solution', 'alternative option', 'an alternative to'],
    confusable: [{word: 'alternate', diff: 'alternate是交替的，alternative是替代的'}, {word: 'alter', diff: 'alter是改变，alternative是替代的'}],
    work_context: '解释原因', related_expression: 'ki-013',
    acceptable_answers: ['alternative', 'alternatives'], work_relevance: 4, difficulty: 2, day: 6, scenario_id: 'sc-reason'
  },
  {
    id: 'v-041', word: 'available', lemma: 'available', pos: 'adjective', chinese: '可用的',
    work_meaning: '可以获取或使用的',
    example_en: 'The original part is no longer available.',
    example_cn: '原装零件已经无法获取了。',
    collocations: ['no longer available', 'currently available', 'become available', 'available for'],
    confusable: [{word: 'valuable', diff: 'valuable是有价值的，available是可用的'}, {word: 'avoidable', diff: 'avoidable是可避免的，available是可用的'}],
    work_context: '解释原因', related_expression: 'ki-013',
    acceptable_answers: ['available'], work_relevance: 5, difficulty: 1, day: 6, scenario_id: 'sc-reason'
  },
  {
    id: 'v-042', word: 'proceed', lemma: 'proceed', pos: 'verb', chinese: '继续',
    work_meaning: '继续推进工作',
    example_en: 'We cannot proceed with the repair right now.',
    example_cn: '我们现在无法继续维修。',
    collocations: ['proceed with', 'cannot proceed', 'proceed to', 'proceed accordingly'],
    confusable: [{word: 'precede', diff: 'precede是先于/在...之前，proceed是继续'}, {word: 'process', diff: 'process是处理/过程，proceed是继续'}],
    work_context: '解释原因', related_expression: 'ki-006',
    acceptable_answers: ['proceed', 'proceeds', 'proceeded', 'proceeding'], work_relevance: 4, difficulty: 2, day: 6, scenario_id: 'sc-reason'
  },
  {
    id: 'v-043', word: 'receive', lemma: 'receive', pos: 'verb', chinese: '收到',
    work_meaning: '接到信息、物品或工单',
    example_en: 'We have not received a clear solution from the supplier yet.',
    example_cn: '我们还没有收到供应商的明确方案。',
    collocations: ['receive the ticket', 'received from', 'receive confirmation', 'have not received'],
    confusable: [{word: 'perceive', diff: 'perceive是感知，receive是收到'}, {word: 'receipt', diff: 'receipt是收据（名词），receive是收到（动词）'}],
    work_context: '解释原因', related_expression: 'ki-018',
    acceptable_answers: ['receive', 'receives', 'received', 'receiving'], work_relevance: 4, difficulty: 1, day: 6, scenario_id: 'sc-reason'
  },
  {
    id: 'v-044', word: 'part', lemma: 'part', pos: 'noun', chinese: '零件',
    work_meaning: '设备或设施的组成部件',
    example_en: 'We are waiting for the spare part to arrive.',
    example_cn: '我们在等备件到货。',
    collocations: ['spare part', 'replacement part', 'original part', 'order parts'],
    confusable: [{word: 'party', diff: 'party是派对/方，part是零件/部分'}, {word: 'depart', diff: 'depart是离开，part是部分/零件'}],
    work_context: '维修管理', related_expression: 'ki-013',
    acceptable_answers: ['part', 'parts'], work_relevance: 5, difficulty: 1, day: 6, scenario_id: 'sc-reason'
  },
  {
    id: 'v-045', word: 'arrive', lemma: 'arrive', pos: 'verb', chinese: '到达',
    work_meaning: '物品送达或时间到来',
    example_en: 'The spare part should arrive in three days.',
    example_cn: '备件应该在三天内到货。',
    collocations: ['arrive in', 'arrive by', 'expected to arrive', 'arrive on time'],
    confusable: [{word: 'arise', diff: 'arise是出现/产生，arrive是到达'}, {word: 'derive', diff: 'derive是源自，arrive是到达'}],
    work_context: '解释原因', related_expression: 'ki-013',
    acceptable_answers: ['arrive', 'arrives', 'arrived', 'arriving'], work_relevance: 4, difficulty: 1, day: 6, scenario_id: 'sc-reason'
  },

  // --- Day 7: Week 1 Review (7 words) ---
  {
    id: 'v-046', word: 'summarize', lemma: 'summarize', pos: 'verb', chinese: '总结',
    work_meaning: '简要概括工作内容或数据',
    example_en: 'To summarize, we have resolved twelve out of fifteen tickets.',
    example_cn: '总结一下，我们已解决15个工单中的12个。',
    collocations: ['to summarize', 'summarize the progress', 'let me summarize', 'in summary'],
    confusable: [{word: 'summer', diff: 'summer是夏天，summarize是总结'}, {word: 'minimize', diff: 'minimize是最小化，summarize是总结'}],
    work_context: '通用汇报', related_expression: 'ki-043',
    acceptable_answers: ['summarize', 'summarizes', 'summarized', 'summarizing'], work_relevance: 5, difficulty: 2, day: 7, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-047', word: 'overall', lemma: 'overall', pos: 'adjective', chinese: '整体的',
    work_meaning: '全部的或总体的',
    example_en: 'The overall completion rate for this week is eighty-five percent.',
    example_cn: '本周整体完成率是85%。',
    collocations: ['overall completion rate', 'overall status', 'overall progress', 'overall performance'],
    confusable: [{word: 'overhaul', diff: 'overhaul是大修，overall是整体的'}, {word: 'overcoat', diff: 'overcoat是大衣，overall是整体的'}],
    work_context: '通用汇报', related_expression: 'ki-017',
    acceptable_answers: ['overall'], work_relevance: 4, difficulty: 1, day: 7, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-048', word: 'track', lemma: 'track', pos: 'verb', chinese: '跟踪',
    work_meaning: '持续关注工单或任务的进展',
    example_en: 'We use the system to track all ticket progress.',
    example_cn: '我们使用系统跟踪所有工单进展。',
    collocations: ['track progress', 'track the ticket', 'keep track of', 'track status'],
    confusable: [{word: 'truck', diff: 'truck是卡车，track是跟踪/轨道'}, {word: 'trace', diff: 'trace是追溯，track是跟踪'}],
    work_context: '工单处理', related_expression: 'ki-001',
    acceptable_answers: ['track', 'tracks', 'tracked', 'tracking'], work_relevance: 5, difficulty: 1, day: 7, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-049', word: 'report', lemma: 'report', pos: 'verb', chinese: '汇报',
    work_meaning: '向上级或相关方说明工作情况',
    example_en: 'I need to report the current status to the manager.',
    example_cn: '我需要向经理汇报当前状态。',
    collocations: ['report to', 'report progress', 'report status', 'submit a report'],
    confusable: [{word: 'repeat', diff: 'repeat是重复，report是汇报'}, {word: 'support', diff: 'support是支持，report是汇报'}],
    work_context: '通用汇报', related_expression: 'ki-001',
    acceptable_answers: ['report', 'reports', 'reported', 'reporting'], work_relevance: 5, difficulty: 1, day: 7, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-050', word: 'situation', lemma: 'situation', pos: 'noun', chinese: '情况',
    work_meaning: '当前的事态或状态',
    example_en: 'Let me explain the situation to you.',
    example_cn: '让我向你解释一下情况。',
    collocations: ['current situation', 'explain the situation', 'the situation is', 'assess the situation'],
    confusable: [{word: 'station', diff: 'station是站点，situation是情况'}, {word: 'location', diff: 'location是位置，situation是情况'}],
    work_context: '通用汇报', related_expression: 'ki-001',
    acceptable_answers: ['situation', 'situations'], work_relevance: 4, difficulty: 1, day: 7, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-051', word: 'handle', lemma: 'handle', pos: 'verb', chinese: '处理',
    work_meaning: '管理或解决工单或问题',
    example_en: 'We are actively handling this case.',
    example_cn: '我们正在积极处理这个案件。',
    collocations: ['handle the case', 'handle the ticket', 'be handled', 'handle issues'],
    confusable: [{word: 'candle', diff: 'candle是蜡烛，handle是处理/把手'}, {word: 'hurdle', diff: 'hurdle是障碍，handle是处理'}],
    work_context: '工单处理', related_expression: 'ki-003',
    acceptable_answers: ['handle', 'handles', 'handled', 'handling'], work_relevance: 5, difficulty: 1, day: 7, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-052', word: 'manage', lemma: 'manage', pos: 'verb', chinese: '管理',
    work_meaning: '负责控制和推进工作',
    example_en: 'We need to manage these tickets more efficiently.',
    example_cn: '我们需要更高效地管理这些工单。',
    collocations: ['manage tickets', 'manage the process', 'manage expectations', 'manage the timeline'],
    confusable: [{word: 'damage', diff: 'damage是损坏，manage是管理'}, {word: 'image', diff: 'image是图像，manage是管理'}],
    work_context: '通用汇报', related_expression: 'ki-001',
    acceptable_answers: ['manage', 'manages', 'managed', 'managing'], work_relevance: 4, difficulty: 1, day: 7, scenario_id: 'sc-reporting'
  },

  // ============================================================
  // WEEK 2 (Days 8-14): Data reporting, follow-ups, next steps, confirming owners
  // ============================================================

  // --- Day 8: Reporting Data Changes (8 words) ---
  {
    id: 'v-053', word: 'figure', lemma: 'figure', pos: 'noun', chinese: '数字',
    work_meaning: '具体的数值或数据',
    example_en: 'The current figure is not directly comparable with last year.',
    example_cn: '当前数字与去年不可直接比较。',
    collocations: ['the current figure', 'exact figure', 'figure shows', 'in the figure'],
    confusable: [{word: 'finger', diff: 'finger是手指，figure是数字/图形'}, {word: 'feature', diff: 'feature是特征，figure是数字'}],
    work_context: '数据汇报', related_expression: 'ki-053',
    acceptable_answers: ['figure', 'figures'], work_relevance: 4, difficulty: 2, day: 8, scenario_id: 'sc-data'
  },
  {
    id: 'v-054', word: 'drop', lemma: 'drop', pos: 'verb', chinese: '下降',
    work_meaning: '数据或指标降低',
    example_en: 'The three-day resolution rate has dropped by eight percent.',
    example_cn: '三日解决率下降了8%。',
    collocations: ['drop by', 'dropped significantly', 'a drop in', 'drop from to'],
    confusable: [{word: 'drip', diff: 'drip是滴水，drop是下降/掉落'}, {word: 'drown', diff: 'drown是淹没，drop是下降'}],
    work_context: '数据汇报', related_expression: 'ki-016',
    acceptable_answers: ['drop', 'drops', 'dropped', 'dropping'], work_relevance: 5, difficulty: 1, day: 8, scenario_id: 'sc-data'
  },
  {
    id: 'v-055', word: 'improve', lemma: 'improve', pos: 'verb', chinese: '提升',
    work_meaning: '使数据或绩效变好',
    example_en: 'Our completion rate has improved by five percent.',
    example_cn: '我们的完成率提升了5%。',
    collocations: ['improve by', 'improve significantly', 'improved compared to', 'room to improve'],
    confusable: [{word: 'prove', diff: 'prove是证明，improve是提升'}, {word: 'approve', diff: 'approve是批准，improve是提升'}],
    work_context: '数据汇报', related_expression: 'ki-016',
    acceptable_answers: ['improve', 'improves', 'improved', 'improving'], work_relevance: 5, difficulty: 1, day: 8, scenario_id: 'sc-data'
  },
  {
    id: 'v-056', word: 'baseline', lemma: 'baseline', pos: 'noun', chinese: '基准',
    work_meaning: '用于比较的初始数据或标准',
    example_en: 'We need a comparable baseline before setting the target.',
    example_cn: '在设定目标前，我们需要一个可比较的基准。',
    collocations: ['comparable baseline', 'set a baseline', 'use as baseline', 'baseline data'],
    confusable: [{word: 'lifeline', diff: 'lifeline是生命线，baseline是基准'}, {word: 'deadline', diff: 'deadline是截止时间，baseline是基准'}],
    work_context: '数据汇报', related_expression: 'ki-052',
    acceptable_answers: ['baseline', 'baselines'], work_relevance: 4, difficulty: 2, day: 8, scenario_id: 'sc-data'
  },
  {
    id: 'v-057', word: 'target', lemma: 'target', pos: 'noun', chinese: '目标',
    work_meaning: '需要达到的指标或数值',
    example_en: 'The target for August is set at 110 consultations per 10,000 units.',
    example_cn: '八月的目标定为每万台110次咨询。',
    collocations: ['set a target', 'meet the target', 'target for', 'exceed the target'],
    confusable: [{word: 'ticket', diff: 'ticket是工单，target是目标'}, {word: 'market', diff: 'market是市场，target是目标'}],
    work_context: '数据汇报', related_expression: 'ki-057',
    acceptable_answers: ['target', 'targets'], work_relevance: 5, difficulty: 2, day: 8, scenario_id: 'sc-data'
  },
  {
    id: 'v-058', word: 'comparable', lemma: 'comparable', pos: 'adjective', chinese: '可比较的',
    work_meaning: '数据口径一致可以进行对比',
    example_en: 'The current figure is not directly comparable with last year.',
    example_cn: '当前数据与去年不可直接比较。',
    collocations: ['comparable with', 'comparable to', 'not directly comparable', 'comparable baseline'],
    confusable: [{word: 'comfortable', diff: 'comfortable是舒适的，comparable是可比较的'}, {word: 'considerable', diff: 'considerable是相当大的，comparable是可比较的'}],
    work_context: '数据汇报', related_expression: 'ki-053',
    acceptable_answers: ['comparable'], work_relevance: 4, difficulty: 2, day: 8, scenario_id: 'sc-data'
  },
  {
    id: 'v-059', word: 'metric', lemma: 'metric', pos: 'noun', chinese: '指标',
    work_meaning: '衡量工作绩效的量化标准',
    example_en: 'Let me clarify how this metric is calculated.',
    example_cn: '让我说明一下这个指标是怎么计算的。',
    collocations: ['this metric', 'key metrics', 'metric is calculated', 'performance metric'],
    confusable: [{word: 'matrix', diff: 'matrix是矩阵，metric是指标'}, {word: 'method', diff: 'method是方法，metric是指标'}],
    work_context: '数据汇报', related_expression: 'ki-051',
    acceptable_answers: ['metric', 'metrics'], work_relevance: 5, difficulty: 2, day: 8, scenario_id: 'sc-data'
  },
  {
    id: 'v-060', word: 'trend', lemma: 'trend', pos: 'noun', chinese: '趋势',
    work_meaning: '数据随时间变化的方向',
    example_en: 'The trend shows a steady decline over the past three weeks.',
    example_cn: '趋势显示过去三周持续下降。',
    collocations: ['upward trend', 'downward trend', 'show a trend', 'trend analysis'],
    confusable: [{word: 'tend', diff: 'tend是倾向于，trend是趋势'}, {word: 'trade', diff: 'trade是贸易，trend是趋势'}],
    work_context: '数据汇报', related_expression: 'ki-016',
    acceptable_answers: ['trend', 'trends'], work_relevance: 4, difficulty: 2, day: 8, scenario_id: 'sc-data'
  },

  // --- Day 9: Answering Follow-up Questions (7 words) ---
  {
    id: 'v-061', word: 'clarify', lemma: 'clarify', pos: 'verb', chinese: '澄清',
    work_meaning: '使意思更清楚明确',
    example_en: 'Let me clarify what I mean by that.',
    example_cn: '让我澄清一下我那句话的意思。',
    collocations: ['let me clarify', 'clarify the reason', 'clarify the situation', 'need to clarify'],
    confusable: [{word: 'classify', diff: 'classify是分类，clarify是澄清'}, {word: 'clear', diff: 'clear是清楚的（形容词），clarify是澄清（动词）'}],
    work_context: '回答追问', related_expression: 'ki-019',
    acceptable_answers: ['clarify', 'clarifies', 'clarified', 'clarifying'], work_relevance: 5, difficulty: 2, day: 9, scenario_id: 'sc-followup'
  },
  {
    id: 'v-062', word: 'specific', lemma: 'specific', pos: 'adjective', chinese: '具体的',
    work_meaning: '明确和详细的',
    example_en: 'To be more specific, three tickets required special parts.',
    example_cn: '更具体地说，有三个工单需要特殊零件。',
    collocations: ['to be more specific', 'specific reason', 'specific tickets', 'be specific'],
    confusable: [{word: 'special', diff: 'special是特殊的，specific是具体的'}, {word: 'pacify', diff: 'pacify是安抚，specific是具体的'}],
    work_context: '回答追问', related_expression: 'ki-021',
    acceptable_answers: ['specific'], work_relevance: 5, difficulty: 2, day: 9, scenario_id: 'sc-followup'
  },
  {
    id: 'v-063', word: 'mean', lemma: 'mean', pos: 'verb', chinese: '意思是',
    work_meaning: '表达某事物的含义',
    example_en: 'What I mean is we had more complex cases this week.',
    example_cn: '我的意思是本周我们有更多复杂案件。',
    collocations: ['what I mean is', 'I mean', 'mean that', 'do you mean'],
    confusable: [{word: 'means', diff: 'means是手段/方式（名词），mean是意思（动词）'}, {word: 'moan', diff: 'moan是呻吟，mean是意思'}],
    work_context: '回答追问', related_expression: 'ki-020',
    acceptable_answers: ['mean', 'means', 'meant', 'meaning'], work_relevance: 4, difficulty: 1, day: 9, scenario_id: 'sc-followup'
  },
  {
    id: 'v-064', word: 'question', lemma: 'question', pos: 'noun', chinese: '问题',
    work_meaning: '需要回答的询问',
    example_en: 'That is a good question. Let me clarify.',
    example_cn: '这是一个好问题。让我澄清一下。',
    collocations: ['good question', 'answer the question', 'follow-up question', 'raise a question'],
    confusable: [{word: 'quest', diff: 'quest是探索，question是问题'}, {word: 'suggestion', diff: 'suggestion是建议，question是问题'}],
    work_context: '回答追问', related_expression: 'ki-019',
    acceptable_answers: ['question', 'questions'], work_relevance: 5, difficulty: 1, day: 9, scenario_id: 'sc-followup'
  },
  {
    id: 'v-065', word: 'explain', lemma: 'explain', pos: 'verb', chinese: '解释',
    work_meaning: '说明原因或细节',
    example_en: 'Can you explain why the rate dropped?',
    example_cn: '你能解释一下为什么比率下降了吗？',
    collocations: ['explain why', 'explain the situation', 'explain the reason', 'let me explain'],
    confusable: [{word: 'complain', diff: 'complain是抱怨，explain是解释'}, {word: 'plain', diff: 'plain是朴素的，explain是解释'}],
    work_context: '回答追问', related_expression: 'ki-019',
    acceptable_answers: ['explain', 'explains', 'explained', 'explaining'], work_relevance: 5, difficulty: 1, day: 9, scenario_id: 'sc-followup'
  },
  {
    id: 'v-066', word: 'breakdown', lemma: 'breakdown', pos: 'noun', chinese: '明细/分解',
    work_meaning: '将数据按类别拆分的详细信息',
    example_en: 'I will get back to you with the exact breakdown by this afternoon.',
    example_cn: '我会在今天下午前给你确切的明细。',
    collocations: ['exact breakdown', 'breakdown by', 'detailed breakdown', 'give a breakdown'],
    confusable: [{word: 'breakdown（故障）', diff: 'breakdown也可指设备故障，此处指数据明细'}, {word: 'break even', diff: 'break even是收支平衡，breakdown是明细'}],
    work_context: '回答追问', related_expression: 'ki-019',
    acceptable_answers: ['breakdown', 'breakdowns'], work_relevance: 4, difficulty: 2, day: 9, scenario_id: 'sc-followup'
  },
  {
    id: 'v-067', word: 'exactly', lemma: 'exactly', pos: 'adverb', chinese: '确切地',
    work_meaning: '精确无误地',
    example_en: 'I will get back to you with the exact breakdown this afternoon.',
    example_cn: '我今天下午会给你确切的明细。',
    collocations: ['exactly what', 'not exactly', 'exactly how', 'the exact number'],
    confusable: [{word: 'extent', diff: 'extent是程度，exactly是确切地'}, {word: 'extract', diff: 'extract是提取，exactly是确切地'}],
    work_context: '回答追问', related_expression: 'ki-020',
    acceptable_answers: ['exactly'], work_relevance: 3, difficulty: 1, day: 9, scenario_id: 'sc-followup'
  },

  // --- Day 10: Proposing Next Steps (7 words) ---
  {
    id: 'v-068', word: 'plan', lemma: 'plan', pos: 'noun', chinese: '计划',
    work_meaning: '接下来要做的事情安排',
    example_en: 'Our plan is to contact the supplier directly.',
    example_cn: '我们的计划是直接联系供应商。',
    collocations: ['our plan is to', 'action plan', 'contingency plan', 'have a plan'],
    confusable: [{word: 'plain', diff: 'plain是朴素的，plan是计划'}, {word: 'plant', diff: 'plant是植物/工厂，plan是计划'}],
    work_context: '下一步方案', related_expression: 'ki-022',
    acceptable_answers: ['plan', 'plans', 'planned', 'planning'], work_relevance: 5, difficulty: 1, day: 10, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-069', word: 'forward', lemma: 'forward', pos: 'adverb', chinese: '向前',
    work_meaning: '向未来推进',
    example_en: 'Moving forward, we will assign a dedicated person to each case.',
    example_cn: '接下来，我们会为每个案件分配专人。',
    collocations: ['moving forward', 'look forward to', 'step forward', 'from this point forward'],
    confusable: [{word: 'foreword', diff: 'foreword是前言，forward是向前'}, {word: 'framework', diff: 'framework是框架，forward是向前'}],
    work_context: '下一步方案', related_expression: 'ki-023',
    acceptable_answers: ['forward', 'forwards'], work_relevance: 4, difficulty: 2, day: 10, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-070', word: 'dedicated', lemma: 'dedicated', pos: 'adjective', chinese: '专门的/专用的',
    work_meaning: '为特定目的或任务设定的',
    example_en: 'We will assign a dedicated person to each high-priority case.',
    example_cn: '我们会为每个高优先级案件分配专人。',
    collocations: ['dedicated person', 'dedicated team', 'dedicated to', 'dedicated resource'],
    confusable: [{word: 'dedicate', diff: 'dedicate是动词奉献，dedicated是形容词专门的'}, {word: 'medicated', diff: 'medicated是含药的，dedicated是专门的'}],
    work_context: '下一步方案', related_expression: 'ki-023',
    acceptable_answers: ['dedicated'], work_relevance: 4, difficulty: 2, day: 10, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-071', word: 'priority', lemma: 'priority', pos: 'noun', chinese: '优先级',
    work_meaning: '任务紧急或重要的程度排序',
    example_en: 'We will assign a dedicated person to each high-priority case.',
    example_cn: '我们会为每个高优先级案件分配专人。',
    collocations: ['high priority', 'top priority', 'set priorities', 'priority case'],
    confusable: [{word: 'society', diff: 'society是社会，priority是优先级'}, {word: 'prior', diff: 'prior是先前的，priority是优先级'}],
    work_context: '下一步方案', related_expression: 'ki-022',
    acceptable_answers: ['priority', 'priorities'], work_relevance: 5, difficulty: 2, day: 10, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-072', word: 'contact', lemma: 'contact', pos: 'verb', chinese: '联系',
    work_meaning: '与某人沟通以获取信息或协助',
    example_en: 'Our next step is to contact the supplier directly.',
    example_cn: '我们的下一步是直接联系供应商。',
    collocations: ['contact the supplier', 'contact directly', 'contact information', 'get in contact'],
    confusable: [{word: 'contract', diff: 'contract是合同，contact是联系'}, {word: 'content', diff: 'content是内容，contact是联系'}],
    work_context: '下一步方案', related_expression: 'ki-022',
    acceptable_answers: ['contact', 'contacts', 'contacted', 'contacting'], work_relevance: 5, difficulty: 1, day: 10, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-073', word: 'directly', lemma: 'directly', pos: 'adverb', chinese: '直接地',
    work_meaning: '不经过中间环节',
    example_en: 'We will contact the supplier directly for a faster delivery.',
    example_cn: '我们将直接联系供应商以加快交付。',
    collocations: ['contact directly', 'directly to', 'report directly', 'go directly'],
    confusable: [{word: 'directory', diff: 'directory是目录，directly是直接地'}, {word: 'direct', diff: 'direct是直接（形容词），directly是直接地（副词）'}],
    work_context: '下一步方案', related_expression: 'ki-022',
    acceptable_answers: ['directly'], work_relevance: 4, difficulty: 1, day: 10, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-074', word: 'deliver', lemma: 'deliver', pos: 'verb', chinese: '交付',
    work_meaning: '将物品或服务送到',
    example_en: 'We requested a faster delivery from the supplier.',
    example_cn: '我们向供应商要求了更快的交付。',
    collocations: ['faster delivery', 'deliver the part', 'delivery time', 'on-time delivery'],
    confusable: [{word: 'delete', diff: 'delete是删除，deliver是交付'}, {word: 'river', diff: 'river是河流，deliver是交付'}],
    work_context: '下一步方案', related_expression: 'ki-024',
    acceptable_answers: ['deliver', 'delivers', 'delivered', 'delivering'], work_relevance: 4, difficulty: 2, day: 10, scenario_id: 'sc-nextstep'
  },

  // --- Day 11: Requesting Help (7 words) ---
  {
    id: 'v-075', word: 'support', lemma: 'support', pos: 'noun', chinese: '支持/协助',
    work_meaning: '帮助或资源上的支援',
    example_en: 'I need your support on getting the budget approved.',
    example_cn: '我需要你在预算审批上的支持。',
    collocations: ['need your support', 'support on', 'provide support', 'technical support'],
    confusable: [{word: 'supply', diff: 'supply是供应，support是支持'}, {word: 'report', diff: 'report是汇报，support是支持'}],
    work_context: '请求协助', related_expression: 'ki-025',
    acceptable_answers: ['support', 'supports', 'supported', 'supporting'], work_relevance: 5, difficulty: 1, day: 11, scenario_id: 'sc-request-help'
  },
  {
    id: 'v-076', word: 'help', lemma: 'help', pos: 'noun', chinese: '帮助',
    work_meaning: '请求他人协助完成工作',
    example_en: 'Could you help me with the owner communication?',
    example_cn: '你能帮我处理业主沟通吗？',
    collocations: ['help with', 'could you help', 'need help', 'help me out'],
    confusable: [{word: 'hope', diff: 'hope是希望，help是帮助'}, {word: 'held', diff: 'held是hold的过去式，help是帮助'}],
    work_context: '请求协助', related_expression: 'ki-025',
    acceptable_answers: ['help', 'helps', 'helped', 'helping'], work_relevance: 5, difficulty: 1, day: 11, scenario_id: 'sc-request-help'
  },
  {
    id: 'v-077', word: 'personally', lemma: 'personally', pos: 'adverb', chinese: '亲自',
    work_meaning: '自己直接处理而非委托他人',
    example_en: 'I will personally follow up on this.',
    example_cn: '我会亲自跟进这件事。',
    collocations: ['personally follow up', 'personally handle', 'personally check', 'I personally'],
    confusable: [{word: 'personal', diff: 'personal是个人的（形容词），personally是亲自地（副词）'}, {word: 'personnel', diff: 'personnel是人员，personally是亲自地'}],
    work_context: '请求协助', related_expression: 'ki-030',
    acceptable_answers: ['personally'], work_relevance: 4, difficulty: 2, day: 11, scenario_id: 'sc-request-help'
  },
  {
    id: 'v-078', word: 'follow up', lemma: 'follow up', pos: 'phrasal verb', chinese: '跟进',
    work_meaning: '持续追踪某事的进展',
    example_en: 'I will personally follow up on this case.',
    example_cn: '我会亲自跟进这个案件。',
    collocations: ['follow up on', 'personally follow up', 'follow up with', 'keep following up'],
    confusable: [{word: 'follow', diff: 'follow是跟随，follow up是跟进（含义更具体）'}, {word: 'fill out', diff: 'fill out是填写，follow up是跟进'}],
    work_context: '请求协助', related_expression: 'ki-030',
    acceptable_answers: ['follow up', 'follow-up', 'follows up', 'followed up', 'following up'], work_relevance: 5, difficulty: 2, day: 11, scenario_id: 'sc-request-help'
  },
  {
    id: 'v-079', word: 'reach out', lemma: 'reach out', pos: 'phrasal verb', chinese: '联系',
    work_meaning: '主动与某人取得联系',
    example_en: 'I need your support on reaching out to them.',
    example_cn: '我需要你帮忙联系他们。',
    collocations: ['reach out to', 'reach out for', 'reaching out', 'reach out directly'],
    confusable: [{word: 'reach', diff: 'reach是到达，reach out是主动联系'}, {word: 'read out', diff: 'read out是朗读，reach out是联系'}],
    work_context: '请求协助', related_expression: 'ki-025',
    acceptable_answers: ['reach out', 'reaches out', 'reached out', 'reaching out'], work_relevance: 4, difficulty: 2, day: 11, scenario_id: 'sc-request-help'
  },
  {
    id: 'v-080', word: 'coordinate', lemma: 'coordinate', pos: 'verb', chinese: '协调',
    work_meaning: '安排多方配合完成工作',
    example_en: 'We need to coordinate with the maintenance team on the schedule.',
    example_cn: '我们需要与维修团队协调时间安排。',
    collocations: ['coordinate with', 'coordinate the schedule', 'coordinate efforts', 'coordinate between'],
    confusable: [{word: 'cooperate', diff: 'cooperate是合作，coordinate是协调'}, {word: 'corporate', diff: 'corporate是公司的，coordinate是协调'}],
    work_context: '请求协助', related_expression: 'ki-026',
    acceptable_answers: ['coordinate', 'coordinates', 'coordinated', 'coordinating'], work_relevance: 4, difficulty: 2, day: 11, scenario_id: 'sc-request-help'
  },
  {
    id: 'v-081', word: 'assist', lemma: 'assist', pos: 'verb', chinese: '协助',
    work_meaning: '帮助或支援某人完成任务',
    example_en: 'Could you assist me with the owner communication?',
    example_cn: '你能协助我处理业主沟通吗？',
    collocations: ['assist with', 'assist in', 'please assist', 'assist the team'],
    confusable: [{word: 'insist', diff: 'insist是坚持，assist是协助'}, {word: 'resist', diff: 'resist是抵抗，assist是协助'}],
    work_context: '请求协助', related_expression: 'ki-025',
    acceptable_answers: ['assist', 'assists', 'assisted', 'assisting'], work_relevance: 4, difficulty: 2, day: 11, scenario_id: 'sc-request-help'
  },

  // --- Day 12: Owner Communication (7 words) ---
  {
    id: 'v-082', word: 'concern', lemma: 'concern', pos: 'noun', chinese: '担忧',
    work_meaning: '业主或相关方的不满或担心',
    example_en: 'I understand your concern about the delay.',
    example_cn: '我理解您对延迟的担忧。',
    collocations: ['understand your concern', 'address the concern', 'raise a concern', 'express concern'],
    confusable: [{word: 'concert', diff: 'concert是音乐会，concern是担忧'}, {word: 'confirm', diff: 'confirm是确认，concern是担忧'}],
    work_context: '业主沟通', related_expression: 'ki-027',
    acceptable_answers: ['concern', 'concerns'], work_relevance: 5, difficulty: 2, day: 12, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-083', word: 'apologize', lemma: 'apologize', pos: 'verb', chinese: '道歉',
    work_meaning: '对给业主造成的不便表示歉意',
    example_en: 'We apologize for the inconvenience caused.',
    example_cn: '我们对造成的不便深表歉意。',
    collocations: ['apologize for', 'we apologize for', 'apologize for the inconvenience', 'sincerely apologize'],
    confusable: [{word: 'apply', diff: 'apply是申请/应用，apologize是道歉'}, {word: 'appall', diff: 'appall是使惊骇，apologize是道歉'}],
    work_context: '业主沟通', related_expression: 'ki-028',
    acceptable_answers: ['apologize', 'apologizes', 'apologized', 'apologizing'], work_relevance: 5, difficulty: 2, day: 12, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-084', word: 'inconvenience', lemma: 'inconvenience', pos: 'noun', chinese: '不便',
    work_meaning: '给业主带来的麻烦或困扰',
    example_en: 'We apologize for the inconvenience caused by the delay.',
    example_cn: '我们对延迟造成的不便深表歉意。',
    collocations: ['apologize for the inconvenience', 'cause inconvenience', 'sorry for the inconvenience', 'inconvenience caused'],
    confusable: [{word: 'convenience', diff: 'convenience是便利，inconvenience是不便'}, {word: 'inconvenient', diff: 'inconvenient是不方便的（形容词），inconvenience是不便（名词）'}],
    work_context: '业主沟通', related_expression: 'ki-028',
    acceptable_answers: ['inconvenience', 'inconveniences'], work_relevance: 5, difficulty: 2, day: 12, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-085', word: 'understand', lemma: 'understand', pos: 'verb', chinese: '理解',
    work_meaning: '表示对业主感受的认同',
    example_en: 'I understand your concern about the delay.',
    example_cn: '我理解您对延迟的担忧。',
    collocations: ['understand your concern', 'I understand', 'understand the situation', 'understand the issue'],
    confusable: [{word: 'underestimate', diff: 'underestimate是低估，understand是理解'}, {word: 'undermine', diff: 'undermine是破坏，understand是理解'}],
    work_context: '业主沟通', related_expression: 'ki-027',
    acceptable_answers: ['understand', 'understands', 'understood', 'understanding'], work_relevance: 5, difficulty: 1, day: 12, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-086', word: 'commit', lemma: 'commit', pos: 'verb', chinese: '承诺',
    work_meaning: '保证完成某事',
    example_en: 'We commit to resolving this by Friday.',
    example_cn: '我们承诺在周五前解决。',
    collocations: ['commit to', 'commit to resolving', 'committed to', 'make a commitment'],
    confusable: [{word: 'submit', diff: 'submit是提交，commit是承诺'}, {word: 'permit', diff: 'permit是允许，commit是承诺'}],
    work_context: '业主沟通', related_expression: 'ki-027',
    acceptable_answers: ['commit', 'commits', 'committed', 'committing'], work_relevance: 4, difficulty: 2, day: 12, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-087', word: 'feedback', lemma: 'feedback', pos: 'noun', chinese: '反馈',
    work_meaning: '业主或上级对工作的意见',
    example_en: 'We have received positive feedback from the owner.',
    example_cn: '我们收到了业主的积极反馈。',
    collocations: ['receive feedback', 'positive feedback', 'feedback from', 'provide feedback'],
    confusable: [{word: 'feed', diff: 'feed是喂养，feedback是反馈'}, {word: 'fallback', diff: 'fallback是兜底，feedback是反馈'}],
    work_context: '业主沟通', related_expression: 'ki-028',
    acceptable_answers: ['feedback'], work_relevance: 4, difficulty: 2, day: 12, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-088', word: 'promise', lemma: 'promise', pos: 'verb', chinese: '保证',
    work_meaning: '向业主保证会做到某事',
    example_en: 'I promise to get back to you by tomorrow.',
    example_cn: '我保证明天前给您回复。',
    collocations: ['promise to', 'make a promise', 'I promise', 'keep the promise'],
    confusable: [{word: 'premise', diff: 'premise是前提，promise是保证'}, {word: 'compromise', diff: 'compromise是妥协，promise是保证'}],
    work_context: '业主沟通', related_expression: 'ki-027',
    acceptable_answers: ['promise', 'promises', 'promised', 'promising'], work_relevance: 4, difficulty: 1, day: 12, scenario_id: 'sc-owner-comm'
  },

  // --- Day 13: Data Reporting Practice (7 words) ---
  {
    id: 'v-089', word: 'break down', lemma: 'break down', pos: 'phrasal verb', chinese: '拆分',
    work_meaning: '将数据按类别或维度细分',
    example_en: 'Could we break this down by scenario?',
    example_cn: '我们能按场景拆分一下吗？',
    collocations: ['break down by', 'break down into', 'break this down', 'break it down'],
    confusable: [{word: 'breakdown', diff: 'breakdown是名词明细，break down是动词拆分'}, {word: 'break up', diff: 'break up是分手/拆散，break down是拆分/故障'}],
    work_context: '数据汇报', related_expression: 'ki-054',
    acceptable_answers: ['break down', 'breaks down', 'broke down', 'breaking down'], work_relevance: 4, difficulty: 2, day: 13, scenario_id: 'sc-data'
  },
  {
    id: 'v-090', word: 'scenario', lemma: 'scenario', pos: 'noun', chinese: '场景',
    work_meaning: '特定的工作情况或类型',
    example_en: 'Could we break this down by scenario?',
    example_cn: '我们能按场景拆分一下吗？',
    collocations: ['by scenario', 'different scenario', 'specific scenario', 'in this scenario'],
    confusable: [{word: 'scenery', diff: 'scenery是风景，scenario是场景'}, {word: 'scheme', diff: 'scheme是方案，scenario是场景'}],
    work_context: '数据汇报', related_expression: 'ki-054',
    acceptable_answers: ['scenario', 'scenarios'], work_relevance: 4, difficulty: 2, day: 13, scenario_id: 'sc-data'
  },
  {
    id: 'v-091', word: 'walk through', lemma: 'walk through', pos: 'phrasal verb', chinese: '逐步讲解',
    work_meaning: '逐步展示或说明数据',
    example_en: 'Let me walk you through the numbers.',
    example_cn: '让我带你过一遍这些数字。',
    collocations: ['walk you through', 'walk through the numbers', 'walk through the data', 'let me walk you through'],
    confusable: [{word: 'walk', diff: 'walk是走路，walk through是逐步讲解'}, {word: 'work through', diff: 'work through是逐步解决，walk through是逐步讲解'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['walk through', 'walks through', 'walked through', 'walking through'], work_relevance: 4, difficulty: 2, day: 13, scenario_id: 'sc-data'
  },
  {
    id: 'v-092', word: 'number', lemma: 'number', pos: 'noun', chinese: '数字',
    work_meaning: '具体的数据值',
    example_en: 'The overall number is misleading without context.',
    example_cn: '没有上下文，总体数字是有误导性的。',
    collocations: ['the numbers', 'exact number', 'overall number', 'in numbers'],
    confusable: [{word: 'lumber', diff: 'lumber是木材，number是数字'}, {word: 'slumber', diff: 'slumber是睡眠，number是数字'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['number', 'numbers'], work_relevance: 4, difficulty: 1, day: 13, scenario_id: 'sc-data'
  },
  {
    id: 'v-093', word: 'misleading', lemma: 'misleading', pos: 'adjective', chinese: '误导性的',
    work_meaning: '数据表面看起来与实际不符',
    example_en: 'The overall number is misleading without context.',
    example_cn: '没有上下文，总体数字是有误导性的。',
    collocations: ['misleading number', 'misleading data', 'misleading figure', 'be misleading'],
    confusable: [{word: 'leading', diff: 'leading是领先的，misleading是误导性的'}, {word: 'mistake', diff: 'mistake是错误，misleading是误导性的'}],
    work_context: '数据汇报', related_expression: 'ki-054',
    acceptable_answers: ['misleading'], work_relevance: 3, difficulty: 3, day: 13, scenario_id: 'sc-data'
  },
  {
    id: 'v-094', word: 'segment', lemma: 'segment', pos: 'verb', chinese: '分段/分层',
    work_meaning: '将数据按维度切分分析',
    example_en: 'Let us segment the data by use case.',
    example_cn: '让我们按使用场景来分段分析数据。',
    collocations: ['segment by', 'segment the data', 'segment into', 'market segment'],
    confusable: [{word: 'augment', diff: 'augment是增加，segment是分段'}, {word: 'moment', diff: 'moment是时刻，segment是分段'}],
    work_context: '数据汇报', related_expression: 'ki-054',
    acceptable_answers: ['segment', 'segments', 'segmented', 'segmenting'], work_relevance: 3, difficulty: 3, day: 13, scenario_id: 'sc-data'
  },
  {
    id: 'v-095', word: 'analyze', lemma: 'analyze', pos: 'verb', chinese: '分析',
    work_meaning: '深入研究数据以发现规律或原因',
    example_en: 'We need to analyze the data to find the root cause.',
    example_cn: '我们需要分析数据以找到根本原因。',
    collocations: ['analyze the data', 'analyze the reason', 'analyze the trend', 'analyze by'],
    confusable: [{word: 'analysis', diff: 'analysis是名词分析，analyze是动词分析'}, {word: 'utilize', diff: 'utilize是利用，analyze是分析'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['analyze', 'analyzes', 'analyzed', 'analyzing'], work_relevance: 5, difficulty: 2, day: 13, scenario_id: 'sc-data'
  },

  // --- Day 14: Week 2 Review (7 words) ---
  {
    id: 'v-096', word: 'comprehensive', lemma: 'comprehensive', pos: 'adjective', chinese: '全面的',
    work_meaning: '涵盖所有方面的',
    example_en: 'Let me give you a comprehensive summary of this week.',
    example_cn: '让我给你一个本周的全面总结。',
    collocations: ['comprehensive summary', 'comprehensive report', 'comprehensive review', 'comprehensive analysis'],
    confusable: [{word: 'comprehend', diff: 'comprehend是理解，comprehensive是全面的'}, {word: 'apprehensive', diff: 'apprehensive是忧虑的，comprehensive是全面的'}],
    work_context: '通用汇报', related_expression: 'ki-049',
    acceptable_answers: ['comprehensive'], work_relevance: 4, difficulty: 2, day: 14, scenario_id: 'sc-data'
  },
  {
    id: 'v-097', word: 'highlight', lemma: 'highlight', pos: 'verb', chinese: '强调/突出',
    work_meaning: '特别指出重要信息',
    example_en: 'Let me highlight the key changes from last week.',
    example_cn: '让我强调一下与上周相比的关键变化。',
    collocations: ['highlight the key', 'highlight the issue', 'highlight that', 'let me highlight'],
    confusable: [{word: 'highland', diff: 'highland是高地，highlight是强调'}, {word: 'light', diff: 'light是光/灯，highlight是强调'}],
    work_context: '通用汇报', related_expression: 'ki-049',
    acceptable_answers: ['highlight', 'highlights', 'highlighted', 'highlighting'], work_relevance: 4, difficulty: 2, day: 14, scenario_id: 'sc-data'
  },
  {
    id: 'v-098', word: 'key', lemma: 'key', pos: 'adjective', chinese: '关键的',
    work_meaning: '最重要的或核心的',
    example_en: 'Let me highlight the key changes from last week.',
    example_cn: '让我强调一下与上周相比的关键变化。',
    collocations: ['key changes', 'key findings', 'key metrics', 'key takeaway'],
    confusable: [{word: 'keys', diff: 'keys是钥匙（复数），key是关键的'}, {word: 'quay', diff: 'quay是码头，key是关键的'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['key'], work_relevance: 4, difficulty: 2, day: 14, scenario_id: 'sc-data'
  },
  {
    id: 'v-099', word: 'recap', lemma: 'recap', pos: 'verb', chinese: '回顾/总结',
    work_meaning: '简要回顾之前讨论或汇报的内容',
    example_en: 'Let me recap what we have accomplished this week.',
    example_cn: '让我回顾一下本周我们完成了什么。',
    collocations: ['let me recap', 'recap the progress', 'quick recap', 'to recap'],
    confusable: [{word: 'repeat', diff: 'repeat是重复，recap是回顾总结'}, {word: 'recover', diff: 'recover是恢复，recap是回顾'}],
    work_context: '通用汇报', related_expression: 'ki-043',
    acceptable_answers: ['recap', 'recaps', 'recapped', 'recapping'], work_relevance: 4, difficulty: 2, day: 14, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-100', word: 'conclusion', lemma: 'conclusion', pos: 'noun', chinese: '结论',
    work_meaning: '分析后得出的判断',
    example_en: 'The conclusion is that we need more staff.',
    example_cn: '结论是我们需要更多人员。',
    collocations: ['the conclusion is', 'in conclusion', 'draw a conclusion', 'reach a conclusion'],
    confusable: [{word: 'exclusion', diff: 'exclusion是排除，conclusion是结论'}, {word: 'confusion', diff: 'confusion是困惑，conclusion是结论'}],
    work_context: '通用汇报', related_expression: 'ki-049',
    acceptable_answers: ['conclusion', 'conclusions'], work_relevance: 4, difficulty: 2, day: 14, scenario_id: 'sc-data'
  },
  {
    id: 'v-101', word: 'outline', lemma: 'outline', pos: 'verb', chinese: '概述',
    work_meaning: '简要说明要点或框架',
    example_en: 'Let me outline the key findings from this week.',
    example_cn: '让我概述一下本周的关键发现。',
    collocations: ['outline the key', 'outline the plan', 'brief outline', 'outline the findings'],
    confusable: [{word: 'online', diff: 'online是在线的，outline是概述'}, {word: 'underline', diff: 'underline是强调/下划线，outline是概述'}],
    work_context: '通用汇报', related_expression: 'ki-049',
    acceptable_answers: ['outline', 'outlines', 'outlined', 'outlining'], work_relevance: 4, difficulty: 2, day: 14, scenario_id: 'sc-data'
  },
  {
    id: 'v-102', word: 'takeaway', lemma: 'takeaway', pos: 'noun', chinese: '要点/收获',
    work_meaning: '从分析或讨论中得出的关键结论',
    example_en: 'The key takeaway from this week is that we need more staff.',
    example_cn: '本周的关键要点是我们需要更多人员。',
    collocations: ['key takeaway', 'main takeaway', 'the takeaway is', 'key takeaways'],
    confusable: [{word: 'take', diff: 'take是拿，takeaway是要点/收获'}, {word: 'takeout', diff: 'takeout是外卖，takeaway是要点'}],
    work_context: '通用汇报', related_expression: 'ki-049',
    acceptable_answers: ['takeaway', 'takeaways'], work_relevance: 4, difficulty: 2, day: 14, scenario_id: 'sc-data'
  },

  // ============================================================
  // WEEK 3 (Days 15-21): Requesting help, owner communication, asset management
  // ============================================================

  // --- Day 15: Repair & Replacement (8 words) ---
  {
    id: 'v-103', word: 'replace', lemma: 'replace', pos: 'verb', chinese: '更换',
    work_meaning: '用新的替代损坏的',
    example_en: 'The valve is damaged and needs to be replaced.',
    example_cn: '阀门损坏，需要更换。',
    collocations: ['needs to be replaced', 'replace the part', 'replace rather than repair', 'replace with'],
    confusable: [{word: 'replay', diff: 'replay是重播，replace是更换'}, {word: 'place', diff: 'place是放置，replace是更换'}],
    work_context: '维修与换新', related_expression: 'ki-031',
    acceptable_answers: ['replace', 'replaces', 'replaced', 'replacing'], work_relevance: 5, difficulty: 2, day: 15, scenario_id: 'sc-repair'
  },
  {
    id: 'v-104', word: 'repair', lemma: 'repair', pos: 'verb', chinese: '维修',
    work_meaning: '修复损坏的设备或设施',
    example_en: 'The repair work is currently in progress.',
    example_cn: '维修工作目前正在进行中。',
    collocations: ['repair work', 'repair the pipe', 'rather than repair', 'repair cost'],
    confusable: [{word: 'repeat', diff: 'repeat是重复，repair是维修'}, {word: 'prepare', diff: 'prepare是准备，repair是维修'}],
    work_context: '维修与换新', related_expression: 'ki-031',
    acceptable_answers: ['repair', 'repairs', 'repaired', 'repairing'], work_relevance: 5, difficulty: 2, day: 15, scenario_id: 'sc-repair'
  },
  {
    id: 'v-105', word: 'damage', lemma: 'damage', pos: 'noun', chinese: '损坏',
    work_meaning: '设备或设施的物理损伤',
    example_en: 'The pipe is damaged and has cracked in multiple places.',
    example_cn: '水管损坏，多处出现裂纹。',
    collocations: ['is damaged', 'damage assessment', 'cause damage', 'extent of damage'],
    confusable: [{word: 'manage', diff: 'manage是管理，damage是损坏'}, {word: 'image', diff: 'image是图像，damage是损坏'}],
    work_context: '维修与换新', related_expression: 'ki-031',
    acceptable_answers: ['damage', 'damages', 'damaged', 'damaging'], work_relevance: 5, difficulty: 2, day: 15, scenario_id: 'sc-repair'
  },
  {
    id: 'v-106', word: 'crack', lemma: 'crack', pos: 'verb', chinese: '裂开',
    work_meaning: '表面出现裂缝',
    example_en: 'The pipe has cracked in multiple places.',
    example_cn: '水管多处裂开了。',
    collocations: ['cracked in', 'crack in', 'hairline crack', 'crack appears'],
    confusable: [{word: 'creak', diff: 'creak是嘎吱声，crack是裂开'}, {word: 'rack', diff: 'rack是架子，crack是裂开'}],
    work_context: '维修与换新', related_expression: 'ki-031',
    acceptable_answers: ['crack', 'cracks', 'cracked', 'cracking'], work_relevance: 4, difficulty: 2, day: 15, scenario_id: 'sc-repair'
  },
  {
    id: 'v-107', word: 'recommend', lemma: 'recommend', pos: 'verb', chinese: '建议',
    work_meaning: '基于专业判断提出的方案建议',
    example_en: 'We recommend replacing the pipe rather than repairing it.',
    example_cn: '我们建议更换水管而不是维修。',
    collocations: ['recommend replacing', 'we recommend', 'recommend that', 'highly recommend'],
    confusable: [{word: 'comment', diff: 'comment是评论，recommend是建议'}, {word: 'reconnect', diff: 'reconnect是重新连接，recommend是建议'}],
    work_context: '维修与换新', related_expression: 'ki-032',
    acceptable_answers: ['recommend', 'recommends', 'recommended', 'recommending'], work_relevance: 5, difficulty: 2, day: 15, scenario_id: 'sc-repair'
  },
  {
    id: 'v-108', word: 'valve', lemma: 'valve', pos: 'noun', chinese: '阀门',
    work_meaning: '管道系统中控制流量的装置',
    example_en: 'The valve is damaged and needs to be replaced.',
    example_cn: '阀门损坏，需要更换。',
    collocations: ['damaged valve', 'replace the valve', 'shut-off valve', 'valve replacement'],
    confusable: [{word: 'value', diff: 'value是价值，valve是阀门'}, {word: 'halve', diff: 'halve是对半分，valve是阀门'}],
    work_context: '维修与换新', related_expression: 'ki-031',
    acceptable_answers: ['valve', 'valves'], work_relevance: 3, difficulty: 2, day: 15, scenario_id: 'sc-repair'
  },
  {
    id: 'v-109', word: 'spare', lemma: 'spare', pos: 'adjective', chinese: '备用的',
    work_meaning: '用于替换的备用零件',
    example_en: 'We are waiting for the spare part to arrive.',
    example_cn: '我们在等备件到货。',
    collocations: ['spare part', 'spare parts', 'spare inventory', 'order a spare'],
    confusable: [{word: 'spark', diff: 'spark是火花，spare是备用的'}, {word: 'scare', diff: 'scare是惊吓，spare是备用的'}],
    work_context: '维修与换新', related_expression: 'ki-013',
    acceptable_answers: ['spare', 'spares'], work_relevance: 4, difficulty: 2, day: 15, scenario_id: 'sc-repair'
  },
  {
    id: 'v-110', word: 'inspect', lemma: 'inspect', pos: 'verb', chinese: '检查',
    work_meaning: '实地查看设备或设施损坏情况',
    example_en: 'We need to inspect the damage before recommending a solution.',
    example_cn: '在建议方案前我们需要检查损坏情况。',
    collocations: ['inspect the damage', 'inspect the site', 'inspect the equipment', 'be inspected'],
    confusable: [{word: 'expect', diff: 'expect是期望，inspect是检查'}, {word: 'respect', diff: 'respect是尊重，inspect是检查'}],
    work_context: '维修与换新', related_expression: 'ki-032',
    acceptable_answers: ['inspect', 'inspects', 'inspected', 'inspecting'], work_relevance: 4, difficulty: 2, day: 15, scenario_id: 'sc-repair'
  },

  // --- Day 16: Timeout Handling (7 words) ---
  {
    id: 'v-111', word: 'overdue', lemma: 'overdue', pos: 'adjective', chinese: '超时的',
    work_meaning: '超过了规定的处理时间',
    example_en: 'We have three overdue tickets that need immediate attention.',
    example_cn: '我们有三个超时工单需要立即处理。',
    collocations: ['overdue ticket', 'overdue by', 'overdue items', 'become overdue'],
    confusable: [{word: 'overview', diff: 'overview是概述，overdue是超时的'}, {word: 'overdone', diff: 'overdone是过度的，overdue是超时的'}],
    work_context: '超时处理', related_expression: 'ki-033',
    acceptable_answers: ['overdue'], work_relevance: 5, difficulty: 2, day: 16, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-112', word: 'escalate', lemma: 'escalate', pos: 'verb', chinese: '升级',
    work_meaning: '将问题提交给更高层级处理',
    example_en: 'This needs to be escalated to the city operations manager.',
    example_cn: '这需要升级给城市运营经理处理。',
    collocations: ['escalate to', 'needs to be escalated', 'escalate the issue', 'escalation path'],
    confusable: [{word: 'estimate', diff: 'estimate是估计，escalate是升级'}, {word: 'escape', diff: 'escape是逃跑，escalate是升级'}],
    work_context: '超时处理', related_expression: 'ki-034',
    acceptable_answers: ['escalate', 'escalates', 'escalated', 'escalating'], work_relevance: 5, difficulty: 3, day: 16, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-113', word: 'past', lemma: 'past', pos: 'preposition', chinese: '超过',
    work_meaning: '已经过了某个时间点',
    example_en: 'This ticket is already past the deadline.',
    example_cn: '这个工单已经过了截止时间。',
    collocations: ['past the deadline', 'past due', 'past the time', 'go past'],
    confusable: [{word: 'passed', diff: 'passed是动词pass的过去式，past是介词/形容词'}, {word: 'post', diff: 'post是后/邮件，past是超过'}],
    work_context: '超时处理', related_expression: 'ki-033',
    acceptable_answers: ['past'], work_relevance: 4, difficulty: 2, day: 16, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-114', word: 'immediate', lemma: 'immediate', pos: 'adjective', chinese: '立即的',
    work_meaning: '需要马上处理的',
    example_en: 'These overdue tickets need immediate attention.',
    example_cn: '这些超时工单需要立即关注。',
    collocations: ['immediate attention', 'immediate action', 'immediate response', 'immediate need'],
    confusable: [{word: 'mediate', diff: 'mediate是调解，immediate是立即的'}, {word: 'intermediate', diff: 'intermediate是中级的，immediate是立即的'}],
    work_context: '超时处理', related_expression: 'ki-033',
    acceptable_answers: ['immediate', 'immediately'], work_relevance: 5, difficulty: 2, day: 16, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-115', word: 'attention', lemma: 'attention', pos: 'noun', chinese: '关注',
    work_meaning: '需要处理或重视的事项',
    example_en: 'These tickets need immediate attention.',
    example_cn: '这些工单需要立即关注。',
    collocations: ['need attention', 'immediate attention', 'pay attention to', 'bring to attention'],
    confusable: [{word: 'tension', diff: 'tension是紧张，attention是关注'}, {word: 'mention', diff: 'mention是提及，attention是关注'}],
    work_context: '超时处理', related_expression: 'ki-033',
    acceptable_answers: ['attention'], work_relevance: 4, difficulty: 2, day: 16, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-116', word: 'urgent', lemma: 'urgent', pos: 'adjective', chinese: '紧急的',
    work_meaning: '需要优先处理的高优先级事项',
    example_en: 'This is an urgent matter that cannot wait.',
    example_cn: '这是一件不能等待的紧急事项。',
    collocations: ['urgent matter', 'urgent request', 'urgent issue', 'highly urgent'],
    confusable: [{word: 'surgeon', diff: 'surgeon是外科医生，urgent是紧急的'}, {word: 'insurgent', diff: 'insurgent是叛乱的，urgent是紧急的'}],
    work_context: '超时处理', related_expression: 'ki-034',
    acceptable_answers: ['urgent', 'urgency'], work_relevance: 5, difficulty: 2, day: 16, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-117', word: 'exceed', lemma: 'exceed', pos: 'verb', chinese: '超过',
    work_meaning: '超过了规定的时间限制或数量',
    example_en: 'This ticket has exceeded the 48-hour resolution window.',
    example_cn: '这个工单已超过了48小时的处理时限。',
    collocations: ['exceed the deadline', 'exceeded the time', 'exceed the limit', 'exceed expectations'],
    confusable: [{word: 'succeed', diff: 'succeed是成功，exceed是超过'}, {word: 'except', diff: 'except是除了，exceed是超过'}],
    work_context: '超时处理', related_expression: 'ki-033',
    acceptable_answers: ['exceed', 'exceeds', 'exceeded', 'exceeding'], work_relevance: 4, difficulty: 2, day: 16, scenario_id: 'sc-timeout'
  },

  // --- Day 17: Fallback Plans (7 words) ---
  {
    id: 'v-118', word: 'fallback', lemma: 'fallback', pos: 'noun', chinese: '兜底方案',
    work_meaning: '主方案失败时的备用方案',
    example_en: 'As a fallback, we will provide a temporary replacement.',
    example_cn: '作为兜底方案，我们将提供临时替代品。',
    collocations: ['as a fallback', 'fallback plan', 'fallback option', 'fallback solution'],
    confusable: [{word: 'feedback', diff: 'feedback是反馈，fallback是兜底方案'}, {word: 'fall', diff: 'fall是落下，fallback是兜底'}],
    work_context: '兜底方案', related_expression: 'ki-035',
    acceptable_answers: ['fallback'], work_relevance: 5, difficulty: 3, day: 17, scenario_id: 'sc-fallback'
  },
  {
    id: 'v-119', word: 'temporary', lemma: 'temporary', pos: 'adjective', chinese: '临时的',
    work_meaning: '非永久的过渡性方案',
    example_en: 'We will provide a temporary replacement while waiting for the new part.',
    example_cn: '在等待新零件期间，我们将提供临时替代品。',
    collocations: ['temporary replacement', 'temporary solution', 'temporary arrangement', 'on a temporary basis'],
    confusable: [{word: 'temporarily', diff: 'temporarily是临时地（副词），temporary是临时的（形容词）'}, {word: 'contemporary', diff: 'contemporary是当代的，temporary是临时的'}],
    work_context: '兜底方案', related_expression: 'ki-035',
    acceptable_answers: ['temporary', 'temporarily'], work_relevance: 5, difficulty: 2, day: 17, scenario_id: 'sc-fallback'
  },
  {
    id: 'v-120', word: 'meantime', lemma: 'meantime', pos: 'noun', chinese: '同时',
    work_meaning: '在等待某事发生的过程中',
    example_en: 'In the meantime, we have arranged a temporary solution.',
    example_cn: '同时，我们已经安排了临时方案。',
    collocations: ['in the meantime', 'during the meantime', 'meantime solution', 'while in the meantime'],
    confusable: [{word: 'meanwhile', diff: 'meanwhile与in the meantime意思相同，但meanwhile是副词'}, {word: 'time', diff: 'time是时间，meantime是同时'}],
    work_context: '兜底方案', related_expression: 'ki-036',
    acceptable_answers: ['meantime'], work_relevance: 4, difficulty: 2, day: 17, scenario_id: 'sc-fallback'
  },
  {
    id: 'v-121', word: 'arrange', lemma: 'arrange', pos: 'verb', chinese: '安排',
    work_meaning: '组织或准备临时方案',
    example_en: 'We have arranged a temporary solution for the residents.',
    example_cn: '我们已经为居民安排了临时方案。',
    collocations: ['arrange a solution', 'arrange a replacement', 'arrange for', 'arrange a meeting'],
    confusable: [{word: 'range', diff: 'range是范围，arrange是安排'}, {word: 'anger', diff: 'anger是愤怒，arrange是安排'}],
    work_context: '兜底方案', related_expression: 'ki-036',
    acceptable_answers: ['arrange', 'arranges', 'arranged', 'arranging'], work_relevance: 5, difficulty: 2, day: 17, scenario_id: 'sc-fallback'
  },
  {
    id: 'v-122', word: 'backup', lemma: 'backup', pos: 'adjective', chinese: '备用的',
    work_meaning: '作为后补的',
    example_en: 'We need to build a backup supplier list.',
    example_cn: '我们需要建立备用供应商名单。',
    collocations: ['backup supplier', 'backup plan', 'backup system', 'backup option'],
    confusable: [{word: 'back up', diff: 'back up是动词短语（支持/后退），backup是形容词/名词备用'}, {word: 'setback', diff: 'setback是挫折，backup是备用'}],
    work_context: '兜底方案', related_expression: 'ki-035',
    acceptable_answers: ['backup'], work_relevance: 4, difficulty: 2, day: 17, scenario_id: 'sc-fallback'
  },
  {
    id: 'v-123', word: 'contingency', lemma: 'contingency', pos: 'noun', chinese: '应急/不测',
    work_meaning: '为可能发生的意外做的准备',
    example_en: 'We need a contingency plan in case the parts do not arrive.',
    example_cn: '我们需要一个应急方案，以防零件不到。',
    collocations: ['contingency plan', 'contingency measure', 'for contingencies', 'contingency fund'],
    confusable: [{word: 'continuity', diff: 'continuity是连续性，contingency是应急'}, {word: 'content', diff: 'content是内容，contingency是应急'}],
    work_context: '兜底方案', related_expression: 'ki-035',
    acceptable_answers: ['contingency', 'contingencies'], work_relevance: 4, difficulty: 3, day: 17, scenario_id: 'sc-fallback'
  },
  {
    id: 'v-124', word: 'while', lemma: 'while', pos: 'conjunction', chinese: '当...的时候',
    work_meaning: '表示两件事同时发生',
    example_en: 'We will provide a temporary replacement while waiting for the new part.',
    example_cn: '在等待新零件期间，我们将提供临时替代品。',
    collocations: ['while waiting', 'while we', 'in a while', 'a while ago'],
    confusable: [{word: 'whole', diff: 'whole是整个，while是当...的时候'}, {word: 'wild', diff: 'wild是野生的，while是当...的时候'}],
    work_context: '兜底方案', related_expression: 'ki-036',
    acceptable_answers: ['while'], work_relevance: 4, difficulty: 2, day: 17, scenario_id: 'sc-fallback'
  },

  // --- Day 18: SOP & Process (7 words) ---
  {
    id: 'v-125', word: 'procedure', lemma: 'procedure', pos: 'noun', chinese: '流程',
    work_meaning: '标准的工作步骤和方法',
    example_en: 'Please make sure to follow the procedure for all emergency cases.',
    example_cn: '请确保所有紧急情况都遵循流程。',
    collocations: ['follow the procedure', 'standard procedure', 'procedure for', 'sop procedure'],
    confusable: [{word: 'proceed', diff: 'proceed是继续，procedure是流程'}, {word: 'produce', diff: 'produce是生产，procedure是流程'}],
    work_context: 'SOP与流程', related_expression: 'ki-037',
    acceptable_answers: ['procedure', 'procedures'], work_relevance: 5, difficulty: 2, day: 18, scenario_id: 'sc-sop'
  },
  {
    id: 'v-126', word: 'document', lemma: 'document', pos: 'verb', chinese: '记录',
    work_meaning: '将过程或结果书面记录',
    example_en: 'Our next step is to document the entire process.',
    example_cn: '我们的下一步是记录整个过程。',
    collocations: ['document the process', 'document the issue', 'document everything', 'properly document'],
    confusable: [{word: 'document（名词）', diff: 'document作名词是文件，作动词是记录'}, {word: 'condiment', diff: 'condiment是调味品，document是记录'}],
    work_context: 'SOP与流程', related_expression: 'ki-038',
    acceptable_answers: ['document', 'documents', 'documented', 'documenting'], work_relevance: 4, difficulty: 2, day: 18, scenario_id: 'sc-sop'
  },
  {
    id: 'v-127', word: 'follow', lemma: 'follow', pos: 'verb', chinese: '遵循',
    work_meaning: '按照规定或流程执行',
    example_en: 'Please follow the procedure for all emergency cases.',
    example_cn: '请所有紧急情况都遵循流程。',
    collocations: ['follow the procedure', 'follow the SOP', 'follow up', 'follow the steps'],
    confusable: [{word: 'fellow', diff: 'fellow是同伴，follow是遵循'}, {word: 'hollow', diff: 'hollow是空洞的，follow是遵循'}],
    work_context: 'SOP与流程', related_expression: 'ki-037',
    acceptable_answers: ['follow', 'follows', 'followed', 'following'], work_relevance: 5, difficulty: 1, day: 18, scenario_id: 'sc-sop'
  },
  {
    id: 'v-128', word: 'emergency', lemma: 'emergency', pos: 'noun', chinese: '紧急情况',
    work_meaning: '需要立即处理的突发事件',
    example_en: 'All emergency cases must be handled within two hours.',
    example_cn: '所有紧急情况必须在两小时内处理。',
    collocations: ['emergency case', 'emergency situation', 'emergency response', 'in case of emergency'],
    confusable: [{word: 'emergence', diff: 'emergence是出现，emergency是紧急情况'}, {word: 'agency', diff: 'agency是机构，emergency是紧急情况'}],
    work_context: 'SOP与流程', related_expression: 'ki-037',
    acceptable_answers: ['emergency', 'emergencies'], work_relevance: 4, difficulty: 2, day: 18, scenario_id: 'sc-sop'
  },
  {
    id: 'v-129', word: 'step', lemma: 'step', pos: 'noun', chinese: '步骤',
    work_meaning: '流程中的单个环节',
    example_en: 'Let me walk you through each step of the procedure.',
    example_cn: '让我带你走一遍流程的每个步骤。',
    collocations: ['next step', 'each step', 'step by step', 'follow the steps'],
    confusable: [{word: 'stop', diff: 'stop是停止，step是步骤'}, {word: 'steep', diff: 'steep是陡峭的，step是步骤'}],
    work_context: 'SOP与流程', related_expression: 'ki-022',
    acceptable_answers: ['step', 'steps'], work_relevance: 4, difficulty: 1, day: 18, scenario_id: 'sc-sop'
  },
  {
    id: 'v-130', word: 'according', lemma: 'according', pos: 'adverb', chinese: '根据',
    work_meaning: '依据某项规定或标准',
    example_en: 'According to the SOP, we need to notify the owner within 24 hours.',
    example_cn: '根据SOP，我们需要在24小时内通知业主。',
    collocations: ['according to', 'according to the SOP', 'according to the procedure', 'according to the policy'],
    confusable: [{word: 'account', diff: 'account是账户，according是根据'}, {word: 'accord', diff: 'accord是协议/给予，according to是根据'}],
    work_context: 'SOP与流程', related_expression: 'ki-037',
    acceptable_answers: ['according'], work_relevance: 5, difficulty: 2, day: 18, scenario_id: 'sc-sop'
  },
  {
    id: 'v-131', word: 'ensure', lemma: 'ensure', pos: 'verb', chinese: '确保',
    work_meaning: '保证某事发生或被执行',
    example_en: 'Please ensure that all steps are followed.',
    example_cn: '请确保所有步骤都被执行。',
    collocations: ['ensure that', 'please ensure', 'ensure compliance', 'ensure quality'],
    confusable: [{word: 'insure', diff: 'insure是投保，ensure是确保'}, {word: 'assure', diff: 'assure是向某人保证，ensure是确保'}],
    work_context: 'SOP与流程', related_expression: 'ki-037',
    acceptable_answers: ['ensure', 'ensures', 'ensured', 'ensuring'], work_relevance: 5, difficulty: 2, day: 18, scenario_id: 'sc-sop'
  },

  // --- Day 19: Problem Escalation (7 words) ---
  {
    id: 'v-132', word: 'flag', lemma: 'flag', pos: 'verb', chinese: '标记/标注',
    work_meaning: '将某事标为需要注意的',
    example_en: 'I would like to flag this as a high-priority issue.',
    example_cn: '我想将此标记为高优先级问题。',
    collocations: ['flag this as', 'flag as high-priority', 'flag the issue', 'red flag'],
    confusable: [{word: 'flat', diff: 'flat是扁平的，flag是标记'}, {word: 'flap', diff: 'flap是拍打，flag是标记'}],
    work_context: '问题升级', related_expression: 'ki-039',
    acceptable_answers: ['flag', 'flags', 'flagged', 'flagging'], work_relevance: 4, difficulty: 2, day: 19, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-133', word: 'ownership', lemma: 'ownership', pos: 'noun', chinese: '负责/主导权',
    work_meaning: '对某事全面负责',
    example_en: 'I will take ownership of this case until it is fully resolved.',
    example_cn: '我将负责这个案件直到完全解决。',
    collocations: ['take ownership', 'ownership of', 'assume ownership', 'transfer ownership'],
    confusable: [{word: 'owner', diff: 'owner是业主/拥有者，ownership是责任/主导权'}, {word: 'ship', diff: 'ship是船，ownership是负责'}],
    work_context: '承担责任', related_expression: 'ki-041',
    acceptable_answers: ['ownership'], work_relevance: 5, difficulty: 3, day: 19, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-134', word: 'stakeholder', lemma: 'stakeholder', pos: 'noun', chinese: '相关方',
    work_meaning: '与某事有利益关系的人或团队',
    example_en: 'Our next step is to arrange a meeting with all stakeholders.',
    example_cn: '我们的下一步是安排所有相关方的会议。',
    collocations: ['all stakeholders', 'stakeholder meeting', 'stakeholder communication', 'key stakeholders'],
    confusable: [{word: 'stockholder', diff: 'stockholder是股东，stakeholder是相关方（含义更广）'}, {word: 'holder', diff: 'holder是持有者，stakeholder是相关方'}],
    work_context: '问题升级', related_expression: 'ki-040',
    acceptable_answers: ['stakeholder', 'stakeholders'], work_relevance: 4, difficulty: 3, day: 19, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-135', word: 'challenge', lemma: 'challenge', pos: 'noun', chinese: '挑战',
    work_meaning: '工作中遇到的困难',
    example_en: 'The main challenge we are facing is the lack of spare parts.',
    example_cn: '我们面临的主要挑战是缺少备件。',
    collocations: ['main challenge', 'face a challenge', 'challenge we are facing', 'address the challenge'],
    confusable: [{word: 'challenger', diff: 'challenger是挑战者，challenge是挑战'}, {word: 'change', diff: 'change是改变，challenge是挑战'}],
    work_context: '问题升级', related_expression: 'ki-044',
    acceptable_answers: ['challenge', 'challenges'], work_relevance: 4, difficulty: 2, day: 19, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-136', word: 'impact', lemma: 'impact', pos: 'noun', chinese: '影响',
    work_meaning: '对其他工作或人员造成的效果',
    example_en: 'This issue affects multiple units and has a significant impact.',
    example_cn: '这个问题影响多户且有重大影响。',
    collocations: ['significant impact', 'impact on', 'minimize the impact', 'assess the impact'],
    confusable: [{word: 'import', diff: 'import是进口，impact是影响'}, {word: 'pact', diff: 'pact是协定，impact是影响'}],
    work_context: '问题升级', related_expression: 'ki-039',
    acceptable_answers: ['impact', 'impacts'], work_relevance: 5, difficulty: 2, day: 19, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-137', word: 'affect', lemma: 'affect', pos: 'verb', chinese: '影响',
    work_meaning: '对某人或某事产生作用',
    example_en: 'This issue affects multiple units in the building.',
    example_cn: '这个问题影响了楼里的多户。',
    collocations: ['affects multiple', 'affect the owner', 'be affected by', 'affect the timeline'],
    confusable: [{word: 'effect', diff: 'effect是名词影响，affect是动词影响'}, {word: 'effort', diff: 'effort是努力，affect是影响'}],
    work_context: '问题升级', related_expression: 'ki-039',
    acceptable_answers: ['affect', 'affects', 'affected', 'affecting'], work_relevance: 5, difficulty: 2, day: 19, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-138', word: 'multiple', lemma: 'multiple', pos: 'adjective', chinese: '多个的',
    work_meaning: '涉及多个对象',
    example_en: 'The pipe has cracked in multiple places.',
    example_cn: '水管在多处裂开了。',
    collocations: ['multiple units', 'multiple places', 'multiple issues', 'multiple cases'],
    confusable: [{word: 'multiply', diff: 'multiply是乘/繁殖，multiple是多个的'}, {word: 'module', diff: 'module是模块，multiple是多个的'}],
    work_context: '问题升级', related_expression: 'ki-039',
    acceptable_answers: ['multiple'], work_relevance: 4, difficulty: 2, day: 19, scenario_id: 'sc-timeout'
  },

  // --- Day 20: Ownership & Reporting (7 words) ---
  {
    id: 'v-139', word: 'accountability', lemma: 'accountability', pos: 'noun', chinese: '问责/责任',
    work_meaning: '对工作结果负责并需要说明',
    example_en: 'We need clear accountability for each stage of the process.',
    example_cn: '我们需要每个阶段都有明确的责任人。',
    collocations: ['clear accountability', 'accountability for', 'hold someone accountable', 'lack of accountability'],
    confusable: [{word: 'account', diff: 'account是账户，accountability是问责'}, {word: 'ability', diff: 'ability是能力，accountability是问责'}],
    work_context: '承担责任', related_expression: 'ki-041',
    acceptable_answers: ['accountability'], work_relevance: 5, difficulty: 3, day: 20, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-140', word: 'guarantee', lemma: 'guarantee', pos: 'verb', chinese: '保证',
    work_meaning: '确定地承诺某事会发生',
    example_en: 'I can guarantee that all overdue tickets will be resolved by Friday.',
    example_cn: '我可以保证所有超时工单将在周五前解决。',
    collocations: ['guarantee that', 'can guarantee', 'guarantee delivery', 'a guarantee'],
    confusable: [{word: 'guard', diff: 'guard是守卫，guarantee是保证'}, {word: 'warranty', diff: 'warranty是保修，guarantee是保证'}],
    work_context: '承担责任', related_expression: 'ki-042',
    acceptable_answers: ['guarantee', 'guarantees', 'guaranteed', 'guaranteeing'], work_relevance: 4, difficulty: 3, day: 20, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-141', word: 'remaining', lemma: 'remaining', pos: 'adjective', chinese: '剩余的',
    work_meaning: '还没处理完的',
    example_en: 'We are currently working on the remaining three tickets.',
    example_cn: '我们目前正在处理剩余的三个工单。',
    collocations: ['remaining tickets', 'remaining issues', 'remaining cases', 'the remaining'],
    confusable: [{word: 'remind', diff: 'remind是提醒，remaining是剩余的'}, {word: 'removing', diff: 'removing是移除，remaining是剩余的'}],
    work_context: '承担责任', related_expression: 'ki-043',
    acceptable_answers: ['remaining'], work_relevance: 5, difficulty: 2, day: 20, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-142', word: 'active', lemma: 'active', pos: 'adjective', chinese: '积极的/活跃的',
    work_meaning: '正在处理中的',
    example_en: 'We are actively working on the remaining tickets.',
    example_cn: '我们正在积极处理剩余工单。',
    collocations: ['actively working', 'actively handling', 'active ticket', 'actively monitoring'],
    confusable: [{word: 'action', diff: 'action是行动，active是积极的'}, {word: 'actual', diff: 'actual是实际的，active是积极的'}],
    work_context: '承担责任', related_expression: 'ki-003',
    acceptable_answers: ['active', 'actively'], work_relevance: 4, difficulty: 2, day: 20, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-143', word: 'closure', lemma: 'closure', pos: 'noun', chinese: '结案',
    work_meaning: '工单处理完毕并关闭',
    example_en: 'We have achieved closure on twelve out of fifteen tickets this week.',
    example_cn: '本周我们已对15个工单中的12个完成结案。',
    collocations: ['achieve closure', 'ticket closure', 'closure rate', 'pending closure'],
    confusable: [{word: 'close', diff: 'close是关闭（动词），closure是结案（名词）'}, {word: 'disclosure', diff: 'disclosure是披露，closure是结案'}],
    work_context: '承担责任', related_expression: 'ki-043',
    acceptable_answers: ['closure', 'closures'], work_relevance: 4, difficulty: 3, day: 20, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-144', word: 'oversee', lemma: 'oversee', pos: 'verb', chinese: '监督',
    work_meaning: '监督和管理工作的进展',
    example_en: 'I will oversee the resolution process until all tickets are closed.',
    example_cn: '我将监督解决过程直到所有工单关闭。',
    collocations: ['oversee the process', 'oversee the work', 'oversee resolution', 'personally oversee'],
    confusable: [{word: 'overlook', diff: 'overlook是忽略，oversee是监督'}, {word: 'see', diff: 'see是看见，oversee是监督'}],
    work_context: '承担责任', related_expression: 'ki-030',
    acceptable_answers: ['oversee', 'oversees', 'oversaw', 'overseeing'], work_relevance: 4, difficulty: 3, day: 20, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-145', word: 'until', lemma: 'until', pos: 'conjunction', chinese: '直到',
    work_meaning: '表示某个时间点之前持续',
    example_en: 'I will take ownership of this case until it is fully resolved.',
    example_cn: '我将负责这个案件直到完全解决。',
    collocations: ['until it is', 'until resolved', 'until tomorrow', 'until further notice'],
    confusable: [{word: 'unless', diff: 'unless是除非，until是直到'}, {word: 'untie', diff: 'untie是解开，until是直到'}],
    work_context: '承担责任', related_expression: 'ki-041',
    acceptable_answers: ['until'], work_relevance: 4, difficulty: 2, day: 20, scenario_id: 'sc-reporting'
  },

  // --- Day 21: Week 3 Review (7 words) ---
  {
    id: 'v-146', word: 'prioritize', lemma: 'prioritize', pos: 'verb', chinese: '优先排序',
    work_meaning: '按重要性和紧急程度排列处理顺序',
    example_en: 'We need to prioritize the overdue tickets that affect the most residents.',
    example_cn: '我们需要优先处理影响居民最多的超时工单。',
    collocations: ['prioritize the tickets', 'prioritize by', 'need to prioritize', 'be prioritized'],
    confusable: [{word: 'priority', diff: 'priority是名词优先级，prioritize是动词优先排序'}, {word: 'polarize', diff: 'polarize是两极化，prioritize是优先排序'}],
    work_context: '通用汇报', related_expression: 'ki-041',
    acceptable_answers: ['prioritize', 'prioritizes', 'prioritized', 'prioritizing'], work_relevance: 4, difficulty: 3, day: 21, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-147', word: 'finalize', lemma: 'finalize', pos: 'verb', chinese: '最终确定',
    work_meaning: '完成最后的步骤并结案',
    example_en: 'We expect to finalize all overdue tickets by the end of this week.',
    example_cn: '我们预计在本周结束前最终确定所有超时工单。',
    collocations: ['finalize the plan', 'finalize the ticket', 'be finalized', 'finalize by'],
    confusable: [{word: 'final', diff: 'final是最终的（形容词），finalize是最终确定（动词）'}, {word: 'finance', diff: 'finance是财务，finalize是最终确定'}],
    work_context: '工单处理', related_expression: 'ki-003',
    acceptable_answers: ['finalize', 'finalizes', 'finalized', 'finalizing'], work_relevance: 4, difficulty: 3, day: 21, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-148', word: 'mitigate', lemma: 'mitigate', pos: 'verb', chinese: '缓解',
    work_meaning: '减轻问题的影响或严重程度',
    example_en: 'We need to mitigate the impact of these delays on the residents.',
    example_cn: '我们需要缓解这些延迟对居民的影响。',
    collocations: ['mitigate the impact', 'mitigate the risk', 'mitigate the issue', 'be mitigated'],
    confusable: [{word: 'irritate', diff: 'irritate是激怒，mitigate是缓解'}, {word: 'navigate', diff: 'navigate是导航，mitigate是缓解'}],
    work_context: '超时处理', related_expression: 'ki-034',
    acceptable_answers: ['mitigate', 'mitigates', 'mitigated', 'mitigating'], work_relevance: 4, difficulty: 3, day: 21, scenario_id: 'sc-timeout'
  },
  {
    id: 'v-149', word: 'substitute', lemma: 'substitute', pos: 'noun', chinese: '替代品',
    work_meaning: '临时替代原有设备的物品',
    example_en: 'We will provide a temporary substitute while waiting for the new part.',
    example_cn: '在等待新零件期间，我们将提供临时替代品。',
    collocations: ['temporary substitute', 'provide a substitute', 'substitute for', 'use as a substitute'],
    confusable: [{word: 'institute', diff: 'institute是机构，substitute是替代品'}, {word: 'constitute', diff: 'constitute是构成，substitute是替代品'}],
    work_context: '兜底方案', related_expression: 'ki-035',
    acceptable_answers: ['substitute', 'substitutes'], work_relevance: 4, difficulty: 3, day: 21, scenario_id: 'sc-fallback'
  },
  {
    id: 'v-150', word: 'comply', lemma: 'comply', pos: 'verb', chinese: '遵守',
    work_meaning: '按照规定或SOP执行',
    example_en: 'We must comply with the SOP when handling overdue tickets.',
    example_cn: '处理超时工单时我们必须遵守SOP。',
    collocations: ['comply with', 'comply with the SOP', 'must comply', 'compliance with'],
    confusable: [{word: 'apply', diff: 'apply是申请/应用，comply是遵守'}, {word: 'supply', diff: 'supply是供应，comply是遵守'}],
    work_context: 'SOP与流程', related_expression: 'ki-037',
    acceptable_answers: ['comply', 'complies', 'complied', 'complying'], work_relevance: 4, difficulty: 3, day: 21, scenario_id: 'sc-sop'
  },
  {
    id: 'v-151', word: 'delegate', lemma: 'delegate', pos: 'verb', chinese: '委派',
    work_meaning: '将任务分配给他人处理',
    example_en: 'I will delegate this case to the regional manager for faster resolution.',
    example_cn: '我将把此案件委派给区域经理以加快解决。',
    collocations: ['delegate to', 'delegate the task', 'delegate responsibility', 'be delegated'],
    confusable: [{word: 'delete', diff: 'delete是删除，delegate是委派'}, {word: 'legate', diff: 'legate是使节，delegate是委派'}],
    work_context: '承担责任', related_expression: 'ki-041',
    acceptable_answers: ['delegate', 'delegates', 'delegated', 'delegating'], work_relevance: 4, difficulty: 3, day: 21, scenario_id: 'sc-reporting'
  },
  {
    id: 'v-152', word: 'deteriorate', lemma: 'deteriorate', pos: 'verb', chinese: '恶化',
    work_meaning: '设备或状况变得更差',
    example_en: 'The pipe condition has deteriorated rapidly and needs immediate replacement.',
    example_cn: '水管状况已迅速恶化，需要立即更换。',
    collocations: ['deteriorate rapidly', 'condition deteriorated', 'has deteriorated', 'be deteriorating'],
    confusable: [{word: 'determine', diff: 'determine是确定，deteriorate是恶化'}, {word: 'decorate', diff: 'decorate是装饰，deteriorate是恶化'}],
    work_context: '维修与换新', related_expression: 'ki-031',
    acceptable_answers: ['deteriorate', 'deteriorates', 'deteriorated', 'deteriorating'], work_relevance: 4, difficulty: 3, day: 21, scenario_id: 'sc-repair'
  },

  // ============================================================
  // WEEK 4 (Days 22-28): Repair, replacement, timeout handling, fallback plans, SOP
  // ============================================================

  // --- Day 22: Data-Driven Reporting (8 words) ---
  {
    id: 'v-153', word: 'analysis', lemma: 'analysis', pos: 'noun', chinese: '分析',
    work_meaning: '对数据进行深入研究',
    example_en: 'Our analysis shows a correlation between complexity and delay.',
    example_cn: '我们的分析显示复杂性和延迟之间存在关联。',
    collocations: ['data analysis', 'root cause analysis', 'analysis shows', 'in the analysis'],
    confusable: [{word: 'analyze', diff: 'analyze是动词分析，analysis是名词分析'}, {word: 'analyst', diff: 'analyst是分析师，analysis是分析'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['analysis', 'analyses'], work_relevance: 5, difficulty: 3, day: 22, scenario_id: 'sc-data'
  },
  {
    id: 'v-154', word: 'complexity', lemma: 'complexity', pos: 'noun', chinese: '复杂性',
    work_meaning: '问题难处理的程度',
    example_en: 'The drop is mainly due to the increased complexity of cases.',
    example_cn: '下降主要因为案件复杂性增加。',
    collocations: ['increased complexity', 'case complexity', 'due to complexity', 'level of complexity'],
    confusable: [{word: 'complex', diff: 'complex是形容词复杂的，complexity是名词复杂性'}, {word: 'completeness', diff: 'completeness是完整性，complexity是复杂性'}],
    work_context: '数据汇报', related_expression: 'ki-053',
    acceptable_answers: ['complexity', 'complexities'], work_relevance: 4, difficulty: 3, day: 22, scenario_id: 'sc-data'
  },
  {
    id: 'v-155', word: 'correlate', lemma: 'correlate', pos: 'verb', chinese: '相关联',
    work_meaning: '两个因素之间存在关联',
    example_en: 'The delay correlates with the increase in complex cases.',
    example_cn: '延迟与复杂案件增加相关联。',
    collocations: ['correlate with', 'correlates to', 'be correlated with', 'correlation between'],
    confusable: [{word: 'relate', diff: 'relate是关联，correlate是相关（更强调统计关系）'}, {word: 'coordinate', diff: 'coordinate是协调，correlate是相关'}],
    work_context: '数据汇报', related_expression: 'ki-053',
    acceptable_answers: ['correlate', 'correlates', 'correlated', 'correlating'], work_relevance: 3, difficulty: 3, day: 22, scenario_id: 'sc-data'
  },
  {
    id: 'v-156', word: 'pattern', lemma: 'pattern', pos: 'noun', chinese: '模式/规律',
    work_meaning: '反复出现的数据特征',
    example_en: 'We can see a clear pattern in the data over the past three weeks.',
    example_cn: '我们可以看到过去三周数据中的明显规律。',
    collocations: ['clear pattern', 'data pattern', 'identify a pattern', 'recurring pattern'],
    confusable: [{word: 'matter', diff: 'matter是事情/物质，pattern是模式'}, {word: 'patent', diff: 'patent是专利，pattern是模式'}],
    work_context: '数据汇报', related_expression: 'ki-053',
    acceptable_answers: ['pattern', 'patterns'], work_relevance: 4, difficulty: 3, day: 22, scenario_id: 'sc-data'
  },
  {
    id: 'v-157', word: 'insight', lemma: 'insight', pos: 'noun', chinese: '洞察',
    work_meaning: '从数据中发现的深层理解',
    example_en: 'The data gives us an important insight into the root cause.',
    example_cn: '数据给我们提供了关于根本原因的重要洞察。',
    collocations: ['key insight', 'important insight', 'provide insight', 'gain insight'],
    confusable: [{word: 'inside', diff: 'inside是里面，insight是洞察'}, {word: 'incite', diff: 'incite是煽动，insight是洞察'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['insight', 'insights'], work_relevance: 4, difficulty: 3, day: 22, scenario_id: 'sc-data'
  },
  {
    id: 'v-158', word: 'triage', lemma: 'triage', pos: 'noun', chinese: '分流/分诊',
    work_meaning: '按优先级对工单进行分类处理',
    example_en: 'Our next step is to improve our triage process.',
    example_cn: '我们的下一步是改进分流流程。',
    collocations: ['triage process', 'improve triage', 'triage system', 'triage by priority'],
    confusable: [{word: 'target', diff: 'target是目标，triage是分流'}, {word: 'trace', diff: 'trace是追溯，triage是分流'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['triage', 'triages'], work_relevance: 4, difficulty: 4, day: 22, scenario_id: 'sc-data'
  },
  {
    id: 'v-159', word: 'recover', lemma: 'recover', pos: 'verb', chinese: '恢复',
    work_meaning: '从下降中回升',
    example_en: 'We expect to recover next week and will keep you updated.',
    example_cn: '我们预计下周会恢复，并会持续更新。',
    collocations: ['expect to recover', 'recover to', 'recover from', 'recovery plan'],
    confusable: [{word: 'discover', diff: 'discover是发现，recover是恢复'}, {word: 'uncover', diff: 'uncover是揭露，recover是恢复'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['recover', 'recovers', 'recovered', 'recovering'], work_relevance: 4, difficulty: 3, day: 22, scenario_id: 'sc-data'
  },
  {
    id: 'v-160', word: 'driven', lemma: 'driven', pos: 'adjective', chinese: '驱动的',
    work_meaning: '以数据为基础做决策',
    example_en: 'We need a data-driven approach to identify the root cause.',
    example_cn: '我们需要以数据驱动的方式来找到根本原因。',
    collocations: ['data-driven', 'driven by', 'result-driven', 'driven approach'],
    confusable: [{word: 'drive', diff: 'drive是驾驶/驱动，driven是被驱动的'}, {word: 'given', diff: 'given是给定的，driven是驱动的'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['driven'], work_relevance: 4, difficulty: 3, day: 22, scenario_id: 'sc-data'
  },

  // --- Day 23: Advanced Follow-up Handling (7 words) ---
  {
    id: 'v-161', word: 'press', lemma: 'press', pos: 'verb', chinese: '追问/施压',
    work_meaning: '继续追问或要求回答',
    example_en: 'The manager pressed for more details about the delay.',
    example_cn: '经理追问了延迟的更多细节。',
    collocations: ['press for', 'press the issue', 'be pressed', 'press further'],
    confusable: [{word: 'stress', diff: 'stress是强调/压力，press是追问'}, {word: 'pass', diff: 'pass是通过，press是追问'}],
    work_context: '回答追问', related_expression: 'ki-019',
    acceptable_answers: ['press', 'presses', 'pressed', 'pressing'], work_relevance: 4, difficulty: 3, day: 23, scenario_id: 'sc-followup'
  },
  {
    id: 'v-162', word: 'detail', lemma: 'detail', pos: 'noun', chinese: '细节',
    work_meaning: '具体的信息或数据',
    example_en: 'I will provide the detailed breakdown this afternoon.',
    example_cn: '我今天下午会提供详细明细。',
    collocations: ['detailed breakdown', 'in detail', 'more details', 'provide details'],
    confusable: [{word: 'detail（动词）', diff: 'detail作动词是详述，作名词是细节'}, {word: 'retail', diff: 'retail是零售，detail是细节'}],
    work_context: '回答追问', related_expression: 'ki-019',
    acceptable_answers: ['detail', 'details'], work_relevance: 5, difficulty: 3, day: 23, scenario_id: 'sc-followup'
  },
  {
    id: 'v-163', word: 'transparency', lemma: 'transparency', pos: 'noun', chinese: '透明度',
    work_meaning: '信息公开可见的程度',
    example_en: 'We need more transparency in our reporting process.',
    example_cn: '我们的汇报流程需要更多透明度。',
    collocations: ['more transparency', 'transparency in', 'ensure transparency', 'lack of transparency'],
    confusable: [{word: 'parent', diff: 'parent是父母，transparency是透明度'}, {word: 'apparent', diff: 'apparent是明显的，transparency是透明度'}],
    work_context: '回答追问', related_expression: 'ki-020',
    acceptable_answers: ['transparency'], work_relevance: 4, difficulty: 3, day: 23, scenario_id: 'sc-followup'
  },
  {
    id: 'v-164', word: 'justify', lemma: 'justify', pos: 'verb', chinese: '证明合理',
    work_meaning: '为某个决定或数据提供合理解释',
    example_en: 'Can you justify why the rate has been dropping for two weeks?',
    example_cn: '你能说明为什么比率连续两周下降吗？',
    collocations: ['justify the decision', 'justify why', 'be justified', 'hard to justify'],
    confusable: [{word: 'testify', diff: 'testify是作证，justify是证明合理'}, {word: 'satisfy', diff: 'satisfy是满足，justify是证明合理'}],
    work_context: '回答追问', related_expression: 'ki-020',
    acceptable_answers: ['justify', 'justifies', 'justified', 'justifying'], work_relevance: 4, difficulty: 3, day: 23, scenario_id: 'sc-followup'
  },
  {
    id: 'v-165', word: 'accountable', lemma: 'accountable', pos: 'adjective', chinese: '可追责的',
    work_meaning: '对结果承担责任',
    example_en: 'We need to be accountable for the drop in performance.',
    example_cn: '我们需要对绩效下降负责。',
    collocations: ['be accountable', 'hold accountable', 'accountable for', 'accountability'],
    confusable: [{word: 'count', diff: 'count是计数，accountable是可追责的'}, {word: 'acceptable', diff: 'acceptable是可接受的，accountable是可追责的'}],
    work_context: '回答追问', related_expression: 'ki-041',
    acceptable_answers: ['accountable'], work_relevance: 4, difficulty: 3, day: 23, scenario_id: 'sc-followup'
  },
  {
    id: 'v-166', word: 'consecutive', lemma: 'consecutive', pos: 'adjective', chinese: '连续的',
    work_meaning: '一个接一个不间断的',
    example_en: 'The rate has been dropping for two consecutive weeks.',
    example_cn: '比率已经连续两周下降了。',
    collocations: ['two consecutive weeks', 'consecutive months', 'consecutive days', 'consecutive decline'],
    confusable: [{word: 'executive', diff: 'executive是行政的，consecutive是连续的'}, {word: 'connective', diff: 'connective是连接的，consecutive是连续的'}],
    work_context: '回答追问', related_expression: 'ki-020',
    acceptable_answers: ['consecutive'], work_relevance: 4, difficulty: 3, day: 23, scenario_id: 'sc-followup'
  },
  {
    id: 'v-167', word: 'convince', lemma: 'convince', pos: 'verb', chinese: '说服',
    work_meaning: '使他人相信某个判断或方案',
    example_en: 'I need to convince the manager that we can recover next week.',
    example_cn: '我需要说服经理我们下周能恢复。',
    collocations: ['convince that', 'convince the manager', 'be convinced', 'convince someone to'],
    confusable: [{word: 'convict', diff: 'convict是定罪，convince是说服'}, {word: 'convene', diff: 'convene是召集，convince是说服'}],
    work_context: '回答追问', related_expression: 'ki-020',
    acceptable_answers: ['convince', 'convinces', 'convinced', 'convincing'], work_relevance: 4, difficulty: 3, day: 23, scenario_id: 'sc-followup'
  },

  // --- Day 24: Plans & Conditionals (7 words) ---
  {
    id: 'v-168', word: 'conditional', lemma: 'conditional', pos: 'adjective', chinese: '有条件的',
    work_meaning: '取决于某些前提的',
    example_en: 'Our timeline is conditional on the parts arriving tomorrow.',
    example_cn: '我们的时间表取决于零件明天到货。',
    collocations: ['conditional on', 'conditional plan', 'be conditional', 'conditional approval'],
    confusable: [{word: 'condition', diff: 'condition是条件，conditional是有条件的'}, {word: 'conventional', diff: 'conventional是常规的，conditional是有条件的'}],
    work_context: '提出方案', related_expression: 'ki-046',
    acceptable_answers: ['conditional'], work_relevance: 4, difficulty: 3, day: 24, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-169', word: 'if', lemma: 'if', pos: 'conjunction', chinese: '如果',
    work_meaning: '引出条件从句',
    example_en: 'If the parts arrive tomorrow, then we will finish by Thursday.',
    example_cn: '如果零件明天到，我们就能在周四前完成。',
    collocations: ['if...then', 'even if', 'as if', 'if possible'],
    confusable: [{word: 'of', diff: 'of是...的，if是如果'}, {word: 'it', diff: 'it是它，if是如果'}],
    work_context: '提出方案', related_expression: 'ki-046',
    acceptable_answers: ['if'], work_relevance: 5, difficulty: 2, day: 24, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-170', word: 'otherwise', lemma: 'otherwise', pos: 'adverb', chinese: '否则',
    work_meaning: '在条件不满足时',
    example_en: 'We need the parts by tomorrow; otherwise, we will need a fallback.',
    example_cn: '我们需要明天前拿到零件，否则需要一个兜底方案。',
    collocations: ['otherwise we', 'or otherwise', 'otherwise, we will', 'unless otherwise'],
    confusable: [{word: 'wise', diff: 'wise是明智的，otherwise是否则'}, {word: 'outside', diff: 'outside是外面，otherwise是否则'}],
    work_context: '提出方案', related_expression: 'ki-046',
    acceptable_answers: ['otherwise'], work_relevance: 4, difficulty: 3, day: 24, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-171', word: 'unless', lemma: 'unless', pos: 'conjunction', chinese: '除非',
    work_meaning: '表示唯一的例外条件',
    example_en: 'Unless we get the parts by tomorrow, we will need a backup plan.',
    example_cn: '除非明天前拿到零件，否则我们需要备用方案。',
    collocations: ['unless we', 'unless otherwise', 'unless the', 'not unless'],
    confusable: [{word: 'until', diff: 'until是直到，unless是除非'}, {word: 'less', diff: 'less是更少，unless是除非'}],
    work_context: '提出方案', related_expression: 'ki-046',
    acceptable_answers: ['unless'], work_relevance: 4, difficulty: 3, day: 24, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-172', word: 'phase', lemma: 'phase', pos: 'noun', chinese: '阶段',
    work_meaning: '工作中的阶段或步骤',
    example_en: 'In the worst case, phase two will take two more weeks.',
    example_cn: '在最坏的情况下，第二阶段将需要再多两周。',
    collocations: ['phase one', 'phase two', 'two-phase approach', 'next phase'],
    confusable: [{word: 'phrase', diff: 'phrase是短语，phase是阶段'}, {word: 'face', diff: 'face是脸，phase是阶段'}],
    work_context: '提出方案', related_expression: 'ki-046',
    acceptable_answers: ['phase', 'phases'], work_relevance: 4, difficulty: 3, day: 24, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-173', word: 'propose', lemma: 'propose', pos: 'verb', chinese: '提出',
    work_meaning: '正式提出方案或建议',
    example_en: 'I would like to propose a two-phase approach.',
    example_cn: '我想提出一个两阶段的方案。',
    collocations: ['propose a plan', 'propose a solution', 'I would like to propose', 'propose that'],
    confusable: [{word: 'purpose', diff: 'purpose是目的，propose是提出'}, {word: 'oppose', diff: 'oppose是反对，propose是提出'}],
    work_context: '提出方案', related_expression: 'ki-022',
    acceptable_answers: ['propose', 'proposes', 'proposed', 'proposing'], work_relevance: 4, difficulty: 3, day: 24, scenario_id: 'sc-nextstep'
  },
  {
    id: 'v-174', word: 'approach', lemma: 'approach', pos: 'noun', chinese: '方法',
    work_meaning: '解决问题的思路或方式',
    example_en: 'We need a different approach to handle complex cases.',
    example_cn: '我们需要不同的方法来处理复杂案件。',
    collocations: ['different approach', 'new approach', 'approach to', 'a phased approach'],
    confusable: [{word: 'approve', diff: 'approve是批准，approach是方法'}, {word: 'attach', diff: 'attach是附上，approach是方法'}],
    work_context: '提出方案', related_expression: 'ki-022',
    acceptable_answers: ['approach', 'approaches'], work_relevance: 4, difficulty: 3, day: 24, scenario_id: 'sc-nextstep'
  },

  // --- Day 25: Full Ticket Lifecycle (7 words) ---
  {
    id: 'v-175', word: 'lifecycle', lemma: 'lifecycle', pos: 'noun', chinese: '生命周期',
    work_meaning: '工单从创建到关闭的全过程',
    example_en: 'Let me walk you through the full lifecycle of this ticket.',
    example_cn: '让我带你过一遍这个工单的完整生命周期。',
    collocations: ['full lifecycle', 'ticket lifecycle', 'lifecycle of', 'entire lifecycle'],
    confusable: [{word: 'life', diff: 'life是生命，lifecycle是生命周期'}, {word: 'circle', diff: 'circle是圆圈，lifecycle是生命周期'}],
    work_context: '工单全流程', related_expression: 'ki-001',
    acceptable_answers: ['lifecycle', 'lifecycles'], work_relevance: 4, difficulty: 3, day: 25, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-176', word: 'dispatch', lemma: 'dispatch', pos: 'verb', chinese: '派遣/分发',
    work_meaning: '将工单或人员派发到对应处理方',
    example_en: 'The ticket was dispatched to the maintenance team on Monday morning.',
    example_cn: '工单于周一上午被派发给维修团队。',
    collocations: ['dispatch to', 'be dispatched', 'dispatch the ticket', 'dispatch a team'],
    confusable: [{word: 'discard', diff: 'discard是丢弃，dispatch是派遣'}, {word: 'display', diff: 'display是展示，dispatch是派遣'}],
    work_context: '工单全流程', related_expression: 'ki-001',
    acceptable_answers: ['dispatch', 'dispatches', 'dispatched', 'dispatching'], work_relevance: 4, difficulty: 3, day: 25, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-177', word: 'route', lemma: 'route', pos: 'verb', chinese: '流转/分发',
    work_meaning: '将工单发送到对应处理人',
    example_en: 'The ticket was routed to the maintenance team.',
    example_cn: '工单被分发到维修团队。',
    collocations: ['route to', 'be routed', 'route the ticket', 'routing rule'],
    confusable: [{word: 'root', diff: 'root是根，route是路线/分发'}, {word: 'rude', diff: 'rude是粗鲁的，route是路线/分发'}],
    work_context: '工单全流程', related_expression: 'ki-008',
    acceptable_answers: ['route', 'routes', 'routed', 'routing'], work_relevance: 4, difficulty: 3, day: 25, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-178', word: 'monitor', lemma: 'monitor', pos: 'verb', chinese: '监控',
    work_meaning: '持续关注工单状态',
    example_en: 'We will monitor the ticket status until it is resolved.',
    example_cn: '我们将监控工单状态直到解决。',
    collocations: ['monitor the status', 'monitor progress', 'monitor closely', 'continuous monitoring'],
    confusable: [{word: 'monitor（名词）', diff: 'monitor作名词是显示器，作动词是监控'}, {word: 'motor', diff: 'motor是马达，monitor是监控'}],
    work_context: '工单全流程', related_expression: 'ki-001',
    acceptable_answers: ['monitor', 'monitors', 'monitored', 'monitoring'], work_relevance: 4, difficulty: 3, day: 25, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-179', word: 'prevent', lemma: 'prevent', pos: 'verb', chinese: '预防',
    work_meaning: '采取措施避免问题再次发生',
    example_en: 'We need to prevent similar delays in the future.',
    example_cn: '我们需要预防未来出现类似延迟。',
    collocations: ['prevent similar', 'prevent delays', 'prevent the issue', 'prevent from'],
    confusable: [{word: 'event', diff: 'event是事件，prevent是预防'}, {word: 'present', diff: 'present是呈现/现在的，prevent是预防'}],
    work_context: '工单全流程', related_expression: 'ki-022',
    acceptable_answers: ['prevent', 'prevents', 'prevented', 'preventing'], work_relevance: 4, difficulty: 3, day: 25, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-180', word: 'identify', lemma: 'identify', pos: 'verb', chinese: '识别',
    work_meaning: '发现或确定问题',
    example_en: 'We need to identify the root cause of the delay.',
    example_cn: '我们需要识别延迟的根本原因。',
    collocations: ['identify the root cause', 'identify the issue', 'identify patterns', 'identify the problem'],
    confusable: [{word: 'identity', diff: 'identity是身份，identify是识别'}, {word: 'notify', diff: 'notify是通知，identify是识别'}],
    work_context: '工单全流程', related_expression: 'ki-013',
    acceptable_answers: ['identify', 'identifies', 'identified', 'identifying'], work_relevance: 4, difficulty: 3, day: 25, scenario_id: 'sc-ticket'
  },
  {
    id: 'v-181', word: 'investigate', lemma: 'investigate', pos: 'verb', chinese: '调查',
    work_meaning: '深入研究问题原因',
    example_en: 'We are investigating the cause of the recurring issue.',
    example_cn: '我们正在调查这个反复出现的问题的原因。',
    collocations: ['investigate the cause', 'investigate the issue', 'be investigated', 'under investigation'],
    confusable: [{word: 'invest', diff: 'invest是投资，investigate是调查'}, {word: 'navigate', diff: 'navigate是导航，investigate是调查'}],
    work_context: '工单全流程', related_expression: 'ki-013',
    acceptable_answers: ['investigate', 'investigates', 'investigated', 'investigating'], work_relevance: 4, difficulty: 3, day: 25, scenario_id: 'sc-ticket'
  },

  // --- Day 26: Owner Communication Full Cycle (7 words) ---
  {
    id: 'v-182', word: 'empathy', lemma: 'empathy', pos: 'noun', chinese: '共情',
    work_meaning: '理解和认同业主的感受',
    example_en: 'We should show empathy when communicating with upset owners.',
    example_cn: '与不满的业主沟通时应表现出共情。',
    collocations: ['show empathy', 'empathy for', 'with empathy', 'lack of empathy'],
    confusable: [{word: 'sympathy', diff: 'sympathy是同情，empathy是共情（更强调感同身受）'}, {word: 'emphasis', diff: 'emphasis是强调，empathy是共情'}],
    work_context: '业主沟通', related_expression: 'ki-027',
    acceptable_answers: ['empathy'], work_relevance: 4, difficulty: 3, day: 26, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-183', word: 'compensate', lemma: 'compensate', pos: 'verb', chinese: '补偿',
    work_meaning: '对业主的损失进行弥补',
    example_en: 'We will compensate the owner for the extended delay.',
    example_cn: '我们将对业主的长期延迟进行补偿。',
    collocations: ['compensate for', 'compensate the owner', 'be compensated', 'compensation plan'],
    confusable: [{word: 'compose', diff: 'compose是组成，compensate是补偿'}, {word: 'compete', diff: 'compete是竞争，compensate是补偿'}],
    work_context: '业主沟通', related_expression: 'ki-028',
    acceptable_answers: ['compensate', 'compensates', 'compensated', 'compensating'], work_relevance: 4, difficulty: 3, day: 26, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-184', word: 'reassure', lemma: 'reassure', pos: 'verb', chinese: '安抚',
    work_meaning: '使业主放心',
    example_en: 'I want to reassure you that we are doing everything we can.',
    example_cn: '我想让您放心，我们正在尽一切努力。',
    collocations: ['reassure the owner', 'reassure that', 'want to reassure', 'be reassured'],
    confusable: [{word: 'ensure', diff: 'ensure是确保，reassure是安抚'}, {word: 'measure', diff: 'measure是测量，reassure是安抚'}],
    work_context: '业主沟通', related_expression: 'ki-027',
    acceptable_answers: ['reassure', 'reassures', 'reassured', 'reassuring'], work_relevance: 4, difficulty: 3, day: 26, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-185', word: 'mediate', lemma: 'mediate', pos: 'verb', chinese: '调解',
    work_meaning: '在业主和维修方之间进行协调',
    example_en: 'If the owner is still not satisfied, we may need to mediate between the parties.',
    example_cn: '如果业主仍不满意，我们可能需要在双方之间进行调解。',
    collocations: ['mediate between', 'mediate the dispute', 'be mediated', 'mediate a solution'],
    confusable: [{word: 'meditate', diff: 'meditate是冥想，mediate是调解'}, {word: 'mediate（形容词）', diff: 'mediate也可作形容词意为中间的，此处是动词调解'}],
    work_context: '业主沟通', related_expression: 'ki-039',
    acceptable_answers: ['mediate', 'mediates', 'mediated', 'mediating'], work_relevance: 4, difficulty: 3, day: 26, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-186', word: 'pledge', lemma: 'pledge', pos: 'verb', chinese: '保证/承诺',
    work_meaning: '向业主正式保证做到某事',
    example_en: 'I pledge to provide you with daily updates until this is resolved.',
    example_cn: '我保证每天向您更新直到问题解决。',
    collocations: ['pledge to', 'pledge to provide', 'make a pledge', 'pledge commitment'],
    confusable: [{word: 'plea', diff: 'plea是恳求，pledge是保证'}, {word: 'edge', diff: 'edge是边缘，pledge是保证'}],
    work_context: '业主沟通', related_expression: 'ki-027',
    acceptable_answers: ['pledge', 'pledges', 'pledged', 'pledging'], work_relevance: 4, difficulty: 3, day: 26, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-187', word: 'satisfaction', lemma: 'satisfaction', pos: 'noun', chinese: '满意度',
    work_meaning: '业主对服务的满意程度',
    example_en: 'Our goal is to ensure owner satisfaction throughout the process.',
    example_cn: '我们的目标是确保整个过程业主满意。',
    collocations: ['owner satisfaction', 'ensure satisfaction', 'satisfaction rate', 'customer satisfaction'],
    confusable: [{word: 'dissatisfaction', diff: 'dissatisfaction是不满，satisfaction是满意'}, {word: 'satisfy', diff: 'satisfy是动词满足，satisfaction是名词满意'}],
    work_context: '业主沟通', related_expression: 'ki-027',
    acceptable_answers: ['satisfaction'], work_relevance: 4, difficulty: 3, day: 26, scenario_id: 'sc-owner-comm'
  },
  {
    id: 'v-188', word: 'timeline', lemma: 'timeline', pos: 'noun', chinese: '时间线',
    work_meaning: '工作的整体时间安排',
    example_en: 'I will get back to you by tomorrow with the exact timeline.',
    example_cn: '我明天前会给你确切的时间线。',
    collocations: ['exact timeline', 'provide a timeline', 'on the timeline', 'adjust the timeline'],
    confusable: [{word: 'deadline', diff: 'deadline是单个截止点，timeline是整体时间线'}, {word: 'lifeline', diff: 'lifeline是生命线，timeline是时间线'}],
    work_context: '业主沟通', related_expression: 'ki-010',
    acceptable_answers: ['timeline', 'timelines'], work_relevance: 4, difficulty: 3, day: 26, scenario_id: 'sc-owner-comm'
  },

  // --- Day 27: Data Report & Q&A (7 words) ---
  {
    id: 'v-189', word: 'fluctuate', lemma: 'fluctuate', pos: 'verb', chinese: '波动',
    work_meaning: '数据上下起伏变化',
    example_en: 'The resolution rate has been fluctuating between seventy and eighty percent.',
    example_cn: '解决率一直在70%到80%之间波动。',
    collocations: ['fluctuate between', 'has been fluctuating', 'fluctuate significantly', 'price fluctuation'],
    confusable: [{word: 'flate', diff: 'flate不是标准词，注意拼写'}, {word: 'formulate', diff: 'formulate是制定，fluctuate是波动'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['fluctuate', 'fluctuates', 'fluctuated', 'fluctuating'], work_relevance: 4, difficulty: 4, day: 27, scenario_id: 'sc-data'
  },
  {
    id: 'v-190', word: 'optimize', lemma: 'optimize', pos: 'verb', chinese: '优化',
    work_meaning: '改进流程以提高效率',
    example_en: 'Our next step is to optimize our triage process.',
    example_cn: '我们的下一步是优化分流流程。',
    collocations: ['optimize the process', 'optimize performance', 'optimize efficiency', 'be optimized'],
    confusable: [{word: 'option', diff: 'option是选项，optimize是优化'}, {word: 'organize', diff: 'organize是组织，optimize是优化'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['optimize', 'optimizes', 'optimized', 'optimizing'], work_relevance: 4, difficulty: 4, day: 27, scenario_id: 'sc-data'
  },
  {
    id: 'v-191', word: 'implement', lemma: 'implement', pos: 'verb', chinese: '实施',
    work_meaning: '将方案或计划付诸执行',
    example_en: 'We plan to implement the new triage process starting next week.',
    example_cn: '我们计划从下周开始实施新的分流流程。',
    collocations: ['implement the plan', 'implement the process', 'be implemented', 'implement changes'],
    confusable: [{word: 'compliment', diff: 'compliment是赞美，implement是实施'}, {word: 'supplement', diff: 'supplement是补充，implement是实施'}],
    work_context: '数据汇报', related_expression: 'ki-022',
    acceptable_answers: ['implement', 'implements', 'implemented', 'implementing'], work_relevance: 4, difficulty: 4, day: 27, scenario_id: 'sc-data'
  },
  {
    id: 'v-192', word: 'measure', lemma: 'measure', pos: 'noun', chinese: '措施',
    work_meaning: '为解决问题采取的行动',
    example_en: 'We have put several measures in place to prevent recurrence.',
    example_cn: '我们已采取多项措施防止再次发生。',
    collocations: ['take measures', 'preventive measures', 'corrective measures', 'put measures in place'],
    confusable: [{word: 'measure（动词）', diff: 'measure作动词是测量，作名词是措施'}, {word: 'treasure', diff: 'treasure是宝藏，measure是措施'}],
    work_context: '数据汇报', related_expression: 'ki-022',
    acceptable_answers: ['measure', 'measures'], work_relevance: 4, difficulty: 3, day: 27, scenario_id: 'sc-data'
  },
  {
    id: 'v-193', word: 'evaluate', lemma: 'evaluate', pos: 'verb', chinese: '评估',
    work_meaning: '对方案或绩效进行评价',
    example_en: 'We need to evaluate the effectiveness of the new process.',
    example_cn: '我们需要评估新流程的有效性。',
    collocations: ['evaluate the effectiveness', 'evaluate performance', 'be evaluated', 'evaluate the impact'],
    confusable: [{word: 'value', diff: 'value是价值，evaluate是评估'}, {word: 'evade', diff: 'evade是逃避，evaluate是评估'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['evaluate', 'evaluates', 'evaluated', 'evaluating'], work_relevance: 4, difficulty: 4, day: 27, scenario_id: 'sc-data'
  },
  {
    id: 'v-194', word: 'enhance', lemma: 'enhance', pos: 'verb', chinese: '提升',
    work_meaning: '改进流程或结果的质量',
    example_en: 'Our next step is to enhance our triage process for better efficiency.',
    example_cn: '我们的下一步是提升分流流程以获得更好的效率。',
    collocations: ['enhance the process', 'enhance efficiency', 'enhance performance', 'be enhanced'],
    confusable: [{word: 'chance', diff: 'chance是机会，enhance是提升'}, {word: 'entrance', diff: 'entrance是入口，enhance是提升'}],
    work_context: '数据汇报', related_expression: 'ki-022',
    acceptable_answers: ['enhance', 'enhances', 'enhanced', 'enhancing'], work_relevance: 4, difficulty: 4, day: 27, scenario_id: 'sc-data'
  },
  {
    id: 'v-195', word: 'effectiveness', lemma: 'effectiveness', pos: 'noun', chinese: '有效性',
    work_meaning: '措施或方案是否产生预期效果',
    example_en: 'We need to evaluate the effectiveness of our new approach.',
    example_cn: '我们需要评估新方法的有效性。',
    collocations: ['evaluate the effectiveness', 'measure effectiveness', 'cost effectiveness', 'effectiveness of'],
    confusable: [{word: 'efficiency', diff: 'efficiency是效率，effectiveness是有效性'}, {word: 'affect', diff: 'affect是影响，effectiveness是有效性'}],
    work_context: '数据汇报', related_expression: 'ki-049',
    acceptable_answers: ['effectiveness'], work_relevance: 4, difficulty: 4, day: 27, scenario_id: 'sc-data'
  },

  // --- Day 28: Monthly Assessment (8 words) ---
  {
    id: 'v-196', word: 'monthly', lemma: 'monthly', pos: 'adjective', chinese: '月度的',
    work_meaning: '每月一次的总结',
    example_en: 'Let me walk you through the monthly numbers.',
    example_cn: '让我带你过一遍月度数据。',
    collocations: ['monthly review', 'monthly report', 'monthly target', 'monthly assessment'],
    confusable: [{word: 'monthly（副词）', diff: 'monthly也可作副词，意为每月地'}, {word: 'motherly', diff: 'motherly是母亲般的，monthly是月度的'}],
    work_context: '月度评估', related_expression: 'ki-049',
    acceptable_answers: ['monthly'], work_relevance: 5, difficulty: 3, day: 28, scenario_id: 'sc-data'
  },
  {
    id: 'v-197', word: 'assessment', lemma: 'assessment', pos: 'noun', chinese: '评估',
    work_meaning: '对一段时间工作的整体评价',
    example_en: 'This monthly assessment covers all key metrics.',
    example_cn: '这次月度评估涵盖了所有关键指标。',
    collocations: ['monthly assessment', 'performance assessment', 'risk assessment', 'conduct an assessment'],
    confusable: [{word: 'asset', diff: 'asset是资产，assessment是评估'}, {word: 'assignment', diff: 'assignment是任务，assessment是评估'}],
    work_context: '月度评估', related_expression: 'ki-049',
    acceptable_answers: ['assessment', 'assessments'], work_relevance: 5, difficulty: 4, day: 28, scenario_id: 'sc-data'
  },
  {
    id: 'v-198', word: 'achieve', lemma: 'achieve', pos: 'verb', chinese: '达成',
    work_meaning: '达到设定的目标',
    example_en: 'We achieved eighty-two percent completion rate this month.',
    example_cn: '本月我们实现了82%的完成率。',
    collocations: ['achieve the target', 'achieve the goal', 'achieve a rate', 'be achieved'],
    confusable: [{word: 'archive', diff: 'archive是归档，achieve是达成'}, {word: 'receive', diff: 'receive是收到，achieve是达成'}],
    work_context: '月度评估', related_expression: 'ki-049',
    acceptable_answers: ['achieve', 'achieves', 'achieved', 'achieving'], work_relevance: 5, difficulty: 3, day: 28, scenario_id: 'sc-data'
  },
  {
    id: 'v-199', word: 'recurrence', lemma: 'recurrence', pos: 'noun', chinese: '再次发生',
    work_meaning: '同类问题重复出现',
    example_en: 'We have taken measures to prevent recurrence of this issue.',
    example_cn: '我们已采取措施防止此类问题再次发生。',
    collocations: ['prevent recurrence', 'recurrence of', 'recurrence rate', 'avoid recurrence'],
    confusable: [{word: 'occurrence', diff: 'occurrence是发生，recurrence是再次发生'}, {word: 'currency', diff: 'currency是货币，recurrence是再次发生'}],
    work_context: '月度评估', related_expression: 'ki-037',
    acceptable_answers: ['recurrence'], work_relevance: 4, difficulty: 4, day: 28, scenario_id: 'sc-sop'
  },
  {
    id: 'v-200', word: 'strengthen', lemma: 'strengthen', pos: 'verb', chinese: '加强',
    work_meaning: '使流程或措施更有力',
    example_en: 'We need to strengthen our SOP to prevent similar issues.',
    example_cn: '我们需要加强SOP以防止类似问题。',
    collocations: ['strengthen the SOP', 'strengthen the process', 'strengthen communication', 'strengthen controls'],
    confusable: [{word: 'length', diff: 'length是长度，strengthen是加强'}, {word: 'string', diff: 'string是绳子，strengthen是加强'}],
    work_context: '月度评估', related_expression: 'ki-037',
    acceptable_answers: ['strengthen', 'strengthens', 'strengthened', 'strengthening'], work_relevance: 4, difficulty: 4, day: 28, scenario_id: 'sc-sop'
  },
  {
    id: 'v-201', word: 'streamline', lemma: 'streamline', pos: 'verb', chinese: '精简',
    work_meaning: '简化和优化流程',
    example_en: 'We plan to streamline the ticket routing process.',
    example_cn: '我们计划精简工单分发流程。',
    collocations: ['streamline the process', 'streamline operations', 'streamline workflow', 'be streamlined'],
    confusable: [{word: 'stream', diff: 'stream是溪流，streamline是精简'}, {word: 'line', diff: 'line是线，streamline是精简'}],
    work_context: '月度评估', related_expression: 'ki-022',
    acceptable_answers: ['streamline', 'streamlines', 'streamlined', 'streamlining'], work_relevance: 4, difficulty: 4, day: 28, scenario_id: 'sc-sop'
  },
  {
    id: 'v-202', word: 'benchmark', lemma: 'benchmark', pos: 'noun', chinese: '基准/标杆',
    work_meaning: '用于比较的标准或参考',
    example_en: 'We use last quarter as the benchmark for comparison.',
    example_cn: '我们以上季度为基准进行比较。',
    collocations: ['use as benchmark', 'set a benchmark', 'benchmark against', 'benchmark data'],
    confusable: [{word: 'bench', diff: 'bench是长椅，benchmark是基准'}, {word: 'mark', diff: 'mark是标记，benchmark是基准'}],
    work_context: '月度评估', related_expression: 'ki-052',
    acceptable_answers: ['benchmark', 'benchmarks'], work_relevance: 4, difficulty: 4, day: 28, scenario_id: 'sc-data'
  },
  {
    id: 'v-203', word: 'sustain', lemma: 'sustain', pos: 'verb', chinese: '维持',
    work_meaning: '保持已有的绩效水平',
    example_en: 'We need to sustain this level of performance going forward.',
    example_cn: '接下来我们需要维持这个绩效水平。',
    collocations: ['sustain the performance', 'sustain the improvement', 'sustain growth', 'be sustained'],
    confusable: [{word: 'contain', diff: 'contain是包含，sustain是维持'}, {word: 'obtain', diff: 'obtain是获得，sustain是维持'}],
    work_context: '月度评估', related_expression: 'ki-049',
    acceptable_answers: ['sustain', 'sustains', 'sustained', 'sustaining'], work_relevance: 4, difficulty: 4, day: 28, scenario_id: 'sc-data'
  }
];

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { VOCAB_ITEMS };
}
