// ===== Work Practice Page (V2: follow-ups) =====
let wpFollowUpIdx = 0;
let wpAnswers = [];

async function renderWorkPractice(app, params) {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const wp = lesson.workPractice;
  const sessionBar = currentSession ? renderSessionBar(3) : '';
  wpFollowUpIdx = 0;
  wpAnswers = [];

  app.innerHTML = `
    <div class="container page">
      ${sessionBar}
      <div style="padding: 20px 0;">
        <h2>工作练习</h2>
        <p class="text-secondary text-sm mt-sm">围绕真实工作情况，自行组织英语</p>
      </div>

      <div class="card">
        <div class="badge badge-coral mb-md">工作场景</div>
        <div style="font-size: 17px; line-height: 1.7;">${wp.context}</div>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-sm">你的任务</div>
        <div style="font-size: 16px; font-weight: 600;">${wp.task}</div>

        <textarea id="wp-answer" placeholder="用英语写出你的回答..." style="min-height: 120px; margin-top: 12px;"></textarea>

        <div class="flex gap-sm mt-sm">
          <button class="btn btn-ghost btn-sm flex-1" onclick="wpVoiceInput()">🎤 语音回答</button>
          <button class="btn btn-ghost btn-sm flex-1" onclick="showWPHints()">💡 提示</button>
        </div>
      </div>

      <div class="card" id="wp-hints" style="display:none;">
        <div class="text-secondary text-sm mb-sm">提示表达</div>
        ${wp.hints.map(h => `<div style="padding: 6px 0;">• ${h}</div>`).join('')}
      </div>

      <div class="card" id="wp-followup" style="display:none;">
        <div class="badge badge-gold mb-md">追问 ${wpFollowUpIdx}</div>
        <div style="font-size: 17px; line-height: 1.7;" id="wp-followup-q"></div>
        <textarea id="wp-followup-answer" placeholder="用英语回答追问..." style="min-height: 80px; margin-top: 12px;"></textarea>
        <div class="flex gap-sm mt-sm">
          <button class="btn btn-ghost btn-sm flex-1" onclick="wpFollowUpVoice()">🎤 语音回答</button>
        </div>
        <button class="btn btn-primary btn-block mt-md" onclick="submitWPFollowUp()">提交回答</button>
      </div>

      <div class="card" id="wp-result" style="display:none;">
        <div class="text-secondary text-sm mb-sm">参考答案</div>
        <div style="font-size: 16px; line-height: 1.7; padding: 12px; background: var(--color-bg-subtle); border-radius: 8px;">${wp.reference}</div>

        ${wp.followUps && wp.followUps.length > 0 ? `
        <div class="text-secondary text-sm mt-md mb-sm">追问与参考</div>
        ${wp.followUps.map((f, i) => `
          <div style="padding: 8px 0; border-bottom: 1px solid var(--color-border-light);">
            <div class="text-sm" style="font-weight: 500;">Q${i+1}: ${f}</div>
            <div class="text-light text-xs mt-sm">你的回答：${wpAnswers[i] || '(未回答)'}</div>
          </div>
        `).join('')}
        ` : ''}

        <div class="text-secondary text-sm mt-md mb-sm">自我评分</div>
        <div class="rating-group">
          <button class="rating-btn again" onclick="rateWorkPractice('again')">不会</button>
          <button class="rating-btn hard" onclick="rateWorkPractice('hard')">困难</button>
          <button class="rating-btn good" onclick="rateWorkPractice('good')">不错</button>
          <button class="rating-btn easy" onclick="rateWorkPractice('easy')">很好</button>
        </div>

        <button class="btn btn-coral btn-sm btn-block mt-md" onclick="addWPToErrorBank()">加入错题本</button>
      </div>

      <div class="flex gap-md mt-lg">
        ${!currentSession ? `<button class="btn btn-outline" onclick="navTo('today')">返回</button>` : ''}
        <button class="btn btn-primary flex-1" onclick="submitWorkPractice()">提交查看参考答案</button>
      </div>
    </div>
  `;
}

function showWPHints() {
  const el = document.getElementById('wp-hints');
  el.style.display = el.style.display === 'none' ? 'block' : 'none';
}

function wpVoiceInput() {
  if (!SpeechUtils.isSTTAvailable()) {
    showToast('当前浏览器不支持语音识别，请用文本输入');
    return;
  }
  showToast('正在录音...说英语后停止');
  const input = document.getElementById('wp-answer');
  SpeechUtils.startRecognition({
    onresult: (e) => {
      input.value = Array.from(e.results).map(r => r[0].transcript).join('');
    },
    onend: () => showToast('录音结束'),
    onerror: () => showToast('语音识别出错')
  });
}

function submitWorkPractice() {
  const answer = document.getElementById('wp-answer').value.trim();
  if (!answer || answer.length < 5) {
    showToast('请先写出你的回答');
    return;
  }
  wpAnswers[0] = answer;
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const followUps = lesson.workPractice.followUps || [];

  if (followUps.length > 0 && wpFollowUpIdx < followUps.length) {
    // 显示追问
    const fuEl = document.getElementById('wp-followup');
    document.getElementById('wp-followup-q').textContent = followUps[wpFollowUpIdx];
    fuEl.style.display = 'block';
    fuEl.scrollIntoView({ behavior: 'smooth' });
  } else {
    // 没有追问，直接显示参考答案
    document.getElementById('wp-result').style.display = 'block';
    document.getElementById('wp-result').scrollIntoView({ behavior: 'smooth' });
  }
}

function submitWPFollowUp() {
  const answer = document.getElementById('wp-followup-answer').value.trim();
  if (!answer || answer.length < 3) {
    showToast('请先写出回答');
    return;
  }
  wpAnswers[wpFollowUpIdx + 1] = answer;
  wpFollowUpIdx++;

  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const followUps = lesson.workPractice.followUps || [];

  if (wpFollowUpIdx < followUps.length) {
    // 还有更多追问
    document.getElementById('wp-followup-q').textContent = followUps[wpFollowUpIdx];
    document.getElementById('wp-followup-answer').value = '';
    const badge = document.querySelector('#wp-followup .badge');
    if (badge) badge.textContent = `追问 ${wpFollowUpIdx + 1}`;
  } else {
    // 追问完毕，显示参考答案
    document.getElementById('wp-followup').style.display = 'none';
    document.getElementById('wp-result').style.display = 'block';
    document.getElementById('wp-result').scrollIntoView({ behavior: 'smooth' });
  }
}

function wpFollowUpVoice() {
  if (!SpeechUtils.isSTTAvailable()) {
    showToast('当前浏览器不支持语音识别');
    return;
  }
  showToast('正在录音...');
  const input = document.getElementById('wp-followup-answer');
  SpeechUtils.startRecognition({
    onresult: (e) => { input.value = Array.from(e.results).map(r => r[0].transcript).join(''); },
    onend: () => showToast('录音结束'),
    onerror: () => showToast('语音识别出错')
  });
}

async function rateWorkPractice(rating) {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const answer = document.getElementById('wp-answer').value;

  // 记录尝试
  await dbPut(STORES.learningAttempts, {
    id: uuid(), item_id: `wp-day-${studyDay}`, date: todayStr(),
    rating, success: rating === 'good' || rating === 'easy',
    answer_text: answer, answer_mode: 'text', dimension: 'usage'
  });

  // 更新能力分数
  await updateSkillScore('give_updates', rating === 'good' || rating === 'easy');
  await updateSkillScore('continuous_speaking', rating === 'good' || rating === 'easy');

  if (currentSession) {
    nextSessionStep();
  } else {
    showToast('已记录！');
    navTo('today');
  }
}

async function addWPToErrorBank() {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const answer = document.getElementById('wp-answer').value;
  await dbPut(STORES.errorBank, {
    id: uuid(), original_answer: answer, better_answer: lesson.workPractice.reference,
    error_type: 'incomplete_answer', error_tag: 'work_practice',
    explanation: lesson.workPractice.task, scenario_id: 'sc-reporting',
    occurrence_count: 1, first_seen_at: new Date().toISOString(),
    last_seen_at: new Date().toISOString(), next_review_at: Date.now() + 86400000,
    resolved: false
  });
  showToast('已加入错题本');
}

// ===== Daily Challenge Page =====
let challengeStartTime = 0;

async function renderDailyChallenge(app, params) {
  const studyDay = getStudyDay(appSettings);
  const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
  const challenge = lesson.challenge;
  const sessionBar = currentSession ? renderSessionBar(4) : '';

  app.innerHTML = `
    <div class="container page">
      ${sessionBar}
      <div style="padding: 20px 0;">
        <div class="badge badge-gold mb-md">🏆 Daily Challenge</div>
        <h2>今日挑战</h2>
        <p class="text-secondary text-sm mt-sm">不显示提示，独立完成</p>
      </div>

      <div class="card" style="background: linear-gradient(135deg, rgba(245,185,66,0.08), rgba(245,185,66,0.02)); border: 1px solid rgba(245,185,66,0.2);">
        <div style="font-size: 18px; font-weight: 600; line-height: 1.6;">${challenge.prompt}</div>
        <div class="text-secondary text-sm mt-md">⏱ 建议 45-60 秒完成</div>
      </div>

      <div class="card">
        <textarea id="challenge-answer" placeholder="用英语完成挑战..." style="min-height: 100px;"></textarea>
        <div class="flex gap-sm mt-sm">
          <button class="btn btn-ghost btn-sm flex-1" onclick="challengeVoiceInput()">🎤 语音</button>
          <button class="btn btn-ghost btn-sm flex-1" onclick="showChallengeRef()">查看参考</button>
        </div>
      </div>

      <div class="card" id="challenge-ref" style="display:none;">
        <div class="text-secondary text-sm mb-sm">参考方向</div>
        <div class="text-sm">挑战重点：先说结论 → 说数据 → 说原因 → 说下一步</div>
        <div class="text-secondary text-sm mt-md mb-sm">自我评分</div>
        <div class="rating-group">
          <button class="rating-btn again" onclick="rateChallenge('again')">没完成</button>
          <button class="rating-btn hard" onclick="rateChallenge('hard')">困难</button>
          <button class="rating-btn good" onclick="rateChallenge('good')">不错</button>
          <button class="rating-btn easy" onclick="rateChallenge('easy')">很好</button>
        </div>
      </div>

      <div class="flex gap-md mt-lg">
        ${!currentSession ? `<button class="btn btn-outline" onclick="navTo('today')">返回</button>` : ''}
        <button class="btn btn-primary flex-1" onclick="submitChallenge()">完成挑战</button>
      </div>
    </div>
  `;
  challengeStartTime = Date.now();
}

function challengeVoiceInput() {
  if (!SpeechUtils.isSTTAvailable()) {
    showToast('当前浏览器不支持语音识别');
    return;
  }
  showToast('正在录音...');
  const input = document.getElementById('challenge-answer');
  SpeechUtils.startRecognition({
    onresult: (e) => { input.value = Array.from(e.results).map(r => r[0].transcript).join(''); },
    onend: () => showToast('录音结束'),
    onerror: () => showToast('语音识别出错')
  });
}

function showChallengeRef() {
  document.getElementById('challenge-ref').style.display = 'block';
}

function submitChallenge() {
  const answer = document.getElementById('challenge-answer').value.trim();
  if (!answer || answer.length < 5) {
    showToast('请先完成挑战');
    return;
  }
  showChallengeRef();
  document.getElementById('challenge-ref').scrollIntoView({ behavior: 'smooth' });
}

async function rateChallenge(rating) {
  const answer = document.getElementById('challenge-answer').value;
  await dbPut(STORES.learningAttempts, {
    id: uuid(), item_id: `challenge-day-${getStudyDay(appSettings)}`,
    date: todayStr(), rating, success: rating === 'good' || rating === 'easy',
    answer_text: answer, dimension: 'transfer', response_time: Date.now() - challengeStartTime
  });
  await updateSkillScore('continuous_speaking', rating === 'good' || rating === 'easy');
  await updateSkillScore('give_updates', rating === 'good' || rating === 'easy');

  if (currentSession) {
    completeSession();
  } else {
    showToast('挑战完成！');
    navTo('today');
  }
}

// ===== Session Summary =====
async function renderSessionSummary(app, params) {
  const studyDay = getStudyDay(appSettings);
  const todayRecord = await dbGet(STORES.dailySessions, studyDay);
  const allMastery = await dbGetAll(STORES.masteryRecords);
  const masteredCount = allMastery.filter(m => m.mastery_state === 'Mastered').length;
  const learningCount = allMastery.filter(m => m.mastery_state === 'Learning').length;
  const reviewingCount = allMastery.filter(m => m.mastery_state === 'Reviewing').length;
  const week = getWeek(studyDay);

  app.innerHTML = `
    <div class="container page">
      <div style="padding: 40px 20px; text-align: center;">
        <div style="font-size: 64px;">🎉</div>
        <h1 style="margin-top: 16px;">今日学习完成！</h1>
        <p class="text-secondary mt-sm">Day ${studyDay} · 第 ${week} 周</p>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">今日成果</div>
        <div class="flex justify-between mb-sm"><span>听力热身</span><span class="badge badge-mint">✓</span></div>
        <div class="flex justify-between mb-sm"><span>主动复习</span><span class="badge badge-mint">✓</span></div>
        <div class="flex justify-between mb-sm"><span>学习表达</span><span class="badge badge-mint">✓</span></div>
        <div class="flex justify-between mb-sm"><span>工作练习</span><span class="badge badge-mint">✓</span></div>
        <div class="flex justify-between"><span>今日挑战</span><span class="badge badge-mint">✓</span></div>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">总体进度</div>
        <div class="flex justify-between mb-md">
          <div style="text-align:center; flex:1;">
            <div style="font-size: 24px; font-weight: 700; color: var(--color-mint);">${learningCount}</div>
            <div class="text-xs text-light">学习中</div>
          </div>
          <div style="text-align:center; flex:1;">
            <div style="font-size: 24px; font-weight: 700; color: var(--color-gold);">${reviewingCount}</div>
            <div class="text-xs text-light">复习中</div>
          </div>
          <div style="text-align:center; flex:1;">
            <div style="font-size: 24px; font-weight: 700; color: var(--color-primary);">${masteredCount}</div>
            <div class="text-xs text-light">已掌握</div>
          </div>
        </div>
        <div class="progress-bar"><div class="progress-bar-fill mint" style="width: ${Math.min(100, studyDay/168*100)}%"></div></div>
        <div class="text-light text-xs mt-sm">总进度 ${Math.round(studyDay/168*100)}% · 连续 ${appSettings.streakDays} 天</div>
      </div>

      <div class="card" style="background: var(--color-bg-subtle);">
        <div class="text-secondary text-sm">💡 明日预告</div>
        <div class="text-sm mt-sm">${studyDay < 168 ? (DAILY_LESSONS.find(l => l.day === studyDay+1)?.theme || '继续学习') : '已完成全部课程！'}</div>
      </div>

      <button class="btn btn-primary btn-block btn-lg mt-lg" onclick="navTo('today')">返回首页</button>
    </div>
  `;
}

// ===== Progress Page =====
async function renderProgress(app) {
  const allSkills = await dbGetAll(STORES.skillScores);
  const allMastery = await dbGetAll(STORES.masteryRecords);
  const mastered = allMastery.filter(m => m.mastery_state === 'Mastered').length;
  const learning = allMastery.filter(m => m.mastery_state === 'Learning').length;
  const reviewing = allMastery.filter(m => m.mastery_state === 'Reviewing').length;
  const total = allMastery.length;

  // 获取错题
  const allErrors = await dbGetAll(STORES.errorBank);
  const unresolvedErrors = allErrors.filter(e => !e.resolved);

  // 本周学习天数
  const studyDay = getStudyDay(appSettings);
  const week = getWeek(studyDay);
  let weekDays = 0;
  for (let d = (week-1)*7+1; d <= studyDay; d++) {
    const rec = await dbGet(STORES.dailySessions, d);
    if (rec && rec.completed) weekDays++;
  }

  // 检查是否已完成入门测评
  const assessmentCompleted = appSettings.assessmentCompleted || false;

  // 找最薄弱能力（仅在测评完成后才显示）
  const sortedSkills = [...allSkills].sort((a, b) => (a.score||0) - (b.score||0));
  const weakest = assessmentCompleted ? sortedSkills.filter(s => (s.score || 0) > 0).slice(0, 3) : [];

  // 最常见错误
  const errorTags = {};
  allErrors.forEach(e => {
    if (e.error_tag) errorTags[e.error_tag] = (errorTags[e.error_tag] || 0) + 1;
  });
  const topErrors = Object.entries(errorTags).sort((a,b) => b[1]-a[1]).slice(0, 5);

  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <h2>学习进度</h2>
        <p class="text-secondary text-sm mt-sm">工作沟通能力追踪</p>
      </div>

      <div class="card">
        <div class="flex justify-between items-center mb-md">
          <span class="text-secondary text-sm">工作沟通综合分</span>
          ${assessmentCompleted
            ? `<span style="font-size: 32px; font-weight: 700; color: var(--color-primary);">${Math.round(allSkills.reduce((s,sk)=>s+(sk.score||0),0)/Math.max(1,allSkills.length))}</span>`
            : `<span class="badge badge-gray" style="font-size: 14px;">尚未评估</span>`
          }
        </div>
        ${assessmentCompleted
          ? `<div class="progress-bar"><div class="progress-bar-fill" style="width: ${Math.round(allSkills.reduce((s,sk)=>s+(sk.score||0),0)/Math.max(1,allSkills.length))}%"></div></div>`
          : `<div class="text-light text-xs">完成 Day 0 入门测评后将显示能力分数</div>`
        }
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">能力维度</div>
        ${allSkills.sort((a,b)=>(b.score||0)-(a.score||0)).map(skill => `
          <div style="margin-bottom: 12px;">
            <div class="flex justify-between text-sm">
              <span>${skill.name_zh}</span>
              ${assessmentCompleted
                ? `<span class="text-light">${Math.round(skill.score || 0)}</span>`
                : `<span class="text-light text-xs">尚未评估</span>`
              }
            </div>
            ${assessmentCompleted
              ? `<div class="progress-bar mt-sm" style="height: 6px;"><div class="progress-bar-fill ${skill.score > 60 ? 'mint' : skill.score > 30 ? 'gold' : 'coral'}" style="width: ${skill.score || 0}%"></div></div>`
              : `<div class="progress-bar mt-sm" style="height: 6px;"><div class="progress-bar-fill" style="width: 0%; background: var(--color-border);"></div></div>`
            }
          </div>
        `).join('')}
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">学习统计</div>
        <div class="flex justify-between mb-sm"><span>本周学习天数</span><span style="font-weight: 600;">${weekDays} / 7</span></div>
        <div class="flex justify-between mb-sm"><span>连续学习</span><span style="font-weight: 600;">${appSettings.streakDays || 0} 天</span></div>
        <div class="flex justify-between mb-sm"><span>累计学习时间</span><span style="font-weight: 600;">${appSettings.totalStudyMinutes || 0} 分钟</span></div>
        <div class="flex justify-between mb-sm"><span>到期复习</span><span style="font-weight: 600; color: var(--color-coral);">${(await WEC_Algo.getDueReviewItems()).length}</span></div>
        <div class="flex justify-between"><span>已掌握表达</span><span style="font-weight: 600; color: var(--color-mint);">${mastered} / ${total}</span></div>
      </div>

      ${assessmentCompleted && weakest.length > 0 ? `
      <div class="card" style="border-left: 3px solid var(--color-coral);">
        <div class="text-coral text-sm mb-sm">⚠️ 当前最薄弱能力</div>
        ${weakest.map(s => `<div class="text-sm" style="padding: 4px 0;">${s.name_zh}：${Math.round(s.score||0)} 分</div>`).join('')}
        <div class="text-light text-xs mt-sm">下周建议重点练习以上能力</div>
      </div>
      ` : !assessmentCompleted ? `
      <div class="card" style="background: var(--color-bg-subtle);">
        <div class="text-secondary text-sm">📋 入门测评</div>
        <div class="text-sm mt-sm" style="line-height: 1.6;">完成 Day 0 入门测评后，将显示各能力的基准分数和最薄弱能力。</div>
        <button class="btn btn-outline btn-sm mt-md" onclick="navTo('assessment')">开始测评 →</button>
      </div>
      ` : ''}

      ${topErrors.length > 0 ? `
      <div class="card">
        <div class="text-secondary text-sm mb-md">最近常见错误</div>
        ${topErrors.map(([tag, count]) => `<div class="flex justify-between text-sm" style="padding: 4px 0;"><span>${tag}</span><span class="badge badge-coral">${count} 次</span></div>`).join('')}
      </div>
      ` : ''}

      <div class="card" style="background: var(--color-bg-subtle);">
        <div class="text-secondary text-sm">📌 下周重点</div>
        <div class="text-sm mt-sm">${weakest[0] ? '重点练习「' + weakest[0].name_zh + '」相关表达' : '继续保持每日学习'}${unresolvedErrors.length > 0 ? '；复习错题本中 ' + unresolvedErrors.length + ' 个未解决错误' : ''}</div>
      </div>
    </div>
  `;
}

// ===== More Page =====
function renderMore(app) {
  const items = [
    { icon: '📝', title: 'Quiz', subtitle: 'Daily / Weekly / Monthly 测验', page: 'quiz' },
    { icon: '💬', title: 'AI Conversation', subtitle: '本地情景对话练习', page: 'conversation' },
    { icon: '📚', title: 'Knowledge Base', subtitle: '查看所有学过的表达', page: 'knowledge-base' },
    { icon: '❌', title: 'Error Bank', subtitle: '错题本和弱项追踪', page: 'error-bank' },
    { icon: '📥', title: '导入对话', subtitle: '导入 ChatGPT 工作对话', page: 'import' },
    { icon: '💾', title: '数据备份与恢复', subtitle: '导出/导入学习数据', page: 'backup' },
    { icon: '⚙️', title: 'Settings', subtitle: '学习设置和偏好', page: 'settings' }
  ];

  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <h2>更多功能</h2>
      </div>
      ${items.map(item => `
        <div class="list-item card-clickable" onclick="navTo('${item.page}')">
          <div class="list-item-icon" style="background: var(--color-bg-subtle);">${item.icon}</div>
          <div class="list-item-content">
            <div class="list-item-title">${item.title}</div>
            <div class="list-item-subtitle">${item.subtitle}</div>
          </div>
          <div class="list-item-action">→</div>
        </div>
      `).join('')}

      <div class="card mt-lg" style="background: var(--color-bg-subtle);">
        <div class="text-secondary text-sm mb-sm">关于</div>
        <div class="text-sm" style="line-height: 1.6;">Personal Work English Coach V2</div>
        <div class="text-light text-xs mt-sm">当前为本地情景对话模式；智能追问与AI评分接口已预留。</div>
        <div class="text-light text-xs mt-sm">数据保存在本设备。更换设备前请先导出学习数据。</div>
      </div>
    </div>
  `;
}

// ===== Knowledge Base Page =====
async function renderKnowledgeBase(app) {
  const allItems = await dbGetAll(STORES.knowledgeItems);
  const allMastery = await dbGetAll(STORES.masteryRecords);
  const masteryMap = {};
  allMastery.forEach(m => masteryMap[m.item_id] = m);

  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <h2>Knowledge Base</h2>
        <p class="text-secondary text-sm mt-sm">已收录 ${allItems.length} 个工作英语表达</p>
      </div>

      <div class="card">
        <input type="search" id="kb-search" placeholder="搜索表达..." oninput="filterKB()">
      </div>

      <div class="card" style="padding: 12px;">
        <div class="flex gap-sm" style="flex-wrap: wrap;">
          <button class="chip active" onclick="filterKBByScenario('all', this)">全部</button>
          ${SCENARIOS.map(s => `<button class="chip" onclick="filterKBByScenario('${s.id}', this)">${s.name}</button>`).join('')}
        </div>
      </div>

      <div id="kb-list">
        ${allItems.map(item => renderKBItem(item, masteryMap[item.id])).join('')}
      </div>
    </div>
  `;
}

function renderKBItem(item, mastery) {
  const state = mastery ? mastery.mastery_state : 'New';
  const stateBadge = {
    'New': '<span class="badge badge-new">新</span>',
    'Learning': '<span class="badge badge-learning">学习中</span>',
    'Reviewing': '<span class="badge badge-reviewing">复习中</span>',
    'Mastered': '<span class="badge badge-mastered">已掌握</span>'
  }[state] || '<span class="badge badge-gray">新</span>';

  return `
    <div class="card card-clickable" onclick="editKBItem('${item.id}')">
      <div class="flex justify-between items-start">
        <div style="flex: 1; min-width: 0;">
          <div style="font-weight: 600; font-size: 16px;">${item.english}</div>
          <div class="text-secondary text-sm">${item.chinese}</div>
          <div class="flex gap-sm mt-sm">
            <span class="badge badge-gray">${item.type}</span>
            <span class="badge badge-gray">${item.work_context}</span>
            ${stateBadge}
          </div>
        </div>
        <button class="btn btn-ghost btn-sm" onclick="event.stopPropagation(); speakKB('${item.id}')">🔊</button>
      </div>
    </div>
  `;
}

let kbFilter = { search: '', scenario: 'all' };

function filterKB() {
  kbFilter.search = document.getElementById('kb-search').value.toLowerCase();
  applyKBFilter();
}

function filterKBByScenario(scenario, btn) {
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');
  kbFilter.scenario = scenario;
  applyKBFilter();
}

async function applyKBFilter() {
  const allItems = await dbGetAll(STORES.knowledgeItems);
  const allMastery = await dbGetAll(STORES.masteryRecords);
  const masteryMap = {};
  allMastery.forEach(m => masteryMap[m.item_id] = m);

  let filtered = allItems;
  if (kbFilter.scenario !== 'all') filtered = filtered.filter(i => i.scenario_id === kbFilter.scenario);
  if (kbFilter.search) filtered = filtered.filter(i =>
    i.english.toLowerCase().includes(kbFilter.search) ||
    i.chinese.toLowerCase().includes(kbFilter.search)
  );

  document.getElementById('kb-list').innerHTML = filtered.map(item => renderKBItem(item, masteryMap[item.id])).join('') ||
    '<div class="empty-state"><div class="empty-state-icon">🔍</div><p>没有匹配的表达</p></div>';
}

function speakKB(itemId) {
  const item = KNOWLEDGE_ITEMS.find(i => i.id === itemId);
  if (item) SpeechUtils.speak(item.english, { rate: appSettings.speechRate });
}

async function editKBItem(itemId) {
  const item = await dbGet(STORES.knowledgeItems, itemId);
  if (!item) return;

  const overlay = showModal(`
    <h3>编辑表达</h3>
    <div class="mt-md">
      <label class="text-secondary text-sm">English</label>
      <input type="text" id="edit-en" value="${item.english.replace(/"/g, '&quot;')}" class="mt-sm">
    </div>
    <div class="mt-md">
      <label class="text-secondary text-sm">中文</label>
      <input type="text" id="edit-zh" value="${item.chinese.replace(/"/g, '&quot;')}" class="mt-sm">
    </div>
    <div class="mt-md">
      <label class="text-secondary text-sm">工作场景</label>
      <select id="edit-scenario" class="mt-sm">
        ${SCENARIOS.map(s => `<option value="${s.id}" ${item.scenario_id === s.id ? 'selected' : ''}>${s.name}</option>`).join('')}
      </select>
    </div>
    <div class="mt-md">
      <label class="text-secondary text-sm">工作相关度 (1-5)</label>
      <input type="number" id="edit-relevance" value="${item.work_relevance || 3}" min="1" max="5" class="mt-sm">
    </div>
    <div class="flex gap-md mt-lg">
      <button class="btn btn-danger btn-sm flex-1" onclick="deleteKBItem('${itemId}')">删除</button>
      <button class="btn btn-outline btn-sm flex-1" onclick="closeModal()">取消</button>
      <button class="btn btn-primary btn-sm flex-1" onclick="saveKBItem('${itemId}')">保存</button>
    </div>
  `);
}

async function saveKBItem(itemId) {
  const item = await dbGet(STORES.knowledgeItems, itemId);
  item.english = document.getElementById('edit-en').value;
  item.chinese = document.getElementById('edit-zh').value;
  item.scenario_id = document.getElementById('edit-scenario').value;
  item.work_relevance = parseInt(document.getElementById('edit-relevance').value);
  item.updated_at = new Date().toISOString();
  await dbPut(STORES.knowledgeItems, item);
  closeModal();
  showToast('已保存');
  renderKnowledgeBase(document.getElementById('app'));
}

async function deleteKBItem(itemId) {
  if (!confirm('确认删除这个表达？')) return;
  await dbDelete(STORES.knowledgeItems, itemId);
  await dbDelete(STORES.masteryRecords, itemId);
  await dbDelete(STORES.reviewSchedule, itemId);
  closeModal();
  showToast('已删除');
  renderKnowledgeBase(document.getElementById('app'));
}

// ===== Error Bank Page =====
async function renderErrorBank(app) {
  const allErrors = await dbGetAll(STORES.errorBank);
  const sorted = allErrors.sort((a, b) => new Date(b.last_seen_at || 0) - new Date(a.last_seen_at || 0));

  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <h2>错题本</h2>
        <p class="text-secondary text-sm mt-sm">${sorted.length} 条记录 · ${sorted.filter(e => !e.resolved).length} 条未解决</p>
      </div>

      <div class="card">
        <div class="flex gap-sm">
          <button class="chip active" onclick="filterErrors('all', this)">全部</button>
          <button class="chip" onclick="filterErrors('unresolved', this)">未解决</button>
          <button class="chip" onclick="filterErrors('resolved', this)">已解决</button>
        </div>
      </div>

      <div id="error-list">
        ${sorted.length === 0 ? `
          <div class="empty-state">
            <div class="empty-state-icon">📝</div>
            <p>还没有错题记录</p>
            <p class="text-light text-xs mt-sm">在词汇练习或工作练习中答错时会自动记录</p>
          </div>
        ` : sorted.map(e => renderErrorItem(e)).join('')}
      </div>
    </div>
  `;
}

let errorFilter = 'all';

function filterErrors(filter, btn) {
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');
  errorFilter = filter;
  applyErrorFilter();
}

async function applyErrorFilter() {
  const allErrors = await dbGetAll(STORES.errorBank);
  let filtered = allErrors;
  if (errorFilter === 'unresolved') filtered = filtered.filter(e => !e.resolved);
  if (errorFilter === 'resolved') filtered = filtered.filter(e => e.resolved);
  filtered.sort((a, b) => new Date(b.last_seen_at || 0) - new Date(a.last_seen_at || 0));
  document.getElementById('error-list').innerHTML = filtered.length === 0 ?
    '<div class="empty-state"><p>没有记录</p></div>' :
    filtered.map(e => renderErrorItem(e)).join('');
}

function renderErrorItem(e) {
  var isVocab = !!e.vocab_id;
  var title = isVocab ? (e.word || e.vocab_id) : (e.better_answer || '表达错误');
  var subtitle = isVocab ? '词汇 · ' + (e.quiz_type || e.error_type || '') : '表达 · ' + (e.error_type || '');
  var userAns = e.user_answer || e.original_answer || '(空)';
  var correctAns = e.correct_answer || e.better_answer || '';
  var expl = e.explanation || '';
  var occCount = e.occurrence_count || 1;
  var lastDate = e.last_seen_at ? new Date(e.last_seen_at).toLocaleDateString('zh-CN') : '—';
  var nextDate = e.next_review_at ? new Date(e.next_review_at).toLocaleDateString('zh-CN') : '—';

  return `
    <div class="error-bank-card ${e.resolved ? 'resolved' : ''}">
      <div class="eb-header">
        <div>
          <div class="eb-word">${title}</div>
          <div class="eb-type">${subtitle}</div>
        </div>
        <div style="text-align: right;">
          <div class="eb-count">×${occCount}</div>
          ${e.resolved ? '<span class="badge badge-mint" style="font-size:11px;">已解决</span>' : '<span class="badge badge-coral" style="font-size:11px;">未解决</span>'}
        </div>
      </div>
      <div class="eb-detail">
        <div style="color: var(--color-coral);">你的答案：${userAns}</div>
        <div style="color: var(--color-primary);">正确答案：${correctAns}</div>
        ${expl ? `<div style="margin-top: 6px; padding: 8px 10px; background: var(--color-bg-subtle); border-radius: 10px; font-size: 13px; line-height: 1.6;">💡 ${expl}</div>` : ''}
      </div>
      <div class="text-light text-xs" style="margin-top: 6px;">
        最近错误：${lastDate} · 下次复习：${nextDate}
        ${e.hint_used ? ' · 使用了提示' : ''}${e.answer_revealed ? ' · 查看了答案' : ''}
      </div>
      <div class="eb-actions">
        ${isVocab ? `<button class="btn btn-ghost btn-sm" style="background: var(--color-coral); color: white;" onclick="retryVocabError('${e.id}')">立即重练</button>` : `<button class="btn btn-ghost btn-sm" onclick="retryExpressionError('${e.id}')">再练一次</button>`}
        ${!e.resolved ? `<button class="btn btn-ghost btn-sm" onclick="resolveError('${e.id}')">标记已解决</button>` : ''}
      </div>
    </div>
  `;
}

async function resolveError(id) {
  const e = await dbGet(STORES.errorBank, id);
  if (e) {
    e.resolved = true;
    e.resolved_at = new Date().toISOString();
    await dbPut(STORES.errorBank, e);
    showToast('已标记为解决');
    renderErrorBank(document.getElementById('app'));
  }
}

async function retryVocabError(id) {
  const e = await dbGet(STORES.errorBank, id);
  if (e && e.vocab_id) {
    startVocabRetry([e.vocab_id]);
  }
}

async function retryExpressionError(id) {
  navTo('review');
  showToast('进入复习模式');
}
