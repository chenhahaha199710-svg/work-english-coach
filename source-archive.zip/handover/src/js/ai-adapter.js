// ===== Local AI Adapter =====
// V1 使用本地规则和模板，未来可替换为 RemoteAIAdapter

const LocalAIAdapter = {
  isLocal: true,

  // 分析导入语料
  analyzeCorpus(text) {
    const results = {
      scenarios: [],
      roles: [],
      business_objects: [],
      problems: [],
      causes: [],
      actions: [],
      metrics: [],
      questions: [],
      answers: [],
      learning_items: [],
      needs_confirmation: true,
      confidence: 0.4
    };

    // 关键词场景识别
    const scenarioKeywords = {
      '工单': 'sc-ticket', 'ticket': 'sc-ticket',
      '维修': 'sc-repair', 'repair': 'sc-repair', 'fix': 'sc-repair',
      '换新': 'sc-repair', 'replace': 'sc-repair',
      '延迟': 'sc-delay', 'delay': 'sc-delay', 'late': 'sc-delay',
      '原因': 'sc-reason', 'reason': 'sc-reason', 'because': 'sc-reason',
      '数据': 'sc-data', 'data': 'sc-data', 'rate': 'sc-data', 'percent': 'sc-data',
      '超时': 'sc-timeout', 'overdue': 'sc-timeout', 'timeout': 'sc-timeout',
      '业主': 'sc-owner-comm', 'owner': 'sc-owner-comm',
      '资管': 'sc-asset-mgmt', 'asset': 'sc-asset-mgmt',
      'SOP': 'sc-sop', '流程': 'sc-sop', 'procedure': 'sc-sop',
      '升级': 'sc-sop', 'escalat': 'sc-sop',
      '兜底': 'sc-fallback', 'backup': 'sc-fallback', 'fallback': 'sc-fallback',
      '协助': 'sc-request-help', 'help': 'sc-request-help', 'support': 'sc-request-help',
      '下一步': 'sc-nextstep', 'next step': 'sc-nextstep',
      '负责人': 'sc-confirm', 'responsible': 'sc-confirm', 'deadline': 'sc-confirm',
      '汇报': 'sc-reporting', 'report': 'sc-reporting', 'update': 'sc-reporting'
    };

    const lowerText = text.toLowerCase();
    for (const [kw, scenarioId] of Object.entries(scenarioKeywords)) {
      if (lowerText.includes(kw.toLowerCase()) && !results.scenarios.includes(scenarioId)) {
        results.scenarios.push(scenarioId);
      }
    }

    // 提取角色
    const roleKeywords = { '领导': 'manager', 'manager': 'manager', '同事': 'colleague', 'colleague': 'colleague',
      '业主': 'owner', 'owner': 'owner', '资管': 'asset', '城市': 'city_ops', 'city': 'city_ops' };
    for (const [kw, role] of Object.entries(roleKeywords)) {
      if (lowerText.includes(kw.toLowerCase()) && !results.roles.includes(role)) {
        results.roles.push(role);
      }
    }

    // 提取候选表达（简单提取英文句子）
    const sentences = text.match(/[A-Z][a-z].*?[.!?]/g) || [];
    const learningCandidates = sentences.filter(s => s.length > 15 && s.length < 200).slice(0, 20);
    results.learning_items = learningCandidates.map(s => ({
      english: s.trim(), chinese: '', type: 'work_expression',
      source: 'import', scenario_id: results.scenarios[0] || 'other'
    }));

    return results;
  },

  // 生成每日课程（基于当前天和到期复习）
  generateDailySession(studyDay, settings, dueItems, newItemCount) {
    const lesson = DAILY_LESSONS.find(l => l.day === studyDay) || DAILY_LESSONS[0];
    return {
      day: studyDay,
      theme: lesson.theme,
      theme_en: lesson.theme_en,
      listening: lesson.listening,
      review_items: dueItems.slice(0, 10),
      learn_items: lesson.itemIds.slice(0, newItemCount),
      learn_patterns: lesson.patternIds,
      work_practice: lesson.workPractice,
      daily_challenge: lesson.challenge,
      estimated_minutes: settings.dailyMinutes || 25
    };
  },

  // 评估用户回答（基于规则）
  evaluateAnswer(userAnswer, referenceAnswer, opts = {}) {
    const { type = 'work_practice' } = opts;
    const answer = (userAnswer || '').trim().toLowerCase();
    const ref = (referenceAnswer || '').trim().toLowerCase();

    if (!answer || answer.length < 5) {
      return {
        communication_success: 0,
        clarity_score: 0,
        naturalness_score: 0,
        work_fit_score: 0,
        better_version: referenceAnswer || '',
        key_expressions: [],
        error_tags: ['too_short', 'no_answer'],
        feedback: '回答太短或没有内容。请尝试用完整的句子回答。'
      };
    }

    // 简单匹配关键词
    const refWords = ref.split(/\s+/).filter(w => w.length > 3);
    const matched = refWords.filter(w => answer.includes(w));
    const matchRatio = matched.length / Math.max(1, refWords.length);

    // 检查是否有关键句型
    const patterns = ref.match(/[A-Z][a-z]+ [a-z]+ [a-z]+/g) || [];
    const patternMatch = patterns.filter(p => answer.includes(p.toLowerCase()));

    const clarityScore = Math.min(100, Math.round(matchRatio * 60 + (answer.length > 30 ? 20 : 0) + (patternMatch.length > 0 ? 20 : 0)));
    const naturalnessScore = Math.min(100, Math.round(matchRatio * 50 + (answer.length > 50 ? 25 : 0) + (patternMatch.length > 1 ? 25 : 0)));
    const workFitScore = Math.min(100, Math.round(matchRatio * 70 + (patternMatch.length > 0 ? 30 : 0)));
    const commScore = Math.min(100, Math.round((clarityScore + workFitScore) / 2));

    const errorTags = [];
    if (matchRatio < 0.2) errorTags.push('missing_key_points');
    if (answer.length < 20) errorTags.push('too_brief');
    if (!answer.includes('.')) errorTags.push('no_complete_sentence');

    // 提取关键表达
    const keyExpressions = refWords.filter(w => w.length > 4 && answer.includes(w)).slice(0, 5);

    let feedback = '';
    if (commScore >= 70) {
      feedback = '回答清晰，涵盖了关键要点。可以尝试使用更多自然的表达。';
    } else if (commScore >= 40) {
      feedback = '回答涵盖了部分要点，但还可以更完整。参考推荐回答补充缺失内容。';
    } else {
      feedback = '回答与参考答案差距较大。建议先学习关键表达，再尝试组织回答。';
    }

    return {
      communication_success: commScore,
      clarity_score: clarityScore,
      naturalness_score: naturalnessScore,
      work_fit_score: workFitScore,
      better_version: referenceAnswer || '',
      key_expressions: keyExpressions,
      error_tags: errorTags,
      feedback: feedback
    };
  },

  // 生成本地对话追问
  generateFollowUp(scenarioId, userResponse, round, history) {
    const scenario = CONVERSATION_SCENARIOS.find(s => s.id === scenarioId);
    if (!scenario) return null;

    if (round >= scenario.rounds) {
      return { task_complete: true, final_feedback: '对话完成。请回顾你的回答，看看哪些表达可以改进。' };
    }

    const branches = scenario.branches;
    const lowerResp = (userResponse || '').toLowerCase();

    // 关键词匹配
    for (const branch of branches) {
      if (branch.trigger === 'start' && round === 0) continue; // skip start on non-first
      if (branch.trigger.startsWith('keyword:')) {
        const keywords = branch.trigger.replace('keyword:', '').split('|');
        if (keywords.some(kw => lowerResp.includes(kw))) {
          return { next_question: branch.question, follow_up_reason: branch.key_points.join(', '), task_complete: false };
        }
      }
    }

    // 默认分支
    const defaultBranch = branches.find(b => b.trigger === 'default');
    if (defaultBranch) {
      return { next_question: defaultBranch.question, follow_up_reason: defaultBranch.key_points.join(', '), task_complete: false };
    }

    // 兜底
    const nextBranch = branches[Math.min(round, branches.length - 1)];
    return { next_question: nextBranch.question, follow_up_reason: nextBranch.key_points.join(', '), task_complete: false };
  },

  // 获取对话开场
  getOpening(scenarioId) {
    const scenario = CONVERSATION_SCENARIOS.find(s => s.id === scenarioId);
    if (!scenario) return null;
    const startBranch = scenario.branches.find(b => b.trigger === 'start');
    return startBranch ? startBranch.question : 'Let\'s start. Can you tell me about the situation?';
  }
};

// ===== AI Service Interface (预留) =====
const AIServiceInterface = {
  // 未来接入后端GPT代理时实现
  analyzeCorpus: null,       // (text) => Promise<analysisResult>
  generateDailySession: null, // (opts) => Promise<session>
  evaluateAnswer: null,      // (answer, reference, opts) => Promise<evaluation>
  generateFollowUp: null,    // (scenarioId, response, round, history) => Promise<followUp>
  summarizeConversation: null // (history) => Promise<summary>
};

// V1 使用本地适配器
const AIAdapter = LocalAIAdapter;

// ===== Speech Utils =====
const SpeechUtils = {
  synth: window.speechSynthesis || null,
  recognition: null,
  currentUtterance: null,

  isTTSAvailable() {
    return !!(window.speechSynthesis && window.SpeechSynthesisUtterance);
  },

  isSTTAvailable() {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  },

  speak(text, opts = {}) {
    if (!this.isTTSAvailable()) return false;
    this.stop();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = opts.rate || 1.0;
    utterance.pitch = opts.pitch || 1;

    if (opts.onend) utterance.onend = opts.onend;
    if (opts.onerror) utterance.onerror = opts.onerror;

    this.currentUtterance = utterance;
    this.synth.speak(utterance);
    return true;
  },

  stop() {
    if (this.synth) this.synth.cancel();
    this.currentUtterance = null;
  },

  pause() {
    if (this.synth) this.synth.pause();
  },

  resume() {
    if (this.synth) this.synth.resume();
  },

  startRecognition(opts = {}) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return null;

    const recognition = new SR();
    recognition.lang = 'en-US';
    recognition.continuous = opts.continuous || false;
    recognition.interimResults = opts.interimResults || false;

    if (opts.onresult) recognition.onresult = opts.onresult;
    if (opts.onerror) recognition.onerror = opts.onerror;
    if (opts.onend) recognition.onend = opts.onend;

    recognition.start();
    this.recognition = recognition;
    return recognition;
  },

  stopRecognition() {
    if (this.recognition) {
      this.recognition.stop();
      this.recognition = null;
    }
  }
};
