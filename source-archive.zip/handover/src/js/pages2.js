// ===== Quiz Page =====
let quizState = null;

async function renderQuiz(app) {
  const allItems = await dbGetAll(STORES.knowledgeItems);
  const allMastery = await dbGetAll(STORES.masteryRecords);
  const masteryMap = {};
  allMastery.forEach(m => masteryMap[m.item_id] = m);

  // 随机选题（优先非Mastered）
  const candidates = allItems.filter(i => {
    const m = masteryMap[i.id];
    return !m || m.mastery_state !== 'Mastered';
  });
  const quizItems = candidates.sort(() => Math.random() - 0.5).slice(0, 10);

  quizState = {
    items: quizItems,
    idx: 0,
    answers: [],
    startTime: Date.now()
  };

  renderQuizQuestion(app);
}

function renderQuizQuestion(app) {
  if (quizState.idx >= quizState.items.length) {
    renderQuizResult(app);
    return;
  }

  const item = quizState.items[quizState.idx];
  const qType = ['cn-to-en', 'fill-blank', 'multi-choice'][Math.floor(Math.random() * 3)];

  let questionHTML = '';
  switch(qType) {
    case 'cn-to-en':
      questionHTML = `
        <div class="text-secondary text-sm mb-sm">看到中文，写出英文表达</div>
        <div style="font-size: 20px; font-weight: 600; padding: 16px; background: var(--color-bg-subtle); border-radius: 12px;">${item.chinese}</div>
      `;
      break;
    case 'fill-blank':
      const words = item.example_sentence.split(' ');
      const blankIdx = Math.min(words.length - 1, Math.floor(words.length / 2));
      const blankWord = words[blankIdx];
      questionHTML = `
        <div class="text-secondary text-sm mb-sm">填空</div>
        <div style="font-size: 17px; padding: 16px; background: var(--color-bg-subtle); border-radius: 12px; line-height: 1.8;">${words.map((w,i) => i === blankIdx ? '____' : w).join(' ')}</div>
      `;
      break;
    case 'multi-choice':
      const otherItems = quizState.items.filter(i => i.id !== item.id).sort(() => Math.random() - 0.5).slice(0, 3);
      const options = [item, ...otherItems].sort(() => Math.random() - 0.5);
      questionHTML = `
        <div class="text-secondary text-sm mb-sm">选择正确的英文表达</div>
        <div style="font-size: 18px; font-weight: 600; padding: 16px; background: var(--color-bg-subtle); border-radius: 12px; margin-bottom: 12px;">${item.chinese}</div>
        ${options.map((opt, i) => `
          <div class="list-item card-clickable" onclick="answerMC('${opt.id}', '${item.id}')">
            <div class="list-item-icon" style="background: var(--color-bg-subtle); font-weight: 600;">${String.fromCharCode(65+i)}</div>
            <div class="list-item-content"><div class="list-item-title">${opt.english}</div></div>
          </div>
        `).join('')}
      `;
      break;
  }

  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <div class="flex justify-between items-center">
          <h2>Quiz</h2>
          <span class="badge badge-primary">${quizState.idx + 1} / ${quizState.items.length}</span>
        </div>
        <div class="progress-bar mt-md"><div class="progress-bar-fill" style="width: ${quizState.idx / quizState.items.length * 100}%"></div></div>
      </div>

      <div class="card">
        ${questionHTML}
      </div>

      ${qType !== 'multi-choice' ? `
      <div class="card">
        <textarea id="quiz-answer" placeholder="输入你的回答..." style="min-height: 80px;"></textarea>
        <button class="btn btn-primary btn-block mt-md" onclick="submitQuizAnswer('${item.id}', '${qType}')">提交</button>
      </div>
      ` : ''}

      <button class="btn btn-ghost btn-sm mt-md" onclick="navTo('more')">退出</button>
    </div>
  `;
}

function answerMC(selectedId, correctId) {
  quizState.answers.push({ item_id: correctId, correct: selectedId === correctId, answer: selectedId });
  quizState.idx++;
  renderQuizQuestion(document.getElementById('app'));
}

async function submitQuizAnswer(itemId, qType) {
  const answer = document.getElementById('quiz-answer').value.trim();
  const item = await dbGet(STORES.knowledgeItems, itemId);
  let correct = false;
  if (qType === 'cn-to-en') {
    correct = answer.toLowerCase().includes(item.english.toLowerCase().split(' ')[0]) || answer.toLowerCase() === item.english.toLowerCase();
  } else if (qType === 'fill-blank') {
    const blankWord = item.example_sentence.split(' ')[Math.floor(item.example_sentence.split(' ').length / 2)];
    correct = answer.toLowerCase().includes(blankWord.toLowerCase());
  }

  quizState.answers.push({ item_id: itemId, correct, answer });
  quizState.idx++;
  renderQuizQuestion(document.getElementById('app'));
}

async function renderQuizResult(app) {
  const correct = quizState.answers.filter(a => a.correct).length;
  const total = quizState.answers.length;
  const score = Math.round(correct / total * 100);

  // 记录测验
  await dbPut(STORES.quizAttempts, {
    id: uuid(), date: todayStr(), score, total, correct,
    duration: Date.now() - quizState.startTime
  });

  app.innerHTML = `
    <div class="container page">
      <div style="padding: 40px 20px; text-align: center;">
        <div style="font-size: 64px;">${score >= 70 ? '🎉' : score >= 40 ? '💪' : '📚'}</div>
        <h1 style="margin-top: 16px;">${score} 分</h1>
        <p class="text-secondary mt-sm">${correct} / ${total} 正确</p>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">答题详情</div>
        ${quizState.answers.map((a, i) => `
          <div class="flex justify-between" style="padding: 8px 0; border-bottom: 1px solid var(--color-border-light);">
            <span class="text-sm">第 ${i+1} 题</span>
            <span class="badge ${a.correct ? 'badge-mint' : 'badge-coral'}">${a.correct ? '✓ 正确' : '✗ 错误'}</span>
          </div>
        `).join('')}
      </div>

      <button class="btn btn-primary btn-block btn-lg mt-lg" onclick="navTo('more')">完成</button>
    </div>
  `;
}

// ===== AI Conversation Page =====
let convState = null;

function renderConversation(app) {
  showBottomNav();
  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <h2>AI Conversation</h2>
        <p class="text-secondary text-sm mt-sm">本地情景对话练习 · 3-5轮连续对话</p>
      </div>

      <div class="card" style="background: var(--color-bg-subtle);">
        <div class="text-light text-xs mb-sm">⚠️ 当前为本地情景对话模式；智能追问与AI评分接口已预留。</div>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">选择对话场景</div>
        ${CONVERSATION_SCENARIOS.map(s => `
          <div class="list-item card-clickable" onclick="startConversation('${s.id}')">
            <div class="list-item-icon" style="background: rgba(26,107,78,0.1);">💬</div>
            <div class="list-item-content">
              <div class="list-item-title">${s.role} · ${s.scenario}</div>
              <div class="list-item-subtitle">${s.goal} · ${s.rounds} 轮</div>
            </div>
            <div class="list-item-action">→</div>
          </div>
        `).join('')}
      </div>

      <button class="btn btn-ghost btn-sm mt-md" onclick="navTo('more')">返回</button>
    </div>
  `;
}

async function startConversation(scenarioId) {
  const scenario = CONVERSATION_SCENARIOS.find(s => s.id === scenarioId);
  if (!scenario) return;

  convState = {
    scenario,
    round: 0,
    history: [],
    startTime: Date.now()
  };

  const opening = AIAdapter.getOpening(scenarioId);
  convState.history.push({ role: 'ai', text: opening });

  renderConversationActive(document.getElementById('app'));
}

// 隐藏底部导航（进入沉浸式对话模式）
function hideBottomNav() {
  const nav = document.querySelector('.bottom-nav');
  if (nav) nav.classList.add('hidden');
  document.body.classList.add('no-nav');
}

// 恢复底部导航
function showBottomNav() {
  const nav = document.querySelector('.bottom-nav');
  if (nav) nav.classList.remove('hidden');
  document.body.classList.remove('no-nav');
}

function renderConversationActive(app) {
  const s = convState.scenario;
  hideBottomNav();
  app.innerHTML = `
    <div class="container page conv-page-content">
      <div class="session-bar">
        <div class="flex items-center gap-sm">
          <button class="btn btn-ghost btn-sm" onclick="exitConversation()">←</button>
          <div>
            <div style="font-weight: 600; font-size: 14px;">${s.role}</div>
            <div class="text-light text-xs">${s.scenario}</div>
          </div>
        </div>
        <span class="badge badge-primary">轮 ${convState.round + 1} / ${s.rounds}</span>
      </div>

      <div style="padding: 12px 0;">
        <div class="text-secondary text-sm mb-sm">对话目标</div>
        <div class="text-sm">${s.goal}</div>
      </div>

      <div id="conv-messages" style="padding-bottom: 20px;">
        ${convState.history.map(h => `
          <div class="card" style="margin-bottom: 8px; ${h.role === 'ai' ? '' : 'background: var(--color-bg-subtle);'}">
            <div class="text-light text-xs mb-sm">${h.role === 'ai' ? s.role : '你'}</div>
            <div style="font-size: 16px; line-height: 1.6;">${h.text}</div>
          </div>
        `).join('')}
      </div>
    </div>

    <div class="conv-input-bar">
      <div class="flex gap-sm">
        <input type="text" id="conv-answer" placeholder="用英语回答..." style="flex: 1; min-height: 44px;" onkeydown="if(event.key==='Enter') submitConversation()">
        <button class="btn btn-ghost btn-sm" style="min-height: 44px; min-width: 44px;" onclick="convVoiceInput()">🎤</button>
        <button class="btn btn-primary btn-sm" style="min-height: 44px; padding: 0 20px;" onclick="submitConversation()">发送</button>
      </div>
    </div>
  `;
  document.getElementById('conv-messages').scrollIntoView({ behavior: 'smooth', block: 'end' });
}

function exitConversation() {
  showBottomNav();
  convState = null;
  navTo('conversation');
}

function convVoiceInput() {
  if (!SpeechUtils.isSTTAvailable()) { showToast('不支持语音识别'); return; }
  showToast('录音中...');
  const input = document.getElementById('conv-answer');
  SpeechUtils.startRecognition({
    onresult: (e) => { input.value = Array.from(e.results).map(r => r[0].transcript).join(''); },
    onend: () => showToast('录音结束'),
    onerror: () => showToast('语音识别出错')
  });
}

async function submitConversation() {
  const answer = document.getElementById('conv-answer').value.trim();
  if (!answer) return;

  convState.history.push({ role: 'user', text: answer });
  convState.round++;

  const followUp = AIAdapter.generateFollowUp(convState.scenario.id, answer, convState.round, convState.history);

  if (followUp.task_complete) {
    // 对话结束
    await dbPut(STORES.conversationSessions, {
      id: uuid(), date: todayStr(),
      scenario_id: convState.scenario.id, role: convState.scenario.role,
      history: convState.history, duration: Date.now() - convState.startTime
    });

    renderConversationResult(document.getElementById('app'), followUp.final_feedback);
  } else {
    convState.history.push({ role: 'ai', text: followUp.next_question });
    renderConversationActive(document.getElementById('app'));
    document.getElementById('conv-answer').value = '';
  }
}

function renderConversationResult(app, feedback) {
  showBottomNav();
  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <h2>对话复盘</h2>
        <p class="text-secondary text-sm mt-sm">${convState.scenario.role} · ${convState.scenario.scenario}</p>
      </div>

      <div class="card" style="background: var(--color-bg-subtle);">
        <div class="text-secondary text-sm">📋 ${feedback || '对话完成'}</div>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">对话记录</div>
        ${convState.history.map(h => `
          <div style="margin-bottom: 12px;">
            <div class="text-light text-xs">${h.role === 'ai' ? convState.scenario.role : '你'}</div>
            <div style="font-size: 16px; line-height: 1.6; ${h.role === 'user' ? 'color: var(--color-text);' : 'color: var(--color-text-secondary);'}">${h.text}</div>
          </div>
        `).join('')}
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-sm">自我评价</div>
        <div class="rating-group">
          <button class="rating-btn again" onclick="rateConversation('again')">不满意</button>
          <button class="rating-btn hard" onclick="rateConversation('hard')">一般</button>
          <button class="rating-btn good" onclick="rateConversation('good')">不错</button>
          <button class="rating-btn easy" onclick="rateConversation('easy')">很好</button>
        </div>
        <button class="btn btn-coral btn-sm btn-block mt-md" onclick="addConvToErrorBank()">将不满意的回答加入错题本</button>
      </div>

      <div class="flex gap-md mt-lg">
        <button class="btn btn-outline flex-1" onclick="navTo('conversation')">换场景</button>
        <button class="btn btn-primary flex-1" onclick="navTo('more')">完成</button>
      </div>
    </div>
  `;
}

async function rateConversation(rating) {
  await updateSkillScore('answer_followups', rating === 'good' || rating === 'easy');
  await updateSkillScore('continuous_speaking', rating === 'good' || rating === 'easy');
  showToast('已记录');
  navTo('more');
}

async function addConvToErrorBank() {
  const userMsgs = convState.history.filter(h => h.role === 'user');
  if (userMsgs.length === 0) { showToast('没有用户回答可加入'); return; }
  const lastMsg = userMsgs[userMsgs.length - 1];
  await dbPut(STORES.errorBank, {
    id: uuid(), original_answer: lastMsg.text,
    better_answer: '(参考对话中的AI提问)', error_type: 'conversation_weakness',
    error_tag: 'follow_up_failure', explanation: 'AI对话中回答不够完整或自然',
    scenario_id: convState.scenario.id, occurrence_count: 1,
    first_seen_at: new Date().toISOString(), last_seen_at: new Date().toISOString(),
    next_review_at: Date.now() + 86400000, resolved: false
  });
  showToast('已加入错题本');
}

// ===== Import Page =====
function renderImportPage(app) {
  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <h2>导入工作对话</h2>
        <p class="text-secondary text-sm mt-sm">从 ChatGPT 工作对话中提取学习内容</p>
      </div>

      <div class="card" style="background: var(--color-bg-subtle);">
        <div class="text-light text-xs">⚠️ 当前使用本地规则进行初步分类。未来接入AI服务后，可进行语义清洗、自然英语生成和更准确的场景识别。</div>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">选择导入方式</div>
        <div class="flex gap-sm" style="flex-wrap: wrap;">
          <button class="chip active" onclick="switchImportMode('paste', this)">粘贴文本</button>
          <button class="chip" onclick="switchImportMode('file', this)">上传文件</button>
        </div>
      </div>

      <div id="import-paste" class="card">
        <div class="text-secondary text-sm mb-sm">粘贴对话内容</div>
        <textarea id="import-text" placeholder="粘贴 ChatGPT 对话内容..." style="min-height: 150px;"></textarea>
        <button class="btn btn-primary btn-block mt-md" onclick="processImport()">分析并导入</button>
      </div>

      <div id="import-file" class="card" style="display:none;">
        <div class="text-secondary text-sm mb-sm">上传文件（.txt / .md / .json）</div>
        <input type="file" id="import-file-input" accept=".txt,.md,.json" onchange="handleFileImport(event)">
        <div class="text-light text-xs mt-sm">支持 ChatGPT 导出的 conversations.json</div>
      </div>

      <div id="import-result" style="display:none;"></div>
    </div>
  `;
}

function switchImportMode(mode, btn) {
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('import-paste').style.display = mode === 'paste' ? 'block' : 'none';
  document.getElementById('import-file').style.display = mode === 'file' ? 'block' : 'none';
}

async function handleFileImport(event) {
  const file = event.target.files[0];
  if (!file) return;

  const maxSize = 5 * 1024 * 1024; // 5MB
  if (file.size > maxSize) {
    showToast('文件过大（最大5MB）');
    return;
  }

  const reader = new FileReader();
  reader.onload = async (e) => {
    const text = e.target.result;

    // 如果是JSON，尝试解析ChatGPT格式
    if (file.name.endsWith('.json')) {
      try {
        const data = JSON.parse(text);
        if (data && Array.isArray(data)) {
          // ChatGPT conversations.json 格式
          let allText = '';
          for (const conv of data) {
            if (conv.title) allText += conv.title + '\n';
            if (conv.mapping) {
              for (const node of Object.values(conv.mapping)) {
                if (node.message && node.message.content && node.message.content.parts) {
                  const role = node.message.author?.role || '';
                  if (role === 'user' || role === 'assistant') {
                    allText += role + ': ' + node.message.content.parts.join(' ') + '\n';
                  }
                }
              }
            }
          }
          await processImportText(allText, file.name);
          return;
        }
      } catch (err) {
        // JSON解析失败，当作普通文本处理
      }
    }
    await processImportText(text, file.name);
  };
  reader.readAsText(file);
}

async function processImport() {
  const text = document.getElementById('import-text').value.trim();
  if (!text || text.length < 10) {
    showToast('请输入对话内容');
    return;
  }
  await processImportText(text, 'paste-' + Date.now());
}

async function processImportText(text, sourceName) {
  const resultDiv = document.getElementById('import-result');
  resultDiv.style.display = 'block';
  resultDiv.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

  // 清洗：去除时间戳、角色标签等
  const cleaned = text
    .replace(/^\[\d{4}-\d{2}-\d{2}.*?\]/gm, '')
    .replace(/^User:?\s/gm, '')
    .replace(/^Assistant:?\s/gm, '')
    .replace(/^Human:?\s/gm, '')
    .replace(/^AI:?\s/gm, '')
    .replace(/```[\s\S]*?```/g, '') // 去除代码块
    .replace(/^>.*$/gm, '') // 去除引用
    .trim();

  // 分析
  const analysis = AIAdapter.analyzeCorpus(cleaned);

  // 保存导入记录
  const importId = uuid();
  await dbPut(STORES.imports, {
    id: importId,
    source_name: sourceName,
    import_date: new Date().toISOString(),
    original_text: text,
    cleaned_text: cleaned,
    status: 'processed',
    scenario_count: analysis.scenarios.length,
    item_count: analysis.learning_items.length
  });

  // 将提取的学习项保存到知识库
  let addedCount = 0;
  for (const item of analysis.learning_items) {
    if (item.english && item.english.length > 15) {
      const newItem = {
        id: uuid(),
        type: item.type || 'work_expression',
        english: item.english,
        chinese: item.chinese || '(待翻译)',
        example_sentence: item.english,
        work_context: '导入内容',
        scenario_id: item.scenario_id || 'other',
        source_conversation_id: importId,
        source: 'import',
        difficulty: 3,
        work_relevance: 3,
        frequency: 2,
        reusability: 3,
        communication_value: 3,
        status: 'needs_confirmation',
        needs_confirmation: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      await dbPut(STORES.knowledgeItems, newItem);

      const mastery = WEC_Algo.initMastery(newItem.id);
      await dbPut(STORES.masteryRecords, mastery);
      await dbPut(STORES.reviewSchedule, {
        item_id: newItem.id, next_review_at: Date.now(),
        interval_days: 0, review_count: 0, mastery_state: 'New'
      });
      addedCount++;
    }
  }

  resultDiv.innerHTML = `
    <div class="card">
      <div class="text-secondary text-sm mb-md">导入结果</div>
      <div class="flex justify-between mb-sm"><span>识别场景</span><span class="badge badge-gray">${analysis.scenarios.length}</span></div>
      <div class="flex justify-between mb-sm"><span>提取表达</span><span class="badge badge-mint">${addedCount}</span></div>
      <div class="flex justify-between mb-sm"><span>识别角色</span><span class="badge badge-gray">${analysis.roles.length}</span></div>
      <div class="flex justify-between"><span>处理状态</span><span class="badge badge-gold">需确认</span></div>
      <div class="text-light text-xs mt-md">提取的内容已标记为「需确认」，不会自动加入课程。请在 Knowledge Base 中查看和编辑。</div>
    </div>

    ${analysis.scenarios.length > 0 ? `
    <div class="card">
      <div class="text-secondary text-sm mb-sm">识别到的场景</div>
      ${analysis.scenarios.map(sid => {
        const s = SCENARIOS.find(s => s.id === sid);
        return s ? `<div class="badge badge-gray" style="margin: 2px;">${s.name}</div>` : '';
      }).join('')}
    </div>
    ` : ''}

    <div class="flex gap-md mt-lg">
      <button class="btn btn-outline flex-1" onclick="navTo('import')">继续导入</button>
      <button class="btn btn-primary flex-1" onclick="navTo('knowledge-base')">查看知识库</button>
    </div>
  `;
}

// ===== Backup Page =====
function renderBackupPage(app) {
  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <h2>数据备份与恢复</h2>
        <p class="text-secondary text-sm mt-sm">导出/导入全部学习数据</p>
      </div>

      <div class="card" style="background: var(--color-bg-subtle); border-left: 3px solid var(--color-gold);">
        <div class="text-secondary text-sm">⚠️ 重要提示</div>
        <div class="text-sm mt-sm" style="line-height: 1.6;">当前版本的数据保存在本设备。更换设备前，请先导出学习数据，再在新设备导入。</div>
      </div>

      <div class="card card-clickable" onclick="exportData()">
        <div class="flex items-center gap-md">
          <div class="list-item-icon" style="background: rgba(77,208,168,0.15);">📤</div>
          <div class="list-item-content">
            <div class="list-item-title">导出全部数据</div>
            <div class="list-item-subtitle">下载 JSON 备份文件</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">导入数据</div>
        <input type="file" id="restore-file-input" accept=".json" onchange="handleRestore(event)">
        <div class="text-light text-xs mt-sm">导入前会自动备份当前数据</div>
      </div>

      <div class="card" style="border: 1px solid var(--color-danger);">
        <div class="text-danger text-sm mb-md">⚠️ 危险操作</div>
        <div class="text-sm mb-md">重置将删除所有学习数据，包括课程进度、错题和导入记录。</div>
        <button class="btn btn-danger btn-block" onclick="confirmReset()">重置全部数据</button>
      </div>

      <button class="btn btn-ghost btn-sm mt-md" onclick="navTo('more')">返回</button>
    </div>
  `;
}

async function exportData() {
  const data = await exportAllData();
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `work-english-coach-backup-${todayStr()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('数据已导出');
}

async function handleRestore(event) {
  const file = event.target.files[0];
  if (!file) return;

  try {
    const text = await file.text();
    const data = JSON.parse(text);

    // 验证格式
    if (!data._meta || data._meta.app !== 'WorkEnglishCoach') {
      showToast('文件格式不正确：不是 Work English Coach 备份文件');
      return;
    }

    if (!confirm('导入将替换当前数据（会先备份）。确认继续？')) return;

    await importAllData(data, true);
    showToast('数据导入成功！');
    navTo('today');
  } catch (e) {
    showToast('导入失败：' + e.message);
  }
}

function confirmReset() {
  const overlay = showModal(`
    <h3 style="color: var(--color-danger);">确认重置全部数据？</h3>
    <div class="text-secondary text-sm mt-md">此操作不可撤销，将删除：</div>
    <ul class="text-sm mt-sm" style="padding-left: 20px; line-height: 1.8;">
      <li>所有学习进度</li>
      <li>所有错题记录</li>
      <li>所有导入内容</li>
      <li>所有能力评分</li>
    </ul>
    <div class="text-danger text-sm mt-md">⚠️ 建议先导出数据备份</div>
    <div class="flex gap-md mt-lg">
      <button class="btn btn-outline flex-1" onclick="closeModal()">取消</button>
      <button class="btn btn-danger flex-1" onclick="executeReset()">确认重置</button>
    </div>
  `);
}

async function executeReset() {
  await resetAllData();
  // 重新初始化知识库
  for (const item of KNOWLEDGE_ITEMS) {
    item.status = 'active';
    item.created_at = new Date().toISOString();
    item.updated_at = new Date().toISOString();
    await dbPut(STORES.knowledgeItems, item);
    const mastery = WEC_Algo.initMastery(item.id);
    await dbPut(STORES.masteryRecords, mastery);
    await dbPut(STORES.reviewSchedule, {
      item_id: item.id, next_review_at: Date.now(),
      interval_days: 0, review_count: 0, mastery_state: 'New'
    });
  }
  // 重置能力分数
  for (const skill of SKILL_DIMENSIONS) {
    await dbPut(STORES.skillScores, {
      skill_key: skill.key, name: skill.name, name_zh: skill.name_zh,
      score: 0, evidence_count: 0, updated_at: new Date().toISOString()
    });
  }
  // 重置设置中的学习状态
  updateSettings({ studyStartDate: todayStr(), currentDay: 1, streakDays: 0, totalStudyMinutes: 0, lastStudyDate: null });
  appSettings = loadSettings();
  closeModal();
  showToast('已重置全部数据');
  navTo('today');
}

// ===== Settings Page =====
function renderSettingsPage(app) {
  app.innerHTML = `
    <div class="container page">
      <div style="padding: 20px 0;">
        <h2>Settings</h2>
        <p class="text-secondary text-sm mt-sm">学习偏好和应用设置</p>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">学习设置</div>
        <div class="mb-md">
          <label class="text-sm">每日学习时间（分钟）</label>
          <div class="flex items-center gap-md mt-sm">
            <input type="range" id="set-minutes" min="15" max="45" step="5" value="${appSettings.dailyMinutes}" onchange="updateSetting('dailyMinutes', parseInt(this.value))">
            <span id="set-minutes-val" style="font-weight: 600; min-width: 50px;">${appSettings.dailyMinutes} min</span>
          </div>
        </div>
        <div class="mb-md">
          <label class="text-sm">每日新内容数量</label>
          <div class="flex items-center gap-md mt-sm">
            <input type="range" id="set-newitems" min="3" max="8" step="1" value="${appSettings.dailyNewItems}" onchange="updateSetting('dailyNewItems', parseInt(this.value))">
            <span id="set-newitems-val" style="font-weight: 600; min-width: 50px;">${appSettings.dailyNewItems} 个</span>
          </div>
        </div>
        <div>
          <label class="text-sm">语速</label>
          <div class="flex items-center gap-md mt-sm">
            <input type="range" id="set-rate" min="0.5" max="1.5" step="0.1" value="${appSettings.speechRate}" onchange="updateSetting('speechRate', parseFloat(this.value))">
            <span id="set-rate-val" style="font-weight: 600; min-width: 50px;">${appSettings.speechRate.toFixed(1)}x</span>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">语音能力</div>
        <div class="flex justify-between mb-sm">
          <span class="text-sm">文字转语音 (TTS)</span>
          ${SpeechUtils.isTTSAvailable() ? '<span class="badge badge-mint">可用</span>' : '<span class="badge badge-coral">不可用</span>'}
        </div>
        <div class="flex justify-between">
          <span class="text-sm">语音识别 (STT)</span>
          ${SpeechUtils.isSTTAvailable() ? '<span class="badge badge-mint">可用</span>' : '<span class="badge badge-coral">不可用</span>'}
        </div>
        ${!SpeechUtils.isSTTAvailable() ? '<div class="text-light text-xs mt-md">当前浏览器不支持语音识别，可使用文本输入完成所有练习。</div>' : ''}
      </div>

      <div class="card">
        <div class="text-secondary text-sm mb-md">学习状态</div>
        <div class="flex justify-between mb-sm"><span class="text-sm">开始日期</span><span class="text-sm">${appSettings.studyStartDate || '未设置'}</span></div>
        <div class="flex justify-between mb-sm"><span class="text-sm">当前天数</span><span class="text-sm">Day ${getStudyDay(appSettings)}</span></div>
        <div class="flex justify-between mb-sm"><span class="text-sm">连续学习</span><span class="text-sm">${appSettings.streakDays || 0} 天</span></div>
        <div class="flex justify-between"><span class="text-sm">累计学习</span><span class="text-sm">${appSettings.totalStudyMinutes || 0} 分钟</span></div>
      </div>

      <div class="card" style="background: var(--color-bg-subtle);">
        <div class="text-secondary text-sm mb-sm">AI 服务状态</div>
        <div class="flex justify-between mb-sm">
          <span class="text-sm">当前模式</span>
          <span class="badge badge-gold">本地适配器</span>
        </div>
        <div class="text-light text-xs">V1 使用本地规则和模板。未来接入服务端GPT代理时，只需替换 AIAdapter，不重写页面和学习逻辑。</div>
        <div class="text-light text-xs mt-sm">预留接口：analyzeCorpus() · generateDailySession() · evaluateAnswer() · generateFollowUp() · summarizeConversation()</div>
      </div>

      <button class="btn btn-ghost btn-sm mt-md" onclick="navTo('more')">返回</button>
    </div>
  `;
}

function updateSetting(key, value) {
  updateSettings({ [key]: value });
  appSettings = loadSettings();
  // 更新显示
  if (key === 'dailyMinutes') document.getElementById('set-minutes-val').textContent = value + ' min';
  if (key === 'dailyNewItems') document.getElementById('set-newitems-val').textContent = value + ' 个';
  if (key === 'speechRate') document.getElementById('set-rate-val').textContent = value.toFixed(1) + 'x';
}

// ===== Bottom Nav Setup =====
function setupBottomNav() {
  const nav = document.querySelector('.bottom-nav');
  if (!nav) return;
  nav.querySelectorAll('.nav-item').forEach(el => {
    el.addEventListener('click', () => {
      const page = el.dataset.page;
      if (page) {
        currentSession = null; // 退出session
        navTo(page);
      }
    });
  });
}

// ===== Boot =====
document.addEventListener('DOMContentLoaded', () => {
  setupBottomNav();
  // initApp 内部会在成功或失败时设置 window.__WEC_BOOT__.finished
  initApp();
});
