// ===== Course Data: 28 Days of Work English =====
// 每天包含: listening, review, learn, work_practice, daily_challenge

const SCENARIOS = [
  { id: 'sc-reporting', name: '汇报状态', name_en: 'Reporting Status' },
  { id: 'sc-ticket', name: '工单进度', name_en: 'Ticket Progress' },
  { id: 'sc-delay', name: '说明延迟', name_en: 'Explaining Delays' },
  { id: 'sc-reason', name: '解释原因', name_en: 'Explaining Reasons' },
  { id: 'sc-data', name: '汇报数据', name_en: 'Reporting Data' },
  { id: 'sc-followup', name: '回答追问', name_en: 'Answering Follow-ups' },
  { id: 'sc-nextstep', name: '下一步方案', name_en: 'Next Steps' },
  { id: 'sc-confirm', name: '确认负责人和时间', name_en: 'Confirming Owner & Deadline' },
  { id: 'sc-request-help', name: '请求协助', name_en: 'Requesting Help' },
  { id: 'sc-owner-comm', name: '业主沟通', name_en: 'Owner Communication' },
  { id: 'sc-asset-mgmt', name: '资管沟通', name_en: 'Asset Management Communication' },
  { id: 'sc-repair', name: '维修与换新', name_en: 'Repair & Replacement' },
  { id: 'sc-timeout', name: '超时处理', name_en: 'Timeout Handling' },
  { id: 'sc-fallback', name: '兜底方案', name_en: 'Fallback Plans' },
  { id: 'sc-sop', name: 'SOP与流程', name_en: 'SOP & Process' }
];

// V2 新增场景（在 corpus-v2.js 中使用）
const V2_SCENARIOS = [
  { id: 'sc-reason', name: '解释原因', name_en: 'Explaining Reasons' }, // 已存在，跳过
  { id: 'sc-fallback', name: '兜底方案', name_en: 'Fallback Plans' },   // 已存在，跳过
];
// 合并新场景（去重）
SCENARIOS.push(...V2_SCENARIOS.filter(s => !SCENARIOS.find(e => e.id === s.id)));

// 新增能力维度（V2）
const V2_SKILL_DIMENSIONS_EXTRA = [
  { key: 'explain_sop', name: 'Explain SOP', name_zh: '解释流程' },
  { key: 'confirm_owner', name: 'Confirm Owner', name_zh: '确认负责人' },
  { key: 'confirm_deadline', name: 'Confirm Deadline', name_zh: '确认截止时间' }
];

// ===== 知识库条目 =====
// 每个条目: id, type, english, chinese, chunk, sentence_pattern, example_sentence,
// natural_alternatives, common_mistakes, usage_note, work_context, scenario_id,
// difficulty, work_relevance, frequency, reusability, communication_value

const KNOWLEDGE_ITEMS = [
  // === Day 1-4: English Reactivation — 状态、时间、人物 ===
  {
    id: 'ki-001', type: 'chunk', english: 'the current status', chinese: '当前状态',
    chunk: 'the current status of', sentence_pattern: 'The current status of ___ is ___.',
    example_sentence: 'The current status of the ticket is pending.',
    natural_alternatives: ['where things stand', 'the latest on this'],
    common_mistakes: ['the now status (×)', 'current situation of (×)'],
    usage_note: '用于汇报时先给结论性状态。', work_context: '工单处理',
    scenario_id: 'sc-reporting', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'give_updates'
  },
  {
    id: 'ki-002', type: 'sentence_pattern', english: 'The current status of ___ is ___.',
    chinese: '___的当前状态是___。',
    example_sentence: 'The current status of the repair is in progress.',
    natural_alternatives: ["Right now, ___ is ___."],
    common_mistakes: ['The now status is (×)'],
    usage_note: '汇报任何工作的基础句型。', work_context: '通用汇报',
    scenario_id: 'sc-reporting', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'give_updates'
  },
  {
    id: 'ki-003', type: 'work_expression', english: 'We are currently working on it.',
    chinese: '我们目前正在处理。',
    example_sentence: 'We are currently working on the ticket and expect to resolve it by tomorrow.',
    natural_alternatives: ["We're on it.", 'We are actively handling this.'],
    common_mistakes: ['We now working (×)', 'We is working (×)'],
    usage_note: '简洁表达正在推进。', work_context: '工单处理',
    scenario_id: 'sc-reporting', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 4, communication_value: 5,
    skill_key: 'give_updates'
  },
  {
    id: 'ki-004', type: 'chunk', english: 'as of', chinese: '截至',
    chunk: 'as of + 时间', sentence_pattern: 'As of ___, ___.',
    example_sentence: 'As of today, we have resolved 15 tickets.',
    natural_alternatives: ['up to', 'through'],
    common_mistakes: ['as of now today (×)'],
    usage_note: '汇报数据时指定时间点。', work_context: '数据汇报',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data'
  },
  {
    id: 'ki-005', type: 'word', english: 'pending', chinese: '待处理/待确认',
    phonetic: '/ˈpendɪŋ/',
    example_sentence: 'The ticket is still pending approval.',
    natural_alternatives: ['awaiting', 'not yet resolved'],
    common_mistakes: ['pending of (×)'],
    usage_note: '描述等待状态的标准用词。', work_context: '工单处理',
    scenario_id: 'sc-ticket', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 4,
    skill_key: 'describe_status'
  },
  {
    id: 'ki-006', type: 'chunk', english: 'in progress', chinese: '进行中',
    chunk: 'in progress',
    example_sentence: 'The repair work is currently in progress.',
    natural_alternatives: ['underway', 'being worked on'],
    common_mistakes: ['in processing (×)', 'on progress (×)'],
    usage_note: '描述正在执行的工作。', work_context: '工单处理',
    scenario_id: 'sc-ticket', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 4,
    skill_key: 'describe_status'
  },
  {
    id: 'ki-007', type: 'work_expression', english: 'It was completed on ___.',
    chinese: '已于___完成。',
    sentence_pattern: 'It was completed on ___.',
    example_sentence: 'It was completed on Monday morning.',
    natural_alternatives: ['We finished it on ___.', 'It was done by ___.'],
    common_mistakes: ['It complete on (×)', 'It was complete in (×)'],
    usage_note: '用过去时汇报已完成事项。', work_context: '汇报',
    scenario_id: 'sc-reporting', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'give_updates'
  },
  {
    id: 'ki-008', type: 'collocation', english: 'assign ... to ...', chinese: '将...指派给...',
    chunk: 'assign to',
    example_sentence: 'I have assigned this ticket to the maintenance team.',
    natural_alternatives: ['give ... to', 'route ... to'],
    common_mistakes: ['assign for (×)'],
    usage_note: '分配任务的标准表达。', work_context: '工单分配',
    scenario_id: 'sc-confirm', difficulty: 1, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'confirm_owner'
  },
  {
    id: 'ki-009', type: 'sentence_pattern', english: 'The person responsible for ___ is ___.',
    chinese: '负责___的人是___。',
    example_sentence: 'The person responsible for this case is Zhang Wei.',
    natural_alternatives: ['___ is handling ___.', '___ is in charge of ___.'],
    common_mistakes: ['The responsible person of (×)'],
    usage_note: '确认责任人的正式句型。', work_context: '责任确认',
    scenario_id: 'sc-confirm', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'confirm_owner'
  },
  {
    id: 'ki-010', type: 'chunk', english: 'by the end of', chinese: '在...之前/到...结束时',
    chunk: 'by the end of + 时间',
    example_sentence: 'We need to finish this by the end of the week.',
    natural_alternatives: ['before', 'no later than'],
    common_mistakes: ['until the end of (×)'],
    usage_note: '确认截止时间的标准表达。', work_context: '时间确认',
    scenario_id: 'sc-confirm', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'confirm_deadline'
  },

  // === Day 5-8: 延迟、原因、数据 ===
  {
    id: 'ki-011', type: 'chunk', english: 'a delay in', chinese: '在...方面的延迟',
    chunk: 'a delay in + 名词/动名词',
    example_sentence: 'There has been a delay in resolving this case.',
    natural_alternatives: ['a holdup in', 'a lag in'],
    common_mistakes: ['a delay of resolve (×)', 'a delay on (×)'],
    usage_note: '描述延迟的标准搭配，后接动名词。', work_context: '工单处理',
    scenario_id: 'sc-delay', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'explain_reasons'
  },
  {
    id: 'ki-012', type: 'work_expression', english: 'The main reason for the delay is that ___',
    chinese: '延迟的主要原因是___',
    sentence_pattern: 'The main reason for the delay is that ___.',
    example_sentence: 'The main reason for the delay is that we have not received a clear solution yet.',
    natural_alternatives: ['The delay is mainly because ___', 'We were delayed because ___'],
    common_mistakes: ['The main reason of delay is (×)'],
    usage_note: '解释延迟原因的核心句型。', work_context: '延迟说明',
    scenario_id: 'sc-delay', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'explain_reasons'
  },
  {
    id: 'ki-013', type: 'sentence_pattern', english: 'The reason why ___ is that ___.',
    chinese: '___的原因是___。',
    example_sentence: 'The reason why the ticket is still open is that we are waiting for the spare part.',
    natural_alternatives: ['___ because ___'],
    common_mistakes: ['The reason why is because (×) — 语义重复'],
    usage_note: '正式解释原因的标准句型。', work_context: '通用解释',
    scenario_id: 'sc-reason', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'explain_reasons'
  },
  {
    id: 'ki-014', type: 'chunk', english: 'due to', chinese: '由于',
    chunk: 'due to + 名词',
    example_sentence: 'The delay was due to a supply shortage.',
    natural_alternatives: ['because of', 'caused by'],
    common_mistakes: ['due to the fact that (过于啰嗦)', 'due to he (×, 应接名词)'],
    usage_note: '后接名词，不接从句。', work_context: '原因解释',
    scenario_id: 'sc-reason', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'explain_reasons'
  },
  {
    id: 'ki-015', type: 'work_expression', english: 'compared to last week', chinese: '与上周相比',
    chunk: 'compared to + 时间段',
    example_sentence: 'Compared to last week, our resolution rate has improved by 5%.',
    natural_alternatives: ['versus last week', 'in comparison with last week'],
    common_mistakes: ['compare to (×, 缺ed)'],
    usage_note: '数据对比的标准表达。', work_context: '数据分析',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data'
  },
  {
    id: 'ki-016', type: 'sentence_pattern', english: '___ increased/decreased by ___% compared to ___.',
    chinese: '___与___相比增加了/减少了___%。',
    example_sentence: 'The ticket volume decreased by 12% compared to last month.',
    natural_alternatives: ['___ went up/down by ___%'],
    common_mistakes: ['increased to 5% (×, to是增到而非增了)'],
    usage_note: 'by 表示增减幅度，to 表示增减到。', work_context: '数据汇报',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'report_data'
  },
  {
    id: 'ki-017', type: 'work_expression', english: 'The completion rate is ___.',
    chinese: '完成率是___。',
    example_sentence: 'The completion rate for this week is 85%.',
    natural_alternatives: ['We completed ___% of ___'],
    common_mistakes: ['The complete rate (×, 应为completion)'],
    usage_note: '汇报完成率的标准表达。', work_context: '数据汇报',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data'
  },
  {
    id: 'ki-018', type: 'chunk', english: 'waiting for', chinese: '等待',
    chunk: 'waiting for + 名词',
    example_sentence: 'We are still waiting for the owner\'s confirmation.',
    natural_alternatives: ['pending', 'expecting'],
    common_mistakes: ['waiting (×, 缺for)'],
    usage_note: '注意要加for。', work_context: '工单处理',
    scenario_id: 'sc-ticket', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 4,
    skill_key: 'describe_status'
  },

  // === Day 9-12: 回答追问、下一步 ===
  {
    id: 'ki-019', type: 'work_expression', english: 'That\'s a good question. Let me clarify.',
    chinese: '这是个好问题，让我澄清一下。',
    example_sentence: 'That\'s a good question. Let me clarify the timeline for you.',
    natural_alternatives: ['Let me explain that in more detail.', 'I can clarify that.'],
    common_mistakes: ['Let me clear (×)'],
    usage_note: '被追问时的缓冲句，争取思考时间。', work_context: '会议沟通',
    scenario_id: 'sc-followup', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'answer_followups'
  },
  {
    id: 'ki-020', type: 'sentence_pattern', english: 'What I mean is ___.',
    chinese: '我的意思是___。',
    example_sentence: 'What I mean is we need two more days to complete the repair.',
    natural_alternatives: ['To clarify, ___.', 'What I\'m saying is ___.'],
    common_mistakes: ['I mean is (×)'],
    usage_note: '澄清解释的标准句型。', work_context: '会议沟通',
    scenario_id: 'sc-followup', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'clarify_info'
  },
  {
    id: 'ki-021', type: 'work_expression', english: 'To be more specific, ___.',
    chinese: '更具体地说，___。',
    example_sentence: 'To be more specific, the issue is with the main water pipe, not the valve.',
    natural_alternatives: ['Specifically, ___.', 'To be precise, ___.'],
    common_mistakes: ['More specific (×, 缺to be)'],
    usage_note: '追问后给出更具体的信息。', work_context: '会议沟通',
    scenario_id: 'sc-followup', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'clarify_info'
  },
  {
    id: 'ki-022', type: 'work_expression', english: 'Our next step is to ___.',
    chinese: '我们的下一步是___。',
    sentence_pattern: 'Our next step is to ___.',
    example_sentence: 'Our next step is to contact the supplier and request a replacement.',
    natural_alternatives: ['We plan to ___ next.', 'Moving forward, we will ___.'],
    common_mistakes: ['Our next step is (×, 缺to)'],
    usage_note: '提出下一步方案的标准句型，后接动词原形。', work_context: '方案汇报',
    scenario_id: 'sc-nextstep', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next'
  },
  {
    id: 'ki-023', type: 'chunk', english: 'moving forward', chinese: '接下来/推进中',
    chunk: 'moving forward,',
    example_sentence: 'Moving forward, we will assign a dedicated person to each case.',
    natural_alternatives: ['going forward', 'from now on'],
    common_mistakes: ['move forward (×, 缺ing)'],
    usage_note: '提出未来改进方案的开头。', work_context: '方案汇报',
    scenario_id: 'sc-nextstep', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next'
  },
  {
    id: 'ki-024', type: 'work_expression', english: 'We plan to ___ by ___.',
    chinese: '我们计划在___之前___。',
    sentence_pattern: 'We plan to ___ by ___.',
    example_sentence: 'We plan to complete the repair by Friday afternoon.',
    natural_alternatives: ['Our target is to ___ by ___.', 'We aim to ___ by ___.'],
    common_mistakes: ['We plan by (×)'],
    usage_note: '给出具体时间和行动。', work_context: '方案汇报',
    scenario_id: 'sc-nextstep', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next'
  },

  // === Day 13-16: 请求协助、业主沟通 ===
  {
    id: 'ki-025', type: 'work_expression', english: 'Could you help me with ___?',
    chinese: '你能帮我处理___吗？',
    sentence_pattern: 'Could you help me with ___?',
    example_sentence: 'Could you help me with the owner communication? They are not responding.',
    natural_alternatives: ['Would you be able to help with ___?', 'I could use some help with ___.'],
    common_mistakes: ['Can you help me to (×, 用with更自然)'],
    usage_note: '礼貌请求协助的标准句型。', work_context: '团队协作',
    scenario_id: 'sc-request-help', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'request_help'
  },
  {
    id: 'ki-026', type: 'work_expression', english: 'I need your support on ___.',
    chinese: '我需要你在___方面的支持。',
    example_sentence: 'I need your support on getting the budget approved for the repair.',
    natural_alternatives: ['I need your help with ___.', 'Could you assist with ___?'],
    common_mistakes: ['I need you support (×, 应为your)'],
    usage_note: '更正式的请求协助表达。', work_context: '跨部门协作',
    scenario_id: 'sc-request-help', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'request_help'
  },
  {
    id: 'ki-027', type: 'work_expression', english: 'I understand your concern. Let me explain the situation.',
    chinese: '我理解您的顾虑。让我解释一下情况。',
    example_sentence: 'I understand your concern about the delay. Let me explain the situation.',
    natural_alternatives: ['I see why you\'re worried. Let me walk you through this.'],
    common_mistakes: ['I know your worry (×, 不够专业)'],
    usage_note: '面对业主不满时的共情+解释句型。', work_context: '业主沟通',
    scenario_id: 'sc-owner-comm', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'explain_problems'
  },
  {
    id: 'ki-028', type: 'work_expression', english: 'We apologize for the inconvenience.',
    chinese: '对给您带来的不便，我们深表歉意。',
    example_sentence: 'We apologize for the inconvenience caused by the water outage.',
    natural_alternatives: ['Sorry for the trouble.', 'We\'re sorry for any inconvenience.'],
    common_mistakes: ['We apologize the inconvenience (×, 缺for)'],
    usage_note: '标准道歉用语，需接for。', work_context: '业主沟通',
    scenario_id: 'sc-owner-comm', difficulty: 1, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'explain_problems'
  },
  {
    id: 'ki-029', type: 'sentence_pattern', english: 'I will personally follow up on this.',
    chinese: '我会亲自跟进这件事。',
    example_sentence: 'I will personally follow up on this and make sure it gets resolved.',
    natural_alternatives: ['I\'ll take care of this myself.', 'I\'ll keep an eye on this.'],
    common_mistakes: ['I will follow up this (×, 缺on)'],
    usage_note: '向业主或上级承诺跟进。', work_context: '业主沟通',
    scenario_id: 'sc-owner-comm', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'give_updates'
  },
  {
    id: 'ki-030', type: 'chunk', english: 'keep someone updated', chinese: '让某人保持知情',
    chunk: 'keep + 人 + updated',
    example_sentence: 'I will keep you updated on the progress.',
    natural_alternatives: ['keep someone in the loop', 'keep someone posted'],
    common_mistakes: ['keep you update (×)'],
    usage_note: '承诺持续沟通的表达。', work_context: '业主沟通',
    scenario_id: 'sc-owner-comm', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'give_updates'
  },

  // === Day 17-20: 维修换新、超时、兜底 ===
  {
    id: 'ki-031', type: 'work_expression', english: 'The part needs to be replaced.',
    chinese: '这个零件需要更换。',
    example_sentence: 'The valve is damaged and needs to be replaced.',
    natural_alternatives: ['We need a replacement for ___.', '___ has to be changed.'],
    common_mistakes: ['need to replace (×, 被动更准确)'],
    usage_note: '被动语态更客观专业。', work_context: '维修换新',
    scenario_id: 'sc-repair', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'explain_problems'
  },
  {
    id: 'ki-032', type: 'work_expression', english: 'We recommend replacing ___ rather than repairing it.',
    chinese: '我们建议更换___而不是维修。',
    example_sentence: 'We recommend replacing the pipe rather than repairing it, as it has cracked in multiple places.',
    natural_alternatives: ['It\'s better to replace ___ than to fix it.'],
    common_mistakes: ['recommend to replace (×, recommend接doing或that)'],
    usage_note: 'recommend + doing 是标准搭配。', work_context: '维修换新',
    scenario_id: 'sc-repair', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 4, communication_value: 5,
    skill_key: 'suggest_next'
  },
  {
    id: 'ki-033', type: 'chunk', english: 'past the deadline', chinese: '超过截止时间',
    chunk: 'past the deadline',
    example_sentence: 'This ticket is already past the deadline and needs escalation.',
    natural_alternatives: ['overdue', 'beyond the due date'],
    common_mistakes: ['pass the deadline (×)'],
    usage_note: '描述超时状态。', work_context: '超时处理',
    scenario_id: 'sc-timeout', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'describe_status'
  },
  {
    id: 'ki-034', type: 'word', english: 'overdue', chinese: '逾期/超时',
    phonetic: '/ˌoʊvərˈduː/',
    example_sentence: 'We have three overdue tickets that need immediate attention.',
    natural_alternatives: ['past due', 'late'],
    common_mistakes: ['overdue with (×)'],
    usage_note: '超时工单的标准用词。', work_context: '超时处理',
    scenario_id: 'sc-timeout', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'describe_status'
  },
  {
    id: 'ki-035', type: 'work_expression', english: 'As a fallback, we will ___.',
    chinese: '作为兜底方案，我们将___。',
    sentence_pattern: 'As a fallback, we will ___.',
    example_sentence: 'As a fallback, we will provide a temporary replacement while waiting for the new part.',
    natural_alternatives: ['If that doesn\'t work, we will ___.', 'Our backup plan is to ___.'],
    common_mistakes: ['As fallback (×, 缺a)'],
    usage_note: '提出兜底方案的标准句型。', work_context: '兜底方案',
    scenario_id: 'sc-fallback', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next'
  },
  {
    id: 'ki-036', type: 'work_expression', english: 'In the meantime, ___.',
    chinese: '在此期间，___。',
    example_sentence: 'In the meantime, we have arranged a temporary solution for the residents.',
    natural_alternatives: ['Meanwhile, ___.', 'For now, ___.'],
    common_mistakes: ['In the same time (×)'],
    usage_note: '在等待期间采取临时措施。', work_context: '兜底方案',
    scenario_id: 'sc-fallback', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next'
  },

  // === Day 21-24: SOP、流程、问题升级 ===
  {
    id: 'ki-037', type: 'work_expression', english: 'According to the SOP, ___.',
    chinese: '根据SOP，___。',
    sentence_pattern: 'According to the SOP, ___.',
    example_sentence: 'According to the SOP, we need to notify the owner within 24 hours of receiving the ticket.',
    natural_alternatives: ['Based on the standard procedure, ___.', 'Per our process, ___.'],
    common_mistakes: ['According the SOP (×, 缺to)'],
    usage_note: '引用流程标准时的句型。', work_context: 'SOP',
    scenario_id: 'sc-sop', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'explain_sop'
  },
  {
    id: 'ki-038', type: 'chunk', english: 'follow the procedure', chinese: '遵循流程',
    chunk: 'follow the procedure',
    example_sentence: 'Please make sure to follow the procedure for all emergency cases.',
    natural_alternatives: ['stick to the process', 'go by the book'],
    common_mistakes: ['follow the processing (×)'],
    usage_note: '强调按流程执行。', work_context: 'SOP',
    scenario_id: 'sc-sop', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 4,
    skill_key: 'explain_sop'
  },
  {
    id: 'ki-039', type: 'work_expression', english: 'This needs to be escalated to ___.',
    chinese: '这需要升级给___。',
    sentence_pattern: 'This needs to be escalated to ___.',
    example_sentence: 'This issue needs to be escalated to the city operations manager.',
    natural_alternatives: ['We need to bring this to ___.', 'This should go to ___ for attention.'],
    common_mistakes: ['escalate to the manager (√, 但需要说明具体到谁)'],
    usage_note: '问题升级的标准句型。', work_context: '问题升级',
    scenario_id: 'sc-sop', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'escalate'
  },
  {
    id: 'ki-040', type: 'work_expression', english: 'I would like to flag this as a high-priority issue.',
    chinese: '我想将此标记为高优先级问题。',
    example_sentence: 'I would like to flag this as a high-priority issue because it affects multiple units.',
    natural_alternatives: ['I want to mark this as urgent.', 'This should be flagged as critical.'],
    common_mistakes: ['flag this as high priority issue (×, 缺a)'],
    usage_note: '标记紧急问题的表达。', work_context: '问题升级',
    scenario_id: 'sc-sop', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 4, communication_value: 5,
    skill_key: 'escalate'
  },
  {
    id: 'ki-041', type: 'chunk', english: 'take ownership of', chinese: '对...负责',
    chunk: 'take ownership of + 名词',
    example_sentence: 'I will take ownership of this case until it is fully resolved.',
    natural_alternatives: ['be responsible for', 'be accountable for'],
    common_mistakes: ['take own of (×)'],
    usage_note: '主动承担责任的正式表达。', work_context: '责任确认',
    scenario_id: 'sc-confirm', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 4, communication_value: 5,
    skill_key: 'confirm_owner'
  },
  {
    id: 'ki-042', type: 'work_expression', english: 'Let me give you a quick update on ___.',
    chinese: '让我快速给你更新一下___。',
    example_sentence: 'Let me give you a quick update on the ticket we discussed yesterday.',
    natural_alternatives: ['Here\'s a quick update on ___.', 'Briefly on ___.'],
    common_mistakes: ['Let me give you quick update (×, 缺a)'],
    usage_note: '会议中汇报更新的开头。', work_context: '会议汇报',
    scenario_id: 'sc-reporting', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'give_updates'
  },

  // === Day 25-28: 综合汇报、数据、追问 ===
  {
    id: 'ki-043', type: 'work_expression', english: 'To summarize, ___.',
    chinese: '总结一下，___。',
    example_sentence: 'To summarize, we have resolved 12 out of 15 tickets this week.',
    natural_alternatives: ['In short, ___.', 'Overall, ___.'],
    common_mistakes: ['Summary, (×, 应为To summarize)'],
    usage_note: '汇报收尾的标准句型。', work_context: '汇报总结',
    scenario_id: 'sc-reporting', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'give_updates'
  },
  {
    id: 'ki-044', type: 'work_expression', english: 'The main challenge we are facing is ___.',
    chinese: '我们面临的主要挑战是___。',
    sentence_pattern: 'The main challenge we are facing is ___.',
    example_sentence: 'The main challenge we are facing is the lack of spare parts.',
    natural_alternatives: ['The biggest issue is ___.', 'Our main difficulty is ___.'],
    common_mistakes: ['The main challenge is we facing (×)'],
    usage_note: '描述困难和挑战。', work_context: '汇报',
    scenario_id: 'sc-reason', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'explain_problems'
  },
  {
    id: 'ki-045', type: 'work_expression', english: 'Is there anything else you would like to know?',
    chinese: '您还有什么想了解的吗？',
    example_sentence: 'Is there anything else you would like to know about the progress?',
    natural_alternatives: ['Any questions on this?', 'Would you like more details?'],
    common_mistakes: ['Do you have anything else to know (×)'],
    usage_note: '汇报后邀请追问。', work_context: '会议汇报',
    scenario_id: 'sc-followup', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'answer_followups'
  },
  {
    id: 'ki-046', type: 'sentence_pattern', english: 'If ___ , then we will ___.',
    chinese: '如果___，那么我们将___。',
    example_sentence: 'If the part arrives tomorrow, then we will complete the repair by Thursday.',
    natural_alternatives: ['In case ___, we will ___.'],
    common_mistakes: ['If tomorrow part arrive, we will (×)'],
    usage_note: '条件句用于给出方案和预判。', work_context: '方案汇报',
    scenario_id: 'sc-nextstep', difficulty: 3, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next'
  },
  {
    id: 'ki-047', type: 'chunk', english: 'in terms of', chinese: '在...方面',
    chunk: 'in terms of + 名词',
    example_sentence: 'In terms of efficiency, we have improved significantly this quarter.',
    natural_alternatives: ['regarding', 'when it comes to'],
    common_mistakes: ['in term of (×, 缺s)'],
    usage_note: '切换汇报维度时使用。', work_context: '数据汇报',
    scenario_id: 'sc-data', difficulty: 3, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'report_data'
  },
  {
    id: 'ki-048', type: 'work_expression', english: 'I will get back to you by ___.',
    chinese: '我会在___之前回复你。',
    example_sentence: 'I will get back to you by this afternoon with the exact numbers.',
    natural_alternatives: ['I\'ll have an answer for you by ___.', 'I\'ll confirm by ___.'],
    common_mistakes: ['I will back to you (×, 缺get)'],
    usage_note: '无法立即回答时承诺回复时间。', work_context: '会议沟通',
    scenario_id: 'sc-followup', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'answer_followups'
  },
  {
    id: 'ki-049', type: 'work_expression', english: 'Based on the data, ___.',
    chinese: '根据数据，___。',
    sentence_pattern: 'Based on the data, ___.',
    example_sentence: 'Based on the data, the three-day resolution rate has dropped by 8%.',
    natural_alternatives: ['According to the numbers, ___.', 'The data shows that ___.'],
    common_mistakes: ['Base on the data (×, 缺d)'],
    usage_note: '数据驱动汇报的标准开头。', work_context: '数据汇报',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'report_data'
  },
  {
    id: 'ki-050', type: 'work_expression', english: 'Let me walk you through the numbers.',
    chinese: '让我带你看一下数据。',
    example_sentence: 'Let me walk you through the numbers for this week\'s ticket resolution.',
    natural_alternatives: ['Let me go over the data.', 'Here are the key numbers.'],
    common_mistakes: ['Let me walk you the numbers (×, 缺through)'],
    usage_note: '开始数据汇报的自然表达。', work_context: '数据汇报',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data'
  }
];

// ===== 28天每日课程 =====
const DAILY_LESSONS = [
  // Day 1
  {
    day: 1, week: 1, theme: '汇报当前状态', theme_en: 'Reporting Current Status',
    itemIds: ['ki-001', 'ki-002', 'ki-003', 'ki-005', 'ki-006'],
    patternIds: ['ki-002'],
    listening: { title: 'Listening: Status & Timeline', text: 'Hi team, let me give you a quick update. The current status of the maintenance ticket is in progress. We assigned it to the repair team yesterday morning. As of today, the work is about sixty percent done. We expect to complete it by the end of the day.', },
    workPractice: { context: '你需要向直属领导汇报一个工单的当前状态。工单编号TK-2024，状态是"维修中"，已指派给维修团队，预计明天完成。', task: '用英语完成30秒状态汇报。', hints: ['The current status of...', 'in progress', 'by the end of...'], reference: 'The current status of ticket TK-2024 is in progress. We assigned it to the repair team, and we expect to complete it by the end of tomorrow.' },
    challenge: { prompt: '用45秒向领导说明本周最重要的一个工单的状态。', }
  },
  // Day 2
  {
    day: 2, week: 1, theme: '确认负责人和时间', theme_en: 'Confirming Owner & Deadline',
    itemIds: ['ki-008', 'ki-009', 'ki-010', 'ki-007', 'ki-003'],
    patternIds: ['ki-009'],
    listening: { title: 'Listening: Who and When', text: 'I have assigned this case to Zhang Wei. He is responsible for following up with the owner. We need to get this done by the end of the week. The person responsible for the repair is the maintenance team lead. It was completed on Monday morning.', },
    workPractice: { context: '一个维修工单需要确认负责人和截止时间。负责人是王磊，截止时间是周五前。', task: '用英语向同事确认这个工单的负责人和截止时间。', hints: ['assign to', 'responsible for', 'by the end of'], reference: 'I have assigned this ticket to Wang Lei. The person responsible for the follow-up is Wang Lei. We need to complete it by the end of the week.' },
    challenge: { prompt: '用45秒说明你本周负责的一个任务，包括负责人和截止时间。', }
  },
  // Day 3
  {
    day: 3, week: 1, theme: '描述工单进度', theme_en: 'Describing Ticket Progress',
    itemIds: ['ki-005', 'ki-006', 'ki-018', 'ki-001', 'ki-004'],
    patternIds: ['ki-002'],
    listening: { title: 'Listening: Ticket Progress', text: 'The ticket is currently pending approval. We are waiting for the manager to sign off. As of this morning, nothing has changed. The current status of the case is still pending. Once approved, the repair work will begin immediately.', },
    workPractice: { context: '一个工单正在等待业主确认。你需要告诉同事当前状态和等待的内容。', task: '用英语描述这个工单的状态和你在等什么。', hints: ['pending', 'waiting for', 'current status'], reference: 'The current status of the ticket is pending. We are waiting for the owner\'s confirmation. Once we get the approval, we will start the repair immediately.' },
    challenge: { prompt: '用45秒描述一个你正在跟进的工单，包括状态、等待的内容和预计完成时间。', }
  },
  // Day 4
  {
    day: 4, week: 1, theme: '时间表达与数据基础', theme_en: 'Time & Data Basics',
    itemIds: ['ki-004', 'ki-015', 'ki-016', 'ki-017', 'ki-007'],
    patternIds: ['ki-016'],
    listening: { title: 'Listening: Numbers & Time', text: 'As of today, we have resolved fifteen tickets. Compared to last week, our completion rate has improved. The completion rate for this week is eighty-five percent. It was completed on Monday. The ticket volume decreased by twelve percent compared to last month.', },
    workPractice: { context: '本周处理了20个工单，完成率90%，比上周提升了5%。', task: '用英语汇报这周的数据。', hints: ['as of', 'compared to', 'completion rate'], reference: 'As of today, we have resolved twenty tickets. The completion rate for this week is ninety percent. Compared to last week, it has improved by five percent.' },
    challenge: { prompt: '用45秒汇报本周的一项关键数据，包括对比。', }
  },
  // Day 5
  {
    day: 5, week: 1, theme: '说明延迟', theme_en: 'Explaining Delays',
    itemIds: ['ki-011', 'ki-012', 'ki-014', 'ki-005', 'ki-018'],
    patternIds: ['ki-012'],
    listening: { title: 'Listening: Why the Delay', text: 'There has been a delay in resolving this case. The main reason for the delay is that we have not received a clear solution from the supplier yet. We are still waiting for their response. The ticket is pending because of the supply issue. Due to the shortage, we cannot proceed with the repair right now.', },
    workPractice: { context: '一个工单延迟了。原因是供应商还没有提供解决方案。你需要向领导解释延迟原因。', task: '用英语解释为什么这个工单延迟了。', hints: ['a delay in', 'the main reason for the delay is that', 'due to'], reference: 'There has been a delay in resolving this case. The main reason for the delay is that we have not received a clear solution from the supplier yet. Due to the supply issue, we are still waiting for their response.' },
    challenge: { prompt: '用45秒解释一个你遇到过的延迟，说明原因。', }
  },
  // Day 6
  {
    day: 6, week: 1, theme: '解释问题原因', theme_en: 'Explaining Reasons',
    itemIds: ['ki-013', 'ki-014', 'ki-011', 'ki-003', 'ki-006'],
    patternIds: ['ki-013'],
    listening: { title: 'Listening: Root Cause', text: 'The reason why the ticket is still open is that we are waiting for the spare part. The delay was due to a supply shortage. We are currently working on finding an alternative supplier. The main reason for the delay is that the original part is no longer available.', },
    workPractice: { context: '一个工单还开着，原因是缺少零件。供应商说零件要三天后到。', task: '用英语向领导解释为什么工单还开着，以及你的应对。', hints: ['the reason why', 'due to', 'currently working on'], reference: 'The reason why the ticket is still open is that we are waiting for the spare part. The delay is due to a supply shortage. We are currently working on finding an alternative supplier, and the part should arrive in three days.' },
    challenge: { prompt: '用45秒解释一个问题的原因和你的应对方案。', }
  },
  // Day 7
  {
    day: 7, week: 1, theme: '本周复习与周测', theme_en: 'Week 1 Review & Test',
    itemIds: ['ki-001', 'ki-005', 'ki-009', 'ki-011', 'ki-013', 'ki-015'],
    patternIds: ['ki-002', 'ki-013'],
    listening: { title: 'Listening: Week 1 Review', text: 'Let me give you a quick update. The current status of the ticket is pending. We assigned it to the repair team. The person responsible for this case is Zhang Wei. There has been a delay in resolving it. The main reason for the delay is that we are waiting for the spare part. As of today, the completion rate is eighty percent.', },
    workPractice: { context: '本周回顾：你需要向领导汇报本周工单的整体情况，包括完成数量、延迟情况和原因。', task: '用英语完成一分钟的本周工作总结。', hints: ['current status', 'assigned to', 'delay', 'main reason', 'as of today'], reference: 'Let me give you a quick update on this week. The current status is that we have resolved most tickets. We assigned the remaining ones to the repair team. There has been a delay in two cases. The main reason for the delay is the supply shortage. As of today, the completion rate is eighty percent.' },
    challenge: { prompt: '用60秒做本周工作总结：状态、数据、延迟原因。', }
  },
  // Day 8
  {
    day: 8, week: 2, theme: '汇报数据变化', theme_en: 'Reporting Data Changes',
    itemIds: ['ki-015', 'ki-016', 'ki-017', 'ki-004', 'ki-049'],
    patternIds: ['ki-016'],
    listening: { title: 'Listening: Data Review', text: 'Based on the data, the three-day resolution rate has dropped by eight percent. Compared to last week, we received more tickets but resolved fewer. The completion rate for this week is seventy-two percent. As of yesterday, we still have fifteen pending tickets.', },
    workPractice: { context: '深圳区域的三日解决率从85%下降到77%。你需要汇报这个数据变化。', task: '用英语说明数据变化情况。', hints: ['based on the data', 'decreased by', 'compared to'], reference: 'Based on the data, the three-day resolution rate has decreased by eight percent, from eighty-five to seventy-seven. Compared to last week, the drop is mainly due to the increased ticket volume.' },
    challenge: { prompt: '用45秒汇报一个你关注的数据指标的变化。', }
  },
  // Day 9
  {
    day: 9, week: 2, theme: '回答追问', theme_en: 'Answering Follow-up Questions',
    itemIds: ['ki-019', 'ki-020', 'ki-021', 'ki-048', 'ki-045'],
    patternIds: ['ki-020'],
    listening: { title: 'Listening: Follow-up Q&A', text: 'Can you explain why the rate dropped? That\'s a good question. Let me clarify. What I mean is we had more complex cases this week. To be more specific, three of the tickets required ordering special parts. I will get back to you by this afternoon with the exact breakdown.', },
    workPractice: { context: '你汇报了数据下降后，领导追问："为什么下降这么多？具体是哪些工单导致的？"', task: '用英语回答这个追问。', hints: ['that\'s a good question', 'what I mean is', 'to be more specific'], reference: 'That\'s a good question. Let me clarify. What I mean is we had more complex cases this week. To be more specific, three tickets required special parts that took longer to source. I will get back to you by this afternoon with the exact breakdown.' },
    challenge: { prompt: '用45秒回答一个关于你工作的追问。', }
  },
  // Day 10
  {
    day: 10, week: 2, theme: '提出下一步方案', theme_en: 'Proposing Next Steps',
    itemIds: ['ki-022', 'ki-023', 'ki-024', 'ki-046', 'ki-003'],
    patternIds: ['ki-022'],
    listening: { title: 'Listening: Next Steps', text: 'Our next step is to contact the supplier directly and request a faster delivery. Moving forward, we will assign a dedicated person to each high-priority case. We plan to complete the remaining repairs by Friday. If the parts arrive tomorrow, then we will finish by Thursday.', },
    workPractice: { context: '工单延迟了，原因是缺零件。你需要向领导提出下一步方案。', task: '用英语说明你的下一步计划和预计完成时间。', hints: ['our next step is to', 'moving forward', 'we plan to'], reference: 'Our next step is to contact the supplier directly and request a faster delivery. Moving forward, we will assign a dedicated person to each high-priority case. We plan to complete the remaining repairs by Friday.' },
    challenge: { prompt: '用45秒提出一个问题的下一步解决方案。', }
  },
  // Day 11
  {
    day: 11, week: 2, theme: '请求同事协助', theme_en: 'Requesting Help',
    itemIds: ['ki-025', 'ki-026', 'ki-029', 'ki-030', 'ki-042'],
    patternIds: ['ki-025'],
    listening: { title: 'Listening: Asking for Help', text: 'Could you help me with the owner communication? They are not responding to our calls. I need your support on getting the budget approved. I will personally follow up on this. Let me give you a quick update on the ticket we discussed yesterday. I will keep you updated on the progress.', },
    workPractice: { context: '一个业主不接电话不回消息。你需要请同事帮忙联系。', task: '用英语向同事请求协助。', hints: ['could you help me with', 'I need your support on', 'keep you updated'], reference: 'Could you help me with the owner communication? They are not responding to our calls. I need your support on reaching out to them. I will keep you updated on the progress, and I will personally follow up on this.' },
    challenge: { prompt: '用45秒向同事请求一项工作协助。', }
  },
  // Day 12
  {
    day: 12, week: 2, theme: '业主沟通', theme_en: 'Owner Communication',
    itemIds: ['ki-027', 'ki-028', 'ki-029', 'ki-030', 'ki-048'],
    patternIds: ['ki-027'],
    listening: { title: 'Listening: Talking to Owners', text: 'I understand your concern about the delay. Let me explain the situation. We apologize for the inconvenience. The reason for the delay is a supply issue. I will personally follow up on this. I will keep you updated on the progress and get back to you by tomorrow.', },
    workPractice: { context: '业主投诉维修延迟了三天。你需要向业主解释情况并安抚。', task: '用英语向业主解释延迟原因并承诺跟进。', hints: ['I understand your concern', 'we apologize for', 'I will personally follow up'], reference: 'I understand your concern about the delay. Let me explain the situation. We apologize for the inconvenience. The reason for the delay is a supply issue. I will personally follow up on this and keep you updated on the progress.' },
    challenge: { prompt: '用60秒向一位不满的业主解释问题并安抚。', }
  },
  // Day 13
  {
    day: 13, week: 2, theme: '数据汇报综合', theme_en: 'Data Reporting Practice',
    itemIds: ['ki-049', 'ki-050', 'ki-047', 'ki-015', 'ki-016'],
    patternIds: ['ki-049'],
    listening: { title: 'Listening: Data Walkthrough', text: 'Let me walk you through the numbers. Based on the data, our three-day resolution rate is currently seventy-seven percent. Compared to last week, it dropped by eight percent. In terms of ticket volume, we received fifty-two tickets this week, which is a ten percent increase.', },
    workPractice: { context: '你需要汇报本周数据：总工单52个，解决40个，完成率77%，比上周下降8%。', task: '用英语完整汇报这组数据。', hints: ['let me walk you through', 'based on the data', 'compared to', 'in terms of'], reference: 'Let me walk you through the numbers. Based on the data, we received fifty-two tickets this week and resolved forty. The completion rate is seventy-seven percent. Compared to last week, it decreased by eight percent. In terms of volume, we had a ten percent increase.' },
    challenge: { prompt: '用60秒完整汇报一组工作数据，包括对比。', }
  },
  // Day 14
  {
    day: 14, week: 2, theme: '本周复习与周测', theme_en: 'Week 2 Review & Test',
    itemIds: ['ki-019', 'ki-022', 'ki-025', 'ki-027', 'ki-049', 'ki-050'],
    patternIds: ['ki-022', 'ki-049'],
    listening: { title: 'Listening: Week 2 Review', text: 'Based on the data, the resolution rate dropped. That\'s a good question. Let me clarify. Our next step is to contact the supplier. Could you help me with the owner communication? I understand your concern about the delay. Let me walk you through the numbers.', },
    workPractice: { context: '本周综合练习：领导问你为什么完成率下降，你需要解释原因并提出下一步。', task: '用英语完成2分钟的综合汇报：数据→原因→下一步。', hints: ['based on the data', 'let me clarify', 'our next step is to', 'moving forward'], reference: 'Based on the data, the completion rate dropped by eight percent this week. Let me clarify the reason. We had more complex cases that required special parts. Our next step is to contact the supplier directly. Moving forward, we will assign a dedicated person to each high-priority case.' },
    challenge: { prompt: '用60秒完成综合汇报：数据变化→原因→下一步。', }
  },
  // Day 15-21 (Week 3)
  {
    day: 15, week: 3, theme: '维修与换新', theme_en: 'Repair & Replacement',
    itemIds: ['ki-031', 'ki-032', 'ki-006', 'ki-011', 'ki-014'],
    patternIds: ['ki-032'],
    listening: { title: 'Listening: Repair Assessment', text: 'The valve is damaged and needs to be replaced. The repair work is currently in progress. There has been a delay in getting the replacement part. Due to the supply issue, we recommend replacing the pipe rather than repairing it, as it has cracked in multiple places.', },
    workPractice: { context: '一根水管裂了多处。你需要向领导建议换新而不是维修。', task: '用英语说明情况并给出建议。', hints: ['needs to be replaced', 'we recommend replacing', 'due to'], reference: 'The pipe is damaged and needs to be replaced. Due to the multiple cracks, we recommend replacing it rather than repairing it. There has been a delay in getting the replacement, but we are currently working on it.' },
    challenge: { prompt: '用45秒建议一个"换新优于维修"的方案。', }
  },
  {
    day: 16, week: 3, theme: '超时处理', theme_en: 'Timeout Handling',
    itemIds: ['ki-033', 'ki-034', 'ki-012', 'ki-022', 'ki-039'],
    patternIds: ['ki-034'],
    listening: { title: 'Listening: Overdue Tickets', text: 'We have three overdue tickets that need immediate attention. This ticket is already past the deadline. The main reason for the delay is that we are still waiting for the owner\'s confirmation. This needs to be escalated to the city operations manager.', },
    workPractice: { context: '一个工单已经超时48小时了。原因是业主不确认方案。你需要汇报并建议升级。', task: '用英语说明超时情况和建议。', hints: ['overdue', 'past the deadline', 'needs to be escalated'], reference: 'This ticket is already past the deadline. It has been overdue for forty-eight hours. The main reason for the delay is that we are waiting for the owner\'s confirmation. I think this needs to be escalated to the city operations manager.' },
    challenge: { prompt: '用45秒汇报一个超时情况并建议处理方式。', }
  },
  {
    day: 17, week: 3, theme: '兜底方案', theme_en: 'Fallback Plans',
    itemIds: ['ki-035', 'ki-036', 'ki-024', 'ki-003', 'ki-030'],
    patternIds: ['ki-035'],
    listening: { title: 'Listening: Fallback Options', text: 'As a fallback, we will provide a temporary replacement while waiting for the new part. In the meantime, we have arranged a temporary solution for the residents. We plan to complete the full repair by next Monday. We are currently working on it and will keep you updated.', },
    workPractice: { context: '零件要等一周才到。你需要给业主一个兜底方案。', task: '用英语提出临时方案和最终解决时间。', hints: ['as a fallback', 'in the meantime', 'we plan to'], reference: 'As a fallback, we will provide a temporary replacement while waiting for the new part. In the meantime, we have arranged a temporary solution for the residents. We plan to complete the full repair by next Monday and will keep you updated on the progress.' },
    challenge: { prompt: '用45秒提出一个兜底方案。', }
  },
  {
    day: 18, week: 3, theme: 'SOP与流程', theme_en: 'SOP & Process',
    itemIds: ['ki-037', 'ki-038', 'ki-022', 'ki-010', 'ki-004'],
    patternIds: ['ki-037'],
    listening: { title: 'Listening: SOP Explanation', text: 'According to the SOP, we need to notify the owner within twenty-four hours of receiving the ticket. Please make sure to follow the procedure for all emergency cases. Our next step is to document the entire process. We need to complete this by the end of the day. As of now, everything is on track.', },
    workPractice: { context: '新同事不知道超时工单的处理流程。你需要向他解释SOP。', task: '用英语说明超时工单的SOP关键步骤。', hints: ['according to the SOP', 'follow the procedure', 'by the end of'], reference: 'According to the SOP, we need to notify the owner within twenty-four hours of receiving the ticket. Please make sure to follow the procedure for all emergency cases. If the ticket is overdue, it needs to be escalated. We need to complete the documentation by the end of the day.' },
    challenge: { prompt: '用45秒解释一个你熟悉的工作流程。', }
  },
  {
    day: 19, week: 3, theme: '问题升级', theme_en: 'Problem Escalation',
    itemIds: ['ki-039', 'ki-040', 'ki-041', 'ki-022', 'ki-044'],
    patternIds: ['ki-039'],
    listening: { title: 'Listening: Escalation', text: 'This issue needs to be escalated to the city operations manager. I would like to flag this as a high-priority issue because it affects multiple units. I will take ownership of this case until it is fully resolved. The main challenge we are facing is the lack of spare parts. Our next step is to arrange a meeting with all stakeholders.', },
    workPractice: { context: '一个水管问题影响了多户业主，已经超时。你需要向领导建议升级处理。', task: '用英语说明情况并建议升级。', hints: ['needs to be escalated', 'flag this as', 'take ownership of'], reference: 'This issue needs to be escalated to the city operations manager. I would like to flag this as a high-priority issue because it affects multiple units. I will take ownership of this case until it is fully resolved. The main challenge we are facing is the lack of spare parts.' },
    challenge: { prompt: '用45秒建议将一个问题升级处理。', }
  },
  {
    day: 20, week: 3, theme: '承担责任与汇报', theme_en: 'Ownership & Reporting',
    itemIds: ['ki-041', 'ki-042', 'ki-043', 'ki-003', 'ki-030'],
    patternIds: ['ki-043'],
    listening: { title: 'Listening: Taking Ownership', text: 'I will take ownership of this case until it is fully resolved. Let me give you a quick update on the ticket we discussed yesterday. To summarize, we have resolved twelve out of fifteen tickets this week. We are currently working on the remaining three. I will keep you updated on the progress.', },
    workPractice: { context: '你需要向领导做本周总结：15个工单解决了12个，还有3个在处理中。', task: '用英语完成本周总结汇报。', hints: ['take ownership of', 'let me give you a quick update', 'to summarize'], reference: 'Let me give you a quick update. To summarize, we have resolved twelve out of fifteen tickets this week. We are currently working on the remaining three. I will take ownership of these cases and keep you updated on the progress.' },
    challenge: { prompt: '用60秒完成一次工作总结，包括数据、状态和承诺。', }
  },
  {
    day: 21, week: 3, theme: '本周复习与周测', theme_en: 'Week 3 Review & Test',
    itemIds: ['ki-031', 'ki-034', 'ki-035', 'ki-037', 'ki-039', 'ki-041'],
    patternIds: ['ki-035', 'ki-039'],
    listening: { title: 'Listening: Week 3 Review', text: 'The pipe needs to be replaced. We have three overdue tickets. As a fallback, we will provide a temporary replacement. According to the SOP, we need to notify the owner within twenty-four hours. This issue needs to be escalated. I will take ownership of this case.', },
    workPractice: { context: '综合场景：一个超时工单需要换新零件，业主不满，需要升级处理。', task: '用英语完成2分钟综合汇报：问题→原因→兜底方案→升级建议。', hints: ['overdue', 'needs to be replaced', 'as a fallback', 'escalated'], reference: 'This ticket is overdue and the part needs to be replaced. The main reason for the delay is the supply shortage. As a fallback, we will provide a temporary replacement. This issue needs to be escalated to the city manager because it affects multiple units. I will take ownership of this case.' },
    challenge: { prompt: '用60秒完成一个超时工单的综合汇报。', }
  },
  // Day 22-28 (Week 4)
  {
    day: 22, week: 4, theme: '数据驱动汇报', theme_en: 'Data-Driven Reporting',
    itemIds: ['ki-049', 'ki-050', 'ki-047', 'ki-016', 'ki-043'],
    patternIds: ['ki-049'],
    listening: { title: 'Listening: Data Deep Dive', text: 'Let me walk you through the numbers. Based on the data, the three-day resolution rate has dropped by eight percent. In terms of ticket volume, we received fifty-two tickets this week. Compared to last week, that is a ten percent increase. To summarize, we are handling more tickets but resolving them slower.', },
    workPractice: { context: '你负责的区域本周数据：工单量增加10%，三日解决率从85%降到77%，主要原因是复杂工单增多。', task: '用英语完整汇报数据、原因和结论。', hints: ['let me walk you through', 'based on the data', 'in terms of', 'to summarize'], reference: 'Let me walk you through the numbers. Based on the data, the three-day resolution rate has dropped by eight percent, from eighty-five to seventy-seven. In terms of ticket volume, we received fifty-two tickets, a ten percent increase compared to last week. To summarize, we are handling more tickets but resolving them slower due to the complexity.' },
    challenge: { prompt: '用60秒做一次数据驱动的汇报，包括原因分析。', }
  },
  {
    day: 23, week: 4, theme: '回答追问进阶', theme_en: 'Advanced Follow-up Handling',
    itemIds: ['ki-019', 'ki-020', 'ki-021', 'ki-048', 'ki-044'],
    patternIds: ['ki-020'],
    listening: { title: 'Listening: Tough Questions', text: 'Why has the rate been dropping for two weeks? That\'s a good question. Let me clarify. What I mean is we have had more complex cases. To be more specific, three required special parts. The main challenge we are facing is the supply chain. I will get back to you by this afternoon with the detailed breakdown.', },
    workPractice: { context: '领导连续追问："为什么连续两周下降？你有没有具体分析过原因？"', task: '用英语回答连续追问，先缓冲再具体解释。', hints: ['that\'s a good question', 'what I mean is', 'to be more specific', 'main challenge'], reference: 'That\'s a good question. Let me clarify. What I mean is we have had more complex cases in the past two weeks. To be more specific, three tickets required special parts that took longer to source. The main challenge we are facing is the supply chain delay. I will get back to you by this afternoon with the detailed breakdown.' },
    challenge: { prompt: '用60秒回答一个连续追问，包括缓冲、解释和具体细节。', }
  },
  {
    day: 24, week: 4, theme: '提出方案与条件预判', theme_en: 'Plans & Conditionals',
    itemIds: ['ki-022', 'ki-023', 'ki-046', 'ki-024', 'ki-035'],
    patternIds: ['ki-046'],
    listening: { title: 'Listening: Action Plans', text: 'Our next step is to contact the supplier directly. Moving forward, we will assign a dedicated person to each case. If the parts arrive tomorrow, then we will complete the repair by Thursday. We plan to finish all pending tickets by Friday. As a fallback, we will arrange a temporary solution.', },
    workPractice: { context: '领导问你下一步怎么办。你需要给出方案A和方案B（兜底）。', task: '用英语提出主方案和兜底方案。', hints: ['our next step is to', 'if...then', 'as a fallback'], reference: 'Our next step is to contact the supplier directly and request a faster delivery. If the parts arrive tomorrow, then we will complete the repair by Thursday. As a fallback, we will arrange a temporary solution for the residents in the meantime.' },
    challenge: { prompt: '用45秒提出一个包含条件预判的方案。', }
  },
  {
    day: 25, week: 4, theme: '综合场景：工单全流程', theme_en: 'Full Ticket Lifecycle',
    itemIds: ['ki-001', 'ki-011', 'ki-013', 'ki-022', 'ki-030', 'ki-043'],
    patternIds: ['ki-022'],
    listening: { title: 'Listening: Full Cycle', text: 'Let me give you a quick update. The current status of the ticket is in progress. There has been a delay in resolving it. The reason is a supply issue. Our next step is to contact the alternative supplier. To summarize, we expect to resolve this by Friday and will keep you updated.', },
    workPractice: { context: '一个工单从开单到现在的完整情况：收到→分派→延迟→原因→下一步→预计完成。', task: '用英语用2分钟完整汇报一个工单的全流程。', hints: ['current status', 'delay', 'reason', 'next step', 'keep you updated', 'to summarize'], reference: 'Let me give you a quick update. The current status of the ticket is in progress. We assigned it to the repair team, but there has been a delay. The reason is a supply issue. Our next step is to contact the alternative supplier. We plan to complete it by Friday. To summarize, we expect to resolve this by the end of the week and will keep you updated.' },
    challenge: { prompt: '用90秒完整汇报一个工单从开始到现在的全流程。', }
  },
  {
    day: 26, week: 4, theme: '综合场景：业主沟通全流程', theme_en: 'Owner Communication Full Cycle',
    itemIds: ['ki-027', 'ki-028', 'ki-029', 'ki-030', 'ki-035', 'ki-048'],
    patternIds: ['ki-027'],
    listening: { title: 'Listening: Owner Full Cycle', text: 'I understand your concern about the delay. We apologize for the inconvenience. Let me explain the situation. The reason is a supply issue. As a fallback, we will provide a temporary replacement. I will personally follow up on this. I will get back to you by tomorrow with the exact timeline.', },
    workPractice: { context: '业主投诉延迟一周了。你需要完整沟通：共情→道歉→解释→兜底方案→承诺。', task: '用英语完成2分钟的业主沟通全流程。', hints: ['I understand your concern', 'we apologize for', 'as a fallback', 'I will personally follow up'], reference: 'I understand your concern about the delay. We apologize for the inconvenience. Let me explain the situation. The delay is due to a supply issue. As a fallback, we will provide a temporary replacement while waiting for the new part. I will personally follow up on this and get back to you by tomorrow with the exact timeline.' },
    challenge: { prompt: '用90秒完成一次完整的业主沟通。', }
  },
  {
    day: 27, week: 4, theme: '综合场景：数据汇报与追问', theme_en: 'Data Report & Q&A',
    itemIds: ['ki-049', 'ki-050', 'ki-016', 'ki-019', 'ki-022', 'ki-043'],
    patternIds: ['ki-049'],
    listening: { title: 'Listening: Data & Q&A', text: 'Let me walk you through the numbers. Based on the data, the resolution rate dropped by eight percent. Why? That\'s a good question. Let me clarify. We had more complex cases. Our next step is to improve our triage process. To summarize, we expect to recover next week.', },
    workPractice: { context: '你需要汇报数据，然后回答追问，最后提出改进方案。', task: '用英语完成3分钟的"数据→追问→方案"全流程。', hints: ['let me walk you through', 'that\'s a good question', 'our next step is to', 'to summarize'], reference: 'Let me walk you through the numbers. Based on the data, the resolution rate dropped by eight percent. That\'s a good question. Let me clarify. We had more complex cases this week. Our next step is to improve our triage process. To summarize, we expect to recover next week and will keep you updated.' },
    challenge: { prompt: '用90秒完成"数据汇报→回答追问→提出方案"全流程。', }
  },
  {
    day: 28, week: 4, theme: '月度评估', theme_en: 'Monthly Assessment',
    itemIds: ['ki-001', 'ki-011', 'ki-013', 'ki-022', 'ki-027', 'ki-034', 'ki-037', 'ki-049', 'ki-050'],
    patternIds: ['ki-022', 'ki-049', 'ki-037'],
    listening: { title: 'Listening: Monthly Review', text: 'Let me walk you through the numbers. Based on the data, we resolved two hundred tickets this month. The completion rate is eighty-two percent. Three tickets were overdue. According to the SOP, we escalated them. The main reason for delays was the supply chain. Our next step is to build a backup supplier list. To summarize, we are on track but need to improve our response time.', },
    workPractice: { context: '月度总结：200个工单，完成率82%，3个超时，主要问题是供应链。', task: '用英语完成3分钟的月度工作总结。', hints: ['let me walk you through', 'based on the data', 'according to the SOP', 'our next step is to', 'to summarize'], reference: 'Let me walk you through the numbers. Based on the data, we resolved two hundred tickets this month. The completion rate is eighty-two percent. Three tickets were overdue. According to the SOP, we escalated them. The main reason for delays was the supply chain issue. Our next step is to build a backup supplier list. To summarize, we are on track but need to improve our response time.' },
    challenge: { prompt: '用120秒完成一次月度工作总结，涵盖数据、原因、SOP、下一步。', }
  }
];

// ===== 本地AI对话场景 =====
const CONVERSATION_SCENARIOS = [
  {
    id: 'cs-manager-status', role: '直属领导', role_en: 'Direct Manager',
    scenario: '周会上汇报工单状态', goal: '清晰汇报本周工单进度和下一步',
    difficulty: 2, rounds: 4,
    branches: [
      { trigger: 'start', question: 'Can you give me a quick update on the tickets this week?', key_points: ['current status', 'number resolved', 'pending'] },
      { trigger: 'keyword:delay|late|overdue', question: 'Why is that ticket delayed? What\'s the reason?', key_points: ['reason', 'due to', 'main reason'] },
      { trigger: 'keyword:next|plan|step', question: 'What\'s your next step? When can you finish it?', key_points: ['next step', 'plan to', 'by'] },
      { trigger: 'keyword:help|support|need', question: 'What do you need from me? How can I help?', key_points: ['could you help', 'need support'] },
      { trigger: 'default', question: 'Is there anything else I should know about?', key_points: ['anything else', 'summary'] }
    ]
  },
  {
    id: 'cs-colleague-collab', role: '同事', role_en: 'Colleague',
    scenario: '请同事协助处理一个超时工单', goal: '说清情况并请求帮助',
    difficulty: 2, rounds: 3,
    branches: [
      { trigger: 'start', question: 'You wanted to talk to me? What\'s up?', key_points: ['context', 'request help'] },
      { trigger: 'keyword:overdue|late|timeout', question: 'How long has it been overdue? What\'s the status?', key_points: ['overdue', 'past deadline', 'status'] },
      { trigger: 'keyword:part|repair|replace', question: 'So what exactly needs to be done? Do we have the parts?', key_points: ['needs to be replaced', 'supply issue'] },
      { trigger: 'default', question: 'OK, so what do you need me to do specifically?', key_points: ['could you help with', 'specific request'] }
    ]
  },
  {
    id: 'cs-owner-complaint', role: '业主', role_en: 'Property Owner',
    scenario: '业主投诉维修延迟', goal: '安抚业主并给出解决方案',
    difficulty: 3, rounds: 4,
    branches: [
      { trigger: 'start', question: 'I\'ve been waiting for three days! When is someone going to fix this?', key_points: ['understand concern', 'apologize', 'explain'] },
      { trigger: 'keyword:sorry|apolog|understand', question: 'OK but when exactly will it be fixed? I need a date.', key_points: ['specific date', 'plan to', 'by'] },
      { trigger: 'keyword:part|supply|waiting', question: 'So you don\'t even have the parts? What am I supposed to do in the meantime?', key_points: ['fallback', 'temporary', 'in the meantime'] },
      { trigger: 'keyword:follow|update|keep', question: 'You said you\'ll follow up. When will I hear from you again?', key_points: ['get back to you by', 'keep updated', 'personally follow up'] },
      { trigger: 'default', question: 'This is really not acceptable. Can I speak to your manager?', key_points: ['escalate', 'understand', 'take ownership'] }
    ]
  },
  {
    id: 'cs-city-ops', role: '城市运营负责人', role_en: 'City Operations Lead',
    scenario: '向城市负责人汇报区域数据', goal: '清晰汇报数据变化和改进计划',
    difficulty: 3, rounds: 4,
    branches: [
      { trigger: 'start', question: 'How are the numbers looking this week?', key_points: ['based on data', 'completion rate', 'compared to'] },
      { trigger: 'keyword:drop|decrease|down|lower', question: 'Why did it drop? Is this a trend or a one-time thing?', key_points: ['reason', 'main challenge', 'clarify'] },
      { trigger: 'keyword:plan|next|improve', question: 'What\'s your plan to improve it? Give me specifics.', key_points: ['next step', 'moving forward', 'specific'] },
      { trigger: 'keyword:week|timeline|when', question: 'When do you expect to see improvement? What\'s your target?', key_points: ['target', 'plan to', 'by'] },
      { trigger: 'default', question: 'Do you need any resources or support from my side?', key_points: ['need support', 'help with'] }
    ]
  }
];

// ===== 能力维度 =====
const SKILL_DIMENSIONS = [
  { key: 'listening', name: 'Listening Comprehension', name_zh: '听力理解' },
  { key: 'give_updates', name: 'Give Work Updates', name_zh: '汇报工作进展' },
  { key: 'explain_problems', name: 'Explain Problems', name_zh: '描述问题' },
  { key: 'explain_reasons', name: 'Explain Reasons', name_zh: '解释原因' },
  { key: 'answer_followups', name: 'Answer Follow-up Questions', name_zh: '回答追问' },
  { key: 'discuss_solutions', name: 'Discuss Solutions', name_zh: '讨论方案' },
  { key: 'report_data', name: 'Report Data', name_zh: '汇报数据' },
  { key: 'suggest_next', name: 'Suggest Next Steps', name_zh: '提出下一步' },
  { key: 'clarify_info', name: 'Clarify Information', name_zh: '澄清信息' },
  { key: 'continuous_speaking', name: 'Continuous Speaking', name_zh: '连续表达' }
];

// V2: 合并新增能力维度
SKILL_DIMENSIONS.push(...V2_SKILL_DIMENSIONS_EXTRA.filter(s => !SKILL_DIMENSIONS.find(e => e.key === s.key)));

