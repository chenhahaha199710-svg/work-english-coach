// ===== Vocabulary Learning Module =====
// Handles pre-check, learn, quiz (6 types), error analysis, and mastery tracking.
// Depends on: VOCAB_ITEMS, STORES, dbGet/dbGetAll/dbPut/dbCount/dbGetByIndex,
//   WEC_Algo, todayStr(), uuid(), showToast(), navTo(), SpeechUtils

// ---------------------------------------------------------------------------
// 1. Session State
// ---------------------------------------------------------------------------

let vocabSession = null;

// ---------------------------------------------------------------------------
// 2. Word Selection Logic
// ---------------------------------------------------------------------------

/**
 * Select today's vocabulary words.
 * Merges due reviews, unresolved error-bank words, and new words for the day.
 * @returns {Promise<Array>} array of VOCAB_ITEMS to study
 */
async function getDailyVocabWords(day) {
  let dueReviews = [];
  let errorWords = [];
  let newWords = [];

  // --- due reviews from reviewSchedule ---
  try {
    const allSchedule = await dbGetAll(STORES.reviewSchedule);
    const now = Date.now();
    const due = allSchedule
      .filter(s => s.next_review_at <= now)
      .sort((a, b) => a.next_review_at - b.next_review_at);
    // resolve to vocab items (reviewSchedule.item_id == vocab id for vocab items)
    for (const s of due) {
      const v = VOCAB_ITEMS.find(item => item.id === s.item_id);
      if (v) dueReviews.push(v);
    }
  } catch (e) {
    console.warn('[vocab] getDailyVocabWords: reviewSchedule failed', e);
  }

  // --- unresolved error-bank words ---
  try {
    const allErrors = await dbGetAll(STORES.errorBank);
    const unresolved = allErrors.filter(e => !e.resolved);
    const seenIds = new Set();
    for (const err of unresolved) {
      if (err.vocab_id && !seenIds.has(err.vocab_id)) {
        const v = VOCAB_ITEMS.find(item => item.id === err.vocab_id);
        if (v) {
          errorWords.push(v);
          seenIds.add(v.id);
        }
      }
    }
  } catch (e) {
    console.warn('[vocab] getDailyVocabWords: errorBank failed', e);
  }

  // --- new words for current day ---
  newWords = VOCAB_ITEMS.filter(v => v.day === day);

  // --- selection rules ---
  const dueCount = dueReviews.length;
  let newMax;
  if (dueCount > 12) newMax = 6;
  else if (dueCount >= 6) newMax = 10;
  else newMax = 15;

  // Deduplicate: build a map to avoid the same word appearing twice
  const wordMap = new Map();

  // priority 1: due reviews
  for (const v of dueReviews) wordMap.set(v.id, v);

  // priority 2: unresolved error words (if not already included)
  for (const v of errorWords) {
    if (!wordMap.has(v.id)) wordMap.set(v.id, v);
  }

  // priority 3: new words (up to newMax, and respect total cap of 20)
  let newAdded = 0;
  for (const v of newWords) {
    if (newAdded >= newMax) break;
    if (!wordMap.has(v.id)) {
      wordMap.set(v.id, v);
      newAdded++;
    }
  }

  let result = Array.from(wordMap.values());

  // total never exceeds 20; target is 15-18
  const MAX_TOTAL = 20;
  const TARGET_MIN = 15;
  const TARGET_MAX = 18;

  if (result.length > MAX_TOTAL) {
    result = result.slice(0, MAX_TOTAL);
  }

  // If we still have room and are below target, fill with more new words
  if (result.length < TARGET_MIN) {
    for (const v of newWords) {
      if (result.length >= TARGET_MAX) break;
      if (!wordMap.has(v.id)) {
        result.push(v);
        wordMap.set(v.id, v);
      }
    }
  }

  return result;
}

// ---------------------------------------------------------------------------
// 3. Entry Points
// ---------------------------------------------------------------------------

/**
 * Start a new vocab learning session for the given day.
 * Called from Today page or vocab card.
 */
async function startVocabSession(day) {
  try {
    const words = await getDailyVocabWords(day);

    if (!words || words.length === 0) {
      showToast('暂无可学习的单词');
      navTo('today');
      return;
    }

    vocabSession = {
      day: day,
      phase: 'precheck',
      targetWords: words,
      precheckResults: {},
      learnWords: [],
      quizQueue: [],
      quizIdx: 0,
      results: [],
      startTime: Date.now()
    };

    const app = document.getElementById('app');
    renderVocabPrecheck(app);
  } catch (e) {
    console.error('[vocab] startVocabSession error', e);
    showToast('启动单词学习失败，请重试');
    navTo('today');
  }
}

/**
 * Start a retry session for specific vocab IDs (from error bank).
 */
async function startVocabRetry(vocabIds) {
  try {
    if (!vocabIds || vocabIds.length === 0) {
      showToast('没有需要重练的单词');
      return;
    }

    const words = vocabIds
      .map(id => VOCAB_ITEMS.find(v => v.id === id))
      .filter(Boolean);

    if (words.length === 0) {
      showToast('未找到对应单词');
      return;
    }

    vocabSession = {
      day: 0,
      phase: 'quiz',
      targetWords: words,
      precheckResults: {},
      learnWords: [],   // skip learn phase for retry
      quizQueue: [],
      quizIdx: 0,
      results: [],
      startTime: Date.now(),
      isRetry: true
    };

    // build quiz queue directly
    buildQuizQueue(words);

    const app = document.getElementById('app');
    if (vocabSession.quizQueue.length > 0) {
      renderVocabQuiz(app);
    } else {
      showToast('没有可生成的测验题');
      navTo('today');
    }
  } catch (e) {
    console.error('[vocab] startVocabRetry error', e);
    showToast('启动重练失败，请重试');
    navTo('today');
  }
}

// ---------------------------------------------------------------------------
// 4. Session Flow Bar
// ---------------------------------------------------------------------------

function _renderVocabFlowBar(currentPhase) {
  const steps = [
    { key: 'precheck', label: '预习' },
    { key: 'learn', label: '学习' },
    { key: 'quiz', label: '测验' },
    { key: 'summary', label: '总结' }
  ];
  const currentIdx = steps.findIndex(s => s.key === currentPhase);

  let html = '<div class="session-flow-bar">';
  steps.forEach((step, i) => {
    const cls = i < currentIdx ? 'done' : (i === currentIdx ? 'active' : '');
    html += `<div class="session-flow-step ${cls}">`;
    html += `<div class="session-flow-dot"></div>`;
    html += `<span>${step.label}</span>`;
    if (i < steps.length - 1) html += '<span class="session-flow-arrow">→</span>';
    html += '</div>';
  });
  html += '<button class="btn btn-ghost btn-sm" style="margin-left:auto;" onclick="navTo(\'today\')">退出</button>';
  html += '</div>';
  return html;
}

// ---------------------------------------------------------------------------
// 5. Pre-check Phase
// ---------------------------------------------------------------------------

function renderVocabPrecheck(app) {
  if (!vocabSession) { navTo('today'); return; }
  vocabSession.phase = 'precheck';

  const words = vocabSession.targetWords;
  const results = vocabSession.precheckResults;
  const ratedCount = Object.keys(results).length;

  app.innerHTML = `
    <div class="container page">
      ${_renderVocabFlowBar('precheck')}
      <div style="padding: 16px 0 8px;">
        <div class="flex items-center justify-between">
          <h2>单词预习</h2>
          <span class="badge badge-primary">${ratedCount} / ${words.length}</span>
        </div>
        <p class="text-secondary text-sm mt-sm">对每个单词选择你的熟悉程度</p>
      </div>

      <div id="vocab-precheck-list">
        ${words.map(v => _renderPrecheckItem(v, results[v.id])).join('')}
      </div>

      <div style="padding: 16px 0 32px;">
        <button id="vocab-precheck-next" class="btn btn-primary" style="width:100%;"
          ${ratedCount < words.length ? 'disabled' : ''}
          onclick="proceedToLearn()">
          ${ratedCount < words.length ? `还需评估 ${words.length - ratedCount} 个` : '开始学习'}
        </button>
      </div>
    </div>
  `;
}

function _renderPrecheckItem(v, currentRating) {
  const knownSel = currentRating === 'known' ? 'selected' : '';
  const unsureSel = currentRating === 'unsure' ? 'selected' : '';
  const unknownSel = currentRating === 'unknown' ? 'selected' : '';

  return `
    <div class="vocab-precheck-item" id="precheck-${v.id}">
      <div>
        <div class="word-en">${v.word}</div>
        <div class="word-cn">${v.chinese}</div>
      </div>
      <div class="vocab-precheck-btns">
        <button class="vocab-precheck-btn known ${knownSel}"
          onclick="ratePrecheckWord('${v.id}', 'known')">认识</button>
        <button class="vocab-precheck-btn unsure ${unsureSel}"
          onclick="ratePrecheckWord('${v.id}', 'unsure')">不确定</button>
        <button class="vocab-precheck-btn unknown ${unknownSel}"
          onclick="ratePrecheckWord('${v.id}', 'unknown')">不认识</button>
      </div>
    </div>
  `;
}

function ratePrecheckWord(vocabId, rating) {
  if (!vocabSession) return;
  vocabSession.precheckResults[vocabId] = rating;

  // Update only the changed item for smoothness
  const v = vocabSession.targetWords.find(w => w.id === vocabId);
  if (!v) return;

  const container = document.getElementById(`precheck-${vocabId}`);
  if (container) {
    const knownSel = rating === 'known' ? 'selected' : '';
    const unsureSel = rating === 'unsure' ? 'selected' : '';
    const unknownSel = rating === 'unknown' ? 'selected' : '';
    container.querySelector('.vocab-precheck-btns').innerHTML = `
      <button class="vocab-precheck-btn known ${knownSel}"
        onclick="ratePrecheckWord('${v.id}', 'known')">认识</button>
      <button class="vocab-precheck-btn unsure ${unsureSel}"
        onclick="ratePrecheckWord('${v.id}', 'unsure')">不确定</button>
      <button class="vocab-precheck-btn unknown ${unknownSel}"
        onclick="ratePrecheckWord('${v.id}', 'unknown')">不认识</button>
    `;
  }

  // Update progress badge and button
  const ratedCount = Object.keys(vocabSession.precheckResults).length;
  const total = vocabSession.targetWords.length;

  const nextBtn = document.getElementById('vocab-precheck-next');
  if (nextBtn) {
    if (ratedCount >= total) {
      nextBtn.disabled = false;
      nextBtn.textContent = '开始学习';
    } else {
      nextBtn.disabled = true;
      nextBtn.textContent = `还需评估 ${total - ratedCount} 个`;
    }
  }
}

function proceedToLearn() {
  if (!vocabSession) return;

  // Words marked "known" are skipped; "unsure" and "unknown" go to learn phase
  vocabSession.learnWords = vocabSession.targetWords.filter(v => {
    const r = vocabSession.precheckResults[v.id];
    return r === 'unsure' || r === 'unknown' || !r;
  });

  const app = document.getElementById('app');
  if (vocabSession.learnWords.length === 0) {
    // All known — skip straight to quiz
    buildQuizQueue(vocabSession.targetWords);
    if (vocabSession.quizQueue.length > 0) {
      renderVocabQuiz(app);
    } else {
      renderVocabSummary(app);
    }
  } else {
    renderVocabLearn(app);
  }
}

// ---------------------------------------------------------------------------
// 6. Learn Phase
// ---------------------------------------------------------------------------

function renderVocabLearn(app) {
  if (!vocabSession) { navTo('today'); return; }
  vocabSession.phase = 'learn';

  if (!vocabSession._learnIdx) vocabSession._learnIdx = 0;

  const words = vocabSession.learnWords;
  const idx = vocabSession._learnIdx;

  if (idx >= words.length) {
    // All cards reviewed — move to quiz
    buildQuizQueue(vocabSession.targetWords);
    if (vocabSession.quizQueue.length > 0) {
      renderVocabQuiz(app);
    } else {
      renderVocabSummary(app);
    }
    return;
  }

  const v = words[idx];
  const confusableHTML = (v.confusable && v.confusable.length > 0) ? `
    <div class="word-confusable">
      <div class="word-confusable-label">⚠️ 易混淆</div>
      ${v.confusable.map(c => `<div class="word-confusable-item"><strong>${c.word}</strong> — ${c.diff}</div>`).join('')}
    </div>
  ` : '';

  const collocationsHTML = (v.collocations && v.collocations.length > 0) ? `
    <div class="word-collocations">
      <div class="word-collocations-label">搭配</div>
      ${v.collocations.map(c => `<span class="word-colloc-chip">${c}</span>`).join('')}
    </div>
  ` : '';

  app.innerHTML = `
    <div class="container page">
      ${_renderVocabFlowBar('learn')}
      <div style="padding: 16px 0 8px;">
        <div class="flex items-center justify-between">
          <h2>学习单词</h2>
          <span class="badge badge-primary">${idx + 1} / ${words.length}</span>
        </div>
      </div>

      <div class="vocab-card">
        <div>
          <span class="word-title">${v.word}</span>
          <span class="word-pos">${v.pos}</span>
        </div>
        <div class="word-cn">${v.chinese}</div>
        <div class="word-work-meaning">${v.work_meaning || ''}</div>

        <div class="word-example">${v.example_en || ''}</div>
        <div class="word-example-cn">${v.example_cn || ''}</div>

        ${collocationsHTML}
        ${confusableHTML}

        <div class="flex gap-sm mt-md">
          <button class="btn btn-ghost btn-sm flex-1" onclick="playVocabWord('${v.id}')">
            🔊 播放
          </button>
        </div>
      </div>

      <div style="padding: 8px 0 32px;">
        <button class="btn btn-primary" style="width:100%;" onclick="nextVocabLearn()">
          ${idx + 1 < words.length ? '下一个' : '开始测验'}
        </button>
      </div>
    </div>
  `;
}

function playVocabWord(vocabId) {
  const v = VOCAB_ITEMS.find(item => item.id === vocabId);
  if (!v) return;
  try {
    if (typeof SpeechUtils !== 'undefined' && SpeechUtils.speak) {
      SpeechUtils.speak(v.word, { rate: 0.9 });
    }
  } catch (e) {
    console.warn('[vocab] TTS failed', e);
  }
}

function nextVocabLearn() {
  if (!vocabSession) return;
  vocabSession._learnIdx = (vocabSession._learnIdx || 0) + 1;
  const app = document.getElementById('app');
  renderVocabLearn(app);
}

// ---------------------------------------------------------------------------
// 7. Quiz Generation — 6 quiz types
// ---------------------------------------------------------------------------

/**
 * Build the quiz queue: one quiz item per target word, type chosen randomly.
 */
function buildQuizQueue(words) {
  vocabSession.quizQueue = [];
  vocabSession.quizIdx = 0;

  const types = ['en2cn', 'cn2en', 'fillblank', 'firstletter', 'confusable', 'scenario'];

  for (const v of words) {
    // Filter types that are feasible for this word
    let feasible = types.filter(t => _canGenerateQuiz(t, v));
    if (feasible.length === 0) feasible = ['en2cn']; // fallback

    // Pick a random feasible type
    const qType = feasible[Math.floor(Math.random() * feasible.length)];
    const quizItem = _generateQuiz(qType, v);
    if (quizItem) vocabSession.quizQueue.push(quizItem);
  }

  // Shuffle quiz order for variety
  for (let i = vocabSession.quizQueue.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [vocabSession.quizQueue[i], vocabSession.quizQueue[j]] =
      [vocabSession.quizQueue[j], vocabSession.quizQueue[i]];
  }
}

function _canGenerateQuiz(type, v) {
  switch (type) {
    case 'en2cn':
      return !!v.word && !!v.chinese;
    case 'cn2en':
      return !!v.word && !!v.chinese;
    case 'fillblank':
      return !!v.example_en && v.example_en.length > 10;
    case 'firstletter':
      return !!v.word && v.word.length > 1;
    case 'confusable':
      return v.confusable && v.confusable.length >= 1;
    case 'scenario':
      return !!v.work_context;
    default:
      return false;
  }
}

/**
 * Get 3 distractor options from other vocab items (same pos preferred).
 */
function _getDistractors(v, field, count) {
  const pool = VOCAB_ITEMS.filter(item =>
    item.id !== v.id && item[field] && item[field] !== v[field]
  );
  // Prefer same pos
  const samePos = pool.filter(item => item.pos === v.pos);
  const chosen = [];
  const usedValues = new Set([v[field]]);
  const tryPick = (arr) => {
    for (const item of arr) {
      if (chosen.length >= count) break;
      if (!usedValues.has(item[field])) {
        chosen.push(item);
        usedValues.add(item[field]);
      }
    }
  };
  tryPick(samePos);
  if (chosen.length < count) tryPick(pool);
  // If still not enough, just take what we have
  return chosen;
}

function _shuffleArray(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function _generateQuiz(type, v) {
  switch (type) {
    case 'en2cn':
      return _genEn2Cn(v);
    case 'cn2en':
      return _genCn2En(v);
    case 'fillblank':
      return _genFillBlank(v);
    case 'firstletter':
      return _genFirstLetter(v);
    case 'confusable':
      return _genConfusable(v);
    case 'scenario':
      return _genScenario(v);
    default:
      return null;
  }
}

// --- a) English -> Chinese (Recognition) ---
function _genEn2Cn(v) {
  const distractors = _getDistractors(v, 'chinese', 3);
  if (distractors.length < 3) return _genCn2En(v); // fallback

  const options = _shuffleArray([
    { text: v.chinese, correct: true },
    ...distractors.map(d => ({ text: d.chinese, correct: false }))
  ]);
  const correctIdx = options.findIndex(o => o.correct);

  return {
    type: 'en2cn',
    quizType: 'choice',
    dimension: 'recognition',
    vocabId: v.id,
    word: v.word,
    question: v.word,
    questionLabel: '选出正确的中文释义',
    options: options.map(o => o.text),
    correctIdx: correctIdx,
    correctAnswer: v.chinese,
    acceptableAnswers: v.acceptable_answers || [v.word],
    item: v
  };
}

// --- b) Chinese -> English (Recall) ---
function _genCn2En(v) {
  const distractors = _getDistractors(v, 'word', 3);
  if (distractors.length < 3) return _genEn2Cn(v);

  const options = _shuffleArray([
    { text: v.word, correct: true },
    ...distractors.map(d => ({ text: d.word, correct: false }))
  ]);
  const correctIdx = options.findIndex(o => o.correct);

  return {
    type: 'cn2en',
    quizType: 'choice',
    dimension: 'recall',
    vocabId: v.id,
    word: v.word,
    question: v.chinese,
    questionLabel: '选出正确的英文单词',
    options: options.map(o => o.text),
    correctIdx: correctIdx,
    correctAnswer: v.word,
    acceptableAnswers: v.acceptable_answers || [v.word],
    item: v
  };
}

// --- c) Fill-in-blank (Usage) ---
function _genFillBlank(v) {
  const sentence = v.example_en;
  // Build a case-insensitive regex to blank out the word
  const wordRegex = new RegExp('\\b' + _escapeRegex(v.word) + '\\b', 'i');
  let blankedSentence;
  if (wordRegex.test(sentence)) {
    blankedSentence = sentence.replace(wordRegex, '____');
  } else {
    // Try lemma
    const lemmaRegex = new RegExp('\\b' + _escapeRegex(v.lemma || v.word) + '\\b', 'i');
    blankedSentence = lemmaRegex.test(sentence)
      ? sentence.replace(lemmaRegex, '____')
      : sentence.replace(/\S+$/, '____');
  }

  const distractors = _getDistractors(v, 'word', 3);
  if (distractors.length < 3) return _genEn2Cn(v);

  const options = _shuffleArray([
    { text: v.word, correct: true },
    ...distractors.map(d => ({ text: d.word, correct: false }))
  ]);
  const correctIdx = options.findIndex(o => o.correct);

  return {
    type: 'fillblank',
    quizType: 'choice',
    dimension: 'usage',
    vocabId: v.id,
    word: v.word,
    question: blankedSentence,
    questionLabel: '选择正确的单词填入空格',
    options: options.map(o => o.text),
    correctIdx: correctIdx,
    correctAnswer: v.word,
    acceptableAnswers: v.acceptable_answers || [v.word],
    item: v
  };
}

// --- d) First letter input (Recall) ---
function _genFirstLetter(v) {
  const firstLetter = v.word.charAt(0).toUpperCase();
  const wordLen = v.word.length;

  return {
    type: 'firstletter',
    quizType: 'input',
    dimension: 'recall',
    vocabId: v.id,
    word: v.word,
    question: `${v.chinese} (${firstLetter}___, ${wordLen} 个字母)`,
    questionLabel: '拼写完整的英文单词',
    correctAnswer: v.word,
    acceptableAnswers: v.acceptable_answers || [v.word],
    item: v
  };
}

// --- e) Confusable distinction (Usage) ---
function _genConfusable(v) {
  if (!v.confusable || v.confusable.length === 0) return _genEn2Cn(v);

  // Take 1-2 confusable words, mix with the correct word
  const confusableWords = v.confusable.slice(0, 2).map(c => c.word);
  const allOptions = [v.word, ...confusableWords];
  const shuffled = _shuffleArray(allOptions);
  const correctIdx = shuffled.indexOf(v.word);

  // Ask which word means the work_meaning
  return {
    type: 'confusable',
    quizType: 'choice',
    dimension: 'usage',
    vocabId: v.id,
    word: v.word,
    question: `下列哪个词表示「${v.work_meaning || v.chinese}」？`,
    questionLabel: '易混词辨析',
    options: shuffled,
    correctIdx: correctIdx,
    correctAnswer: v.word,
    acceptableAnswers: v.acceptable_answers || [v.word],
    item: v
  };
}

// --- f) Scenario matching (Transfer) ---
function _genScenario(v) {
  // Build a scenario question: "In the context of X, which word fits?"
  const scenario = v.work_context || '日常工作';
  const scenarioText = `工作场景：${scenario}。以下哪个词最适合此场景？`;

  const distractors = _getDistractors(v, 'word', 3);
  if (distractors.length < 3) return _genEn2Cn(v);

  const options = _shuffleArray([
    { text: v.word, correct: true },
    ...distractors.map(d => ({ text: d.word, correct: false }))
  ]);
  const correctIdx = options.findIndex(o => o.correct);

  return {
    type: 'scenario',
    quizType: 'choice',
    dimension: 'transfer',
    vocabId: v.id,
    word: v.word,
    question: scenarioText,
    questionLabel: '场景匹配',
    options: options.map(o => o.text),
    correctIdx: correctIdx,
    correctAnswer: v.word,
    acceptableAnswers: v.acceptable_answers || [v.word],
    item: v
  };
}

function _escapeRegex(str) {
  return String(str || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ---------------------------------------------------------------------------
// 8. Quiz Rendering
// ---------------------------------------------------------------------------

function renderVocabQuiz(app) {
  if (!vocabSession) { navTo('today'); return; }
  vocabSession.phase = 'quiz';

  const queue = vocabSession.quizQueue;
  const idx = vocabSession.quizIdx;

  if (idx >= queue.length) {
    renderVocabSummary(app);
    return;
  }

  const q = queue[idx];
  let questionBody = '';

  if (q.quizType === 'choice') {
    questionBody = `
      <div id="vocab-quiz-options">
        ${q.options.map((opt, i) => `
          <button class="vocab-quiz-option" data-idx="${i}"
            onclick="answerVocabChoice(${i})">${opt}</button>
        `).join('')}
      </div>
    `;
  } else if (q.quizType === 'input') {
    questionBody = `
      <div style="margin-top:12px;">
        <input type="text" id="vocab-quiz-input"
          placeholder="输入英文单词..."
          autocomplete="off" autocapitalize="off" spellcheck="false"
          style="width:100%; padding:14px 16px; font-size:16px; border:2px solid var(--color-border-light); border-radius:var(--radius-md); box-sizing:border-box;"
          onkeypress="if(event.key==='Enter') submitVocabInput()" />
        <button class="btn btn-primary" style="width:100%; margin-top:8px;"
          onclick="submitVocabInput()">提交</button>
      </div>
    `;
  }

  app.innerHTML = `
    <div class="container page">
      ${_renderVocabFlowBar('quiz')}
      <div style="padding: 16px 0 8px;">
        <div class="flex items-center justify-between">
          <h2>单词测验</h2>
          <span class="badge badge-primary">${idx + 1} / ${queue.length}</span>
        </div>
      </div>

      <div class="card">
        <div class="text-secondary text-sm">${q.questionLabel}</div>
        <div style="font-size:18px; font-weight:600; padding:14px 0; line-height:1.6;">${q.question}</div>
        ${questionBody}
      </div>

      <div id="vocab-quiz-feedback" style="display:none;"></div>
    </div>
  `;

  // Auto-focus input
  if (q.quizType === 'input') {
    setTimeout(() => {
      const input = document.getElementById('vocab-quiz-input');
      if (input) input.focus();
    }, 100);
  }
}

// ---------------------------------------------------------------------------
// 9. Answer Checking
// ---------------------------------------------------------------------------

let _vocabAnswered = false;

function answerVocabChoice(selectedIdx) {
  if (!vocabSession || _vocabAnswered) return;
  _vocabAnswered = true;

  const q = vocabSession.quizQueue[vocabSession.quizIdx];
  const isCorrect = selectedIdx === q.correctIdx;

  // Highlight options
  const optionContainer = document.getElementById('vocab-quiz-options');
  if (optionContainer) {
    const btns = optionContainer.querySelectorAll('.vocab-quiz-option');
    btns.forEach((btn, i) => {
      btn.classList.add('disabled');
      if (i === q.correctIdx) btn.classList.add('correct');
      else if (i === selectedIdx) btn.classList.add('incorrect');
    });
  }

  _showVocabFeedback(q, isCorrect, q.options[selectedIdx], null);
}

function submitVocabInput() {
  if (!vocabSession || _vocabAnswered) return;
  _vocabAnswered = true;

  const q = vocabSession.quizQueue[vocabSession.quizIdx];
  const input = document.getElementById('vocab-quiz-input');
  const userInput = input ? input.value : '';

  const isCorrect = _checkInputAnswer(userInput, q);

  // Disable input
  if (input) input.disabled = true;
  const submitBtn = input ? input.nextElementSibling : null;
  if (submitBtn) submitBtn.disabled = true;

  _showVocabFeedback(q, isCorrect, userInput, null);
}

/**
 * Deterministic answer checking for input questions.
 * Case-insensitive, strips punctuation, checks acceptable_answers + variants.
 */
function _checkInputAnswer(userInput, q) {
  const normalize = (s) => {
    return String(s || '')
      .toLowerCase()
      .trim()
      .replace(/[.,!?;:'"]/g, '')
      .replace(/\s+/g, ' ');
  };

  const normalized = normalize(userInput);
  if (!normalized) return false;

  // Collect all acceptable answers
  const acceptable = new Set();
  if (q.correctAnswer) acceptable.add(normalize(q.correctAnswer));
  if (q.acceptableAnswers) {
    q.acceptableAnswers.forEach(a => acceptable.add(normalize(a)));
  }
  // Add the word itself and lemma
  if (q.item) {
    acceptable.add(normalize(q.item.word));
    if (q.item.lemma) acceptable.add(normalize(q.item.lemma));
  }

  // Direct match
  if (acceptable.has(normalized)) return true;

  // Check common spelling variants (allow 1-character difference for longer words)
  for (const ans of acceptable) {
    if (_isSpellingVariant(normalized, ans)) return true;
  }

  return false;
}

/**
 * Check if two strings differ by at most 1 character (insert/delete/substitute)
 * Only for words of length >= 4 to avoid false positives on short words.
 */
function _isSpellingVariant(a, b) {
  if (a === b) return true;
  if (Math.abs(a.length - b.length) > 1) return false;
  if (a.length < 4 || b.length < 4) return a === b;

  // Levenshtein distance == 1
  const dist = _levenshtein(a, b);
  return dist <= 1;
}

function _levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = [];
  for (let i = 0; i <= m; i++) {
    dp[i] = [i];
    for (let j = 1; j <= n; j++) {
      if (i === 0) { dp[i][j] = j; continue; }
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost
      );
    }
  }
  return dp[m][n];
}

// ---------------------------------------------------------------------------
// 10. Feedback + Error Analysis Card
// ---------------------------------------------------------------------------

function _showVocabFeedback(q, isCorrect, userAnswer, hintUsed) {
  const feedback = document.getElementById('vocab-quiz-feedback');
  if (!feedback) return;

  // Record result
  const result = {
    vocabId: q.vocabId,
    word: q.word,
    quizType: q.type,
    dimension: q.dimension,
    isCorrect: isCorrect,
    userAnswer: userAnswer,
    correctAnswer: q.correctAnswer,
    hintUsed: !!hintUsed,
    timestamp: Date.now()
  };
  vocabSession.results.push(result);

  // Update mastery and record error if wrong
  updateVocabMastery(q, isCorrect, hintUsed);
  if (!isCorrect || hintUsed) {
    recordVocabError(q, userAnswer, isCorrect, hintUsed);
  }

  // Build error analysis card
  const bgClass = isCorrect ? 'correct-bg' : 'incorrect-bg';
  const statusText = isCorrect ? '✓ 回答正确' : '✗ 回答错误';
  const statusColor = isCorrect ? 'text-mint' : 'text-coral';

  const v = q.item;
  const userDisplay = userAnswer || '(未作答)';
  const correctDisplay = q.correctAnswer;

  // Why it's wrong — targeted explanation
  let explanation = '';
  if (!isCorrect) {
    if (q.type === 'en2cn') {
      explanation = `「${v.word}」的中文释义是「${v.chinese}」，不是「${userDisplay}」。注意区分相近的中文含义。`;
    } else if (q.type === 'cn2en') {
      explanation = `「${v.chinese}」对应的英文是「${v.word}」，不是「${userDisplay}」。请回忆这个词的拼写。`;
    } else if (q.type === 'fillblank') {
      explanation = `在例句中应该填入「${v.word}」。该词在此语境下表示「${v.work_meaning || v.chinese}」。`;
    } else if (q.type === 'firstletter') {
      explanation = `正确的拼写是「${v.word}」。${v.word.length} 个字母，首字母 ${v.word.charAt(0).toUpperCase()}。`;
    } else if (q.type === 'confusable') {
      explanation = `「${v.word}」表示「${v.work_meaning || v.chinese}」。${v.confusable ? v.confusable.map(c => `「${c.word}」${c.diff}`).join('；') : ''}`;
    } else if (q.type === 'scenario') {
      explanation = `在「${v.work_context}」场景中，最合适的词是「${v.word}」。${v.work_meaning || ''}`;
    } else {
      explanation = `正确答案是「${q.correctAnswer}」。`;
    }
  } else {
    explanation = `回答正确！「${v.word}」= ${v.chinese}。${v.work_meaning || ''}`;
  }

  // Confusable distinction section
  const confusableSection = (v.confusable && v.confusable.length > 0) ? `
    <div class="ea-label">易混淆辨析</div>
    <div class="ea-value">
      ${v.confusable.map(c => `<div><strong>${c.word}</strong> — ${c.diff}</div>`).join('')}
    </div>
  ` : '';

  // Related expression
  const relatedSection = v.related_expression ? `
    <div class="ea-label">相关表达</div>
    <div class="ea-value">${v.related_expression}</div>
  ` : '';

  // Work example
  const exampleSection = v.example_en ? `
    <div class="ea-label">工作例句</div>
    <div class="ea-value">
      <div>${v.example_en}</div>
      <div class="text-light text-xs mt-sm">${v.example_cn || ''}</div>
    </div>
  ` : '';

  // Next review time
  let nextReviewText = '明天复习';
  try {
    const mastery = _masteryCache.get(v.id);
    if (mastery && mastery.next_review_at) {
      const days = Math.max(0, Math.round((mastery.next_review_at - Date.now()) / 86400000));
      nextReviewText = days === 0 ? '今天复习' : days === 1 ? '明天复习' : `${days} 天后复习`;
    }
  } catch (e) {}

  feedback.style.display = 'block';
  feedback.innerHTML = `
    <div class="card">
      <div style="padding:12px 0;">
        <div style="font-size:18px; font-weight:700; color:${isCorrect ? 'var(--color-primary)' : 'var(--color-coral)'};">
          ${statusText}
        </div>
      </div>

      <div class="error-analysis ${bgClass}">
        <div class="ea-label">你的回答</div>
        <div class="ea-value">${userDisplay}</div>

        <div class="ea-label">正确答案</div>
        <div class="ea-value" style="font-weight:600; color:var(--color-primary);">${correctDisplay}</div>

        <div class="ea-label">${isCorrect ? '解析' : '为什么错了'}</div>
        <div class="ea-explanation">${explanation}</div>

        ${exampleSection}
        ${confusableSection}
        ${relatedSection}

        <div class="ea-label">下次复习</div>
        <div class="ea-value">${nextReviewText}</div>
      </div>

      <div style="margin-top:12px;">
        <button class="btn btn-primary" style="width:100%;"
          onclick="nextVocabQuiz()">
          ${vocabSession.quizIdx + 1 < vocabSession.quizQueue.length ? '下一题' : '查看总结'}
        </button>
      </div>
    </div>
  `;

  // Scroll to feedback
  setTimeout(() => {
    feedback.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 100);
}

function nextVocabQuiz() {
  if (!vocabSession) return;
  _vocabAnswered = false;
  vocabSession.quizIdx++;
  const app = document.getElementById('app');
  renderVocabQuiz(app);
}

// ---------------------------------------------------------------------------
// 11. Error Recording
// ---------------------------------------------------------------------------

// In-memory cache for mastery records (avoids repeated DB reads during a session)
const _masteryCache = new Map();

async function recordVocabError(q, userAnswer, isCorrect, hintUsed) {
  try {
    const v = q.item || VOCAB_ITEMS.find(item => item.id === q.vocabId);
    if (!v) return;

    // Check if an existing error record for same vocab_id + same error_type exists
    const allErrors = await dbGetAll(STORES.errorBank);
    const existing = allErrors.find(e =>
      e.vocab_id === v.id && e.error_type === q.type
    );

    // Build explanation
    let explanation = '';
    if (q.type === 'en2cn') {
      explanation = `「${v.word}」的中文是「${v.chinese}」。用户选择了「${userAnswer}」。`;
    } else if (q.type === 'cn2en') {
      explanation = `「${v.chinese}」对应英文「${v.word}」。用户选择了「${userAnswer}」。`;
    } else if (q.type === 'fillblank') {
      explanation = `例句填空应填「${v.word}」。用户选择了「${userAnswer}」。`;
    } else if (q.type === 'firstletter') {
      explanation = `首字母填空正确答案「${v.word}」。用户输入了「${userAnswer}」。`;
    } else if (q.type === 'confusable') {
      explanation = `易混词辨析：正确答案「${v.word}」(${v.chinese})。用户选择了「${userAnswer}」。${v.confusable ? v.confusable.map(c => c.word + ': ' + c.diff).join('; ') : ''}`;
    } else if (q.type === 'scenario') {
      explanation = `场景匹配正确答案「${v.word}」。用户选择了「${userAnswer}」。`;
    }

    // Determine error tag
    let errorTag = 'vocabulary';
    if (q.type === 'firstletter') errorTag = 'spelling';
    else if (q.type === 'confusable') errorTag = 'confusable';
    else if (q.type === 'fillblank') errorTag = 'usage';
    else if (q.type === 'scenario') errorTag = 'transfer';
    else if (q.type === 'en2cn') errorTag = 'recognition';
    else if (q.type === 'cn2en') errorTag = 'recall';

    const userSelectedOption = (q.quizType === 'choice' && typeof userAnswer === 'string')
      ? userAnswer : null;

    if (existing) {
      // Increment occurrence, update fields
      existing.occurrence_count = (existing.occurrence_count || 0) + 1;
      existing.last_seen_at = new Date().toISOString();
      existing.resolved = false;
      existing.resolve_streak = 0;
      existing.user_answer = userAnswer;
      if (userSelectedOption) existing.user_selected_option = userSelectedOption;
      existing.question = q.question;
      existing.explanation = explanation;
      existing.hint_used = !!hintUsed;
      existing.answer_revealed = !!hintUsed;
      existing.next_review_at = Date.now() + 86400000;
      existing.updated_at = new Date().toISOString();
      await dbPut(STORES.errorBank, existing);
    } else {
      // Create new error record
      const errorRecord = {
        id: uuid(),
        vocab_id: v.id,
        word: v.word,
        error_type: q.type,
        quiz_type: q.type,
        question: q.question,
        user_answer: userAnswer,
        user_selected_option: userSelectedOption,
        correct_answer: q.correctAnswer,
        acceptable_answers: v.acceptable_answers || [v.word],
        explanation: explanation,
        error_tag: errorTag,
        work_context: v.work_context || '',
        hint_used: !!hintUsed,
        answer_revealed: !!hintUsed,
        occurrence_count: 1,
        first_seen_at: new Date().toISOString(),
        last_seen_at: new Date().toISOString(),
        next_review_at: Date.now() + 86400000,
        resolved: false,
        resolve_streak: 0,
        learning_item_id: v.id,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      await dbPut(STORES.errorBank, errorRecord);
    }
  } catch (e) {
    console.warn('[vocab] recordVocabError failed', e);
  }
}

// ---------------------------------------------------------------------------
// 12. Mastery Update
// ---------------------------------------------------------------------------

async function updateVocabMastery(q, isCorrect, hintUsed) {
  try {
    const v = q.item || VOCAB_ITEMS.find(item => item.id === q.vocabId);
    if (!v) return;

    // Get or create mastery record
    let mastery = _masteryCache.get(v.id);
    if (!mastery) {
      try {
        mastery = await dbGet(STORES.masteryRecords, v.id);
      } catch (e) {
        mastery = null;
      }
      if (!mastery) {
        mastery = WEC_Algo.initMastery(v.id);
      }
    }

    // Determine rating
    let rating;
    if (hintUsed) {
      rating = 'hard';  // hint/view-answer counts as "hard", not correct
    } else if (isCorrect) {
      rating = 'good';
    } else {
      rating = 'again';
    }

    // Update mastery using WEC_Algo
    mastery = WEC_Algo.updateMastery(mastery, rating, {
      dimension: q.dimension,
      hintUsed: !!hintUsed,
      responseTime: 0
    });

    // Additional mastery advancement rules:
    // - "不确定" (unsure in precheck) doesn't count as mastered
    // - High work_relevance (5) needs transfer dimension
    // - Need both recall + usage stable (score >= 80) for normal words
    if (vocabSession && vocabSession.precheckResults[v.id] === 'unsure') {
      // Force mastery_state to at most "Reviewing" if was marked unsure
      if (mastery.mastery_state === 'Mastered') {
        mastery.mastery_state = 'Reviewing';
      }
    }

    // High work_relevance words need transfer dimension to be Mastered
    if (v.work_relevance === 5 && mastery.mastery_state === 'Mastered') {
      if (mastery.transfer_score < 80 || mastery.transfer_evidence_count < 2) {
        mastery.mastery_state = 'Reviewing';
      }
    }

    // Check if can advance to Mastered: need recall + usage >= 80
    if (mastery.mastery_state !== 'Mastered') {
      const recallStable = mastery.recall_score >= 80 && mastery.recall_evidence_count >= 2;
      const usageStable = mastery.usage_score >= 80 && mastery.usage_evidence_count >= 2;
      if (recallStable && usageStable) {
        if (v.work_relevance === 5) {
          // High relevance also needs transfer
          if (mastery.transfer_score >= 80 && mastery.transfer_evidence_count >= 2) {
            mastery.mastery_state = 'Mastered';
          }
        } else {
          mastery.mastery_state = 'Mastered';
        }
      }
    }

    // If wrong: decrease score, schedule sooner review
    if (!isCorrect) {
      const scoreKey = `${q.dimension}_score`;
      mastery[scoreKey] = Math.max(0, mastery[scoreKey] - 10);
      // Schedule sooner review
      mastery.next_review_at = Date.now() + 86400000; // 1 day
      mastery.interval_days = Math.min(mastery.interval_days, 1);
    }

    // Cache and save
    _masteryCache.set(v.id, mastery);
    await dbPut(STORES.masteryRecords, mastery);

    // Update review schedule
    try {
      let schedule = await dbGet(STORES.reviewSchedule, v.id);
      if (!schedule) {
        schedule = {
          item_id: v.id,
          next_review_at: mastery.next_review_at,
          interval_days: mastery.interval_days,
          review_count: mastery.review_count,
          mastery_state: mastery.mastery_state
        };
      } else {
        schedule.next_review_at = mastery.next_review_at;
        schedule.interval_days = mastery.interval_days;
        schedule.review_count = mastery.review_count;
        schedule.mastery_state = mastery.mastery_state;
      }
      await dbPut(STORES.reviewSchedule, schedule);
    } catch (e) {
      console.warn('[vocab] updateVocabMastery: schedule save failed', e);
    }

    // If error is resolved (correct answer after previous errors), mark error as resolved
    if (isCorrect && !hintUsed) {
      try {
        const allErrors = await dbGetAll(STORES.errorBank);
        const wordErrors = allErrors.filter(e => e.vocab_id === v.id && !e.resolved);
        for (const err of wordErrors) {
          err.resolve_streak = (err.resolve_streak || 0) + 1;
          if (err.resolve_streak >= 2) {
            err.resolved = true;
            err.resolved_at = new Date().toISOString();
          }
          err.updated_at = new Date().toISOString();
          await dbPut(STORES.errorBank, err);
        }
      } catch (e) {
        console.warn('[vocab] error resolution update failed', e);
      }
    }
  } catch (e) {
    console.warn('[vocab] updateVocabMastery failed', e);
  }
}

// ---------------------------------------------------------------------------
// 13. Summary Phase
// ---------------------------------------------------------------------------

function renderVocabSummary(app) {
  if (!vocabSession) { navTo('today'); return; }
  vocabSession.phase = 'summary';

  const results = vocabSession.results;
  const totalWords = vocabSession.targetWords.length;
  const correctCount = results.filter(r => r.isCorrect).length;
  const errorCount = results.filter(r => !r.isCorrect).length;

  // New words learned = words that went through learn phase
  const newWordsLearned = vocabSession.learnWords ? vocabSession.learnWords.length : 0;

  // Error words for retry
  const errorWords = results.filter(r => !r.isCorrect);

  const accuracy = results.length > 0 ? Math.round(correctCount / results.length * 100) : 100;

  const errorListHTML = errorWords.length > 0 ? `
    <div class="card">
      <div class="text-secondary text-sm mb-md">需要重点复习的单词</div>
      ${errorWords.map(r => {
        const v = VOCAB_ITEMS.find(item => item.id === r.vocabId);
        if (!v) return '';
        return `
          <div class="error-bank-card" style="margin-bottom:8px;">
            <div class="eb-header">
              <span class="eb-word">${v.word}</span>
              <span class="eb-type">${r.quizType}</span>
            </div>
            <div class="eb-detail">正确：${r.correctAnswer} · 你的回答：${r.userAnswer || '(未作答)'}</div>
            <div class="eb-actions">
              <button class="btn btn-ghost btn-sm flex-1"
                onclick="retrySingleVocab('${v.id}')">立即重练</button>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  ` : '';

  const elapsed = Math.round((Date.now() - vocabSession.startTime) / 60000);

  app.innerHTML = `
    <div class="container page">
      ${_renderVocabFlowBar('summary')}
      <div style="padding: 20px 0; text-align:center;">
        <h2>学习完成</h2>
        <div class="text-secondary text-sm mt-sm">用时 ${elapsed} 分钟</div>
      </div>

      <div class="card" style="text-align:center; padding:24px;">
        <div style="font-size:48px; font-weight:700; color:var(--color-primary);">${accuracy}%</div>
        <div class="text-secondary text-sm mt-sm">正确率</div>
      </div>

      <div class="card">
        <div class="flex justify-between" style="padding:6px 0;">
          <span class="text-secondary text-sm">总单词数</span>
          <span style="font-weight:600;">${totalWords}</span>
        </div>
        <div class="flex justify-between" style="padding:6px 0;">
          <span class="text-secondary text-sm">答对</span>
          <span class="text-mint" style="font-weight:600;">${correctCount}</span>
        </div>
        <div class="flex justify-between" style="padding:6px 0;">
          <span class="text-secondary text-sm">答错</span>
          <span class="text-coral" style="font-weight:600;">${errorCount}</span>
        </div>
        <div class="flex justify-between" style="padding:6px 0;">
          <span class="text-secondary text-sm">新学单词</span>
          <span style="font-weight:600;">${newWordsLearned}</span>
        </div>
      </div>

      ${errorListHTML}

      <div style="padding: 12px 0 32px;">
        <div class="flex gap-md">
          <button class="btn btn-outline flex-1" onclick="navTo('today')">返回 Today</button>
          <button class="btn btn-primary flex-1" onclick="continueVocabAfterSession()">继续学习表达</button>
        </div>
      </div>
    </div>
  `;
}

function retrySingleVocab(vocabId) {
  startVocabRetry([vocabId]);
}

function continueVocabAfterSession() {
  if (!vocabSession) { navTo('today'); return; }
  // Navigate to expression learning or today page based on session
  if (vocabSession.day && vocabSession.day > 0) {
    navTo('learn', { day: vocabSession.day });
  } else {
    navTo('today');
  }
}

// ---------------------------------------------------------------------------
// 14. Export to window
// ---------------------------------------------------------------------------

window.startVocabSession = startVocabSession;
window.startVocabRetry = startVocabRetry;
window.renderVocabPrecheck = renderVocabPrecheck;
window.renderVocabLearn = renderVocabLearn;
window.renderVocabQuiz = renderVocabQuiz;
window.renderVocabSummary = renderVocabSummary;
window.ratePrecheckWord = ratePrecheckWord;
window.proceedToLearn = proceedToLearn;
window.playVocabWord = playVocabWord;
window.nextVocabLearn = nextVocabLearn;
window.answerVocabChoice = answerVocabChoice;
window.submitVocabInput = submitVocabInput;
window.nextVocabQuiz = nextVocabQuiz;
window.retrySingleVocab = retrySingleVocab;
window.continueVocabAfterSession = continueVocabAfterSession;
