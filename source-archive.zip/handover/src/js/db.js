// ===== IndexedDB Storage Engine =====
// 持久化存储：课程内容、学习记录、复习计划、错题库、导入语料
// 包含内存降级模式：IndexedDB 不可用时自动切换到内存 Map，保证应用可用

const DB_NAME = 'WorkEnglishCoachDB';
const DB_VERSION = 2;

const STORES = {
  knowledgeItems: 'knowledgeItems',       // 知识库条目
  learningAttempts: 'learningAttempts',   // 学习尝试记录
  masteryRecords: 'masteryRecords',       // 四级掌握记录
  reviewSchedule: 'reviewSchedule',       // 复习排程
  errorBank: 'errorBank',                 // 错题库
  dailySessions: 'dailySessions',         // 每日学习记录
  imports: 'imports',                     // 导入的对话
  quizAttempts: 'quizAttempts',           // 测验记录
  conversationSessions: 'conversationSessions', // 对话练习记录
  skillScores: 'skillScores',            // 能力评分
  assessments: 'assessments'              // V2: 入门/阶段测评记录
};

let dbInstance = null;

// ===== 降级模式状态 =====
let _fallbackMode = false;       // 是否处于内存降级模式
let _fallbackReason = '';        // 降级原因（用于诊断）
let _fallbackStores = {};        // 内存中的 store: { storeName: Map(key -> value) }
let _fallbackAutoInc = {};       // 自增计数器

function _initFallbackStores() {
  for (const store of Object.values(STORES)) {
    if (!_fallbackStores[store]) {
      _fallbackStores[store] = new Map();
      _fallbackAutoInc[store] = 1;
    }
  }
}

function isFallbackMode() {
  return _fallbackMode;
}

function getFallbackReason() {
  return _fallbackReason;
}

function enableFallbackMode(reason) {
  if (_fallbackMode) return;
  _fallbackMode = true;
  _fallbackReason = reason || 'unknown';
  _initFallbackStores();
  console.warn('[WEC] IndexedDB 不可用，已切换到内存降级模式。原因：' + _fallbackReason);
}

// ===== openDB：带 onblocked、onerror 和超时处理 =====
function openDB() {
  return new Promise((resolve, reject) => {
    if (_fallbackMode) {
      reject(new Error('fallback mode: ' + _fallbackReason));
      return;
    }
    if (dbInstance) { resolve(dbInstance); return; }

    // 检查 indexedDB 是否存在
    if (typeof indexedDB === 'undefined' || !indexedDB) {
      enableFallbackMode('browser_no_indexeddb');
      reject(new Error('IndexedDB 不可用：浏览器不支持'));
      return;
    }

    let settled = false;
    const timeoutId = setTimeout(() => {
      if (!settled) {
        settled = true;
        enableFallbackMode('open_timeout_5s');
        reject(new Error('IndexedDB 打开超时（5秒无响应）'));
      }
    }, 5000);

    // 监听 boot 超时事件，强制切换降级模式
    var bootTimeoutHandler = function () {
      if (!settled) {
        settled = true;
        clearTimeout(timeoutId);
        enableFallbackMode('boot_timeout_8s');
        reject(new Error('IndexedDB 打开超时（启动8秒超时）'));
      }
    };
    window.addEventListener('wec-boot-timeout', bootTimeoutHandler, { once: true });

    try {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onerror = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timeoutId);
        var reason = 'db_error';
        try {
          if (req.error && req.error.name === 'QuotaExceededError') reason = 'quota_exceeded';
          else if (req.error && req.error.name === 'SecurityError') reason = 'security_error';
          else if (req.error && req.error.message) reason = req.error.message;
        } catch(e) {}
        enableFallbackMode(reason);
        reject(req.error || new Error('IndexedDB 打开失败：' + reason));
      };
      req.onblocked = () => {
        // 数据库被其他标签页占用，等待但不无限等
        if (!settled) {
          settled = true;
          clearTimeout(timeoutId);
          enableFallbackMode('db_blocked_by_other_tab');
          reject(new Error('IndexedDB 被其他标签页阻塞，已切换到内存模式'));
        }
      };
      req.onsuccess = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timeoutId);
        dbInstance = req.result;
        resolve(dbInstance);
      };
      req.onupgradeneeded = (e) => {
      const db = e.target.result;
      // 知识库
      if (!db.objectStoreNames.contains(STORES.knowledgeItems)) {
        const s = db.createObjectStore(STORES.knowledgeItems, { keyPath: 'id' });
        s.createIndex('scenario', 'scenario_id', { unique: false });
        s.createIndex('type', 'type', { unique: false });
        s.createIndex('status', 'status', { unique: false });
        s.createIndex('source', 'source_conversation_id', { unique: false });
      }
      // 学习尝试
      if (!db.objectStoreNames.contains(STORES.learningAttempts)) {
        const s = db.createObjectStore(STORES.learningAttempts, { keyPath: 'id', autoIncrement: true });
        s.createIndex('itemId', 'item_id', { unique: false });
        s.createIndex('date', 'date', { unique: false });
      }
      // 掌握记录
      if (!db.objectStoreNames.contains(STORES.masteryRecords)) {
        db.createObjectStore(STORES.masteryRecords, { keyPath: 'item_id' });
      }
      // 复习排程
      if (!db.objectStoreNames.contains(STORES.reviewSchedule)) {
        const s = db.createObjectStore(STORES.reviewSchedule, { keyPath: 'item_id' });
        s.createIndex('dueDate', 'next_review_at', { unique: false });
      }
      // 错题库
      if (!db.objectStoreNames.contains(STORES.errorBank)) {
        const s = db.createObjectStore(STORES.errorBank, { keyPath: 'id', autoIncrement: true });
        s.createIndex('itemId', 'learning_item_id', { unique: false });
        s.createIndex('resolved', 'resolved', { unique: false });
      }
      // 每日学习
      if (!db.objectStoreNames.contains(STORES.dailySessions)) {
        const s = db.createObjectStore(STORES.dailySessions, { keyPath: 'day' });
        s.createIndex('date', 'date', { unique: false });
      }
      // 导入记录
      if (!db.objectStoreNames.contains(STORES.imports)) {
        const s = db.createObjectStore(STORES.imports, { keyPath: 'id', autoIncrement: true });
        s.createIndex('date', 'import_date', { unique: false });
      }
      // 测验记录
      if (!db.objectStoreNames.contains(STORES.quizAttempts)) {
        db.createObjectStore(STORES.quizAttempts, { keyPath: 'id', autoIncrement: true });
      }
      // 对话记录
      if (!db.objectStoreNames.contains(STORES.conversationSessions)) {
        db.createObjectStore(STORES.conversationSessions, { keyPath: 'id', autoIncrement: true });
      }
      // 能力评分
      if (!db.objectStoreNames.contains(STORES.skillScores)) {
        db.createObjectStore(STORES.skillScores, { keyPath: 'skill_key' });
      }
      // V2: 测评记录（Day 0 入门测评、第12周测评等）
      if (!db.objectStoreNames.contains(STORES.assessments)) {
        const s = db.createObjectStore(STORES.assessments, { keyPath: 'id', autoIncrement: true });
        s.createIndex('type', 'assessment_type', { unique: false });
        s.createIndex('date', 'date', { unique: false });
      }
    };
    } catch (openErr) {
      if (!settled) {
        settled = true;
        clearTimeout(timeoutId);
        enableFallbackMode('open_exception:' + ((openErr && openErr.message) || 'unknown'));
        reject(new Error('IndexedDB 打开异常：' + (openErr && openErr.message)));
      }
    }
  });
}

// ===== 降级模式下的内存操作 =====
function _fallbackPut(store, value) {
  _initFallbackStores();
  var map = _fallbackStores[store] || (_fallbackStores[store] = new Map());
  // 如果 store 有 keyPath，用 keyPath 的值作为 key；否则自增
  var key;
  if (value && value.id) key = value.id;
  else if (value && value.item_id) key = value.item_id;
  else if (value && value.skill_key) key = value.skill_key;
  else if (value && value.day) key = value.day;
  else { key = _fallbackAutoInc[store]++; }
  map.set(key, value);
  return Promise.resolve(value);
}

function _fallbackGet(store, key) {
  _initFallbackStores();
  var map = _fallbackStores[store] || (_fallbackStores[store] = new Map());
  return Promise.resolve(map.get(key) || null);
}

function _fallbackGetAll(store) {
  _initFallbackStores();
  var map = _fallbackStores[store] || (_fallbackStores[store] = new Map());
  return Promise.resolve(Array.from(map.values()));
}

function _fallbackDelete(store, key) {
  _initFallbackStores();
  var map = _fallbackStores[store] || (_fallbackStores[store] = new Map());
  map.delete(key);
  return Promise.resolve();
}

function _fallbackClear(store) {
  _initFallbackStores();
  _fallbackStores[store] = new Map();
  _fallbackAutoInc[store] = 1;
  return Promise.resolve();
}

function _fallbackCount(store) {
  _initFallbackStores();
  var map = _fallbackStores[store] || (_fallbackStores[store] = new Map());
  return Promise.resolve(map.size);
}

function _fallbackGetByIndex(store, indexName, value) {
  // 简化：遍历所有值匹配字段
  _initFallbackStores();
  var map = _fallbackStores[store] || (_fallbackStores[store] = new Map());
  var results = [];
  map.forEach(function(v) {
    if (v && v[indexName] === value) results.push(v);
  });
  return Promise.resolve(results);
}

// ===== 带降级的数据库操作 =====
async function dbPut(store, value) {
  if (_fallbackMode) return _fallbackPut(store, value);
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).put(value);
      tx.oncomplete = () => resolve(value);
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    enableFallbackMode('put_fail:' + (e && e.message || 'unknown'));
    return _fallbackPut(store, value);
  }
}

async function dbGet(store, key) {
  if (_fallbackMode) return _fallbackGet(store, key);
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    enableFallbackMode('get_fail:' + (e && e.message || 'unknown'));
    return _fallbackGet(store, key);
  }
}

async function dbGetAll(store) {
  if (_fallbackMode) return _fallbackGetAll(store);
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    enableFallbackMode('getAll_fail:' + (e && e.message || 'unknown'));
    return _fallbackGetAll(store);
  }
}

async function dbDelete(store, key) {
  if (_fallbackMode) return _fallbackDelete(store, key);
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    enableFallbackMode('delete_fail:' + (e && e.message || 'unknown'));
    return _fallbackDelete(store, key);
  }
}

async function dbClear(store) {
  if (_fallbackMode) return _fallbackClear(store);
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    enableFallbackMode('clear_fail:' + (e && e.message || 'unknown'));
    return _fallbackClear(store);
  }
}

async function dbGetByIndex(store, indexName, value) {
  if (_fallbackMode) return _fallbackGetByIndex(store, indexName, value);
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readonly');
      const idx = tx.objectStore(store).index(indexName);
      const req = idx.getAll(value);
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    enableFallbackMode('getByIndex_fail:' + (e && e.message || 'unknown'));
    return _fallbackGetByIndex(store, indexName, value);
  }
}

async function dbCount(store) {
  if (_fallbackMode) return _fallbackCount(store);
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).count();
      req.onsuccess = () => resolve(req.result || 0);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    enableFallbackMode('count_fail:' + (e && e.message || 'unknown'));
    return _fallbackCount(store);
  }
}

// ===== Export / Import All Data =====
async function exportAllData() {
  const data = {};
  for (const [key, store] of Object.entries(STORES)) {
    try {
      data[key] = await dbGetAll(store);
    } catch (e) {
      data[key] = [];
    }
  }
  data._meta = { exportDate: new Date().toISOString(), version: DB_VERSION, app: 'WorkEnglishCoach' };
  return data;
}

async function importAllData(jsonData, replaceMode = true) {
  // 降级模式下也可导入到内存
  if (!jsonData || typeof jsonData !== 'object') throw new Error('数据格式无效');
  if (!jsonData._meta || jsonData._meta.app !== 'WorkEnglishCoach') {
    throw new Error('这不是 Work English Coach 的备份文件');
  }

  // 先备份当前数据
  const backup = await exportAllData();

  try {
    for (const [key, store] of Object.entries(STORES)) {
      if (replaceMode) await dbClear(store);
      if (jsonData[key] && Array.isArray(jsonData[key])) {
        for (const item of jsonData[key]) {
          await dbPut(store, item);
        }
      }
    }
    return { success: true, backup };
  } catch (e) {
    // 恢复备份
    for (const [key, store] of Object.entries(STORES)) {
      try {
        await dbClear(store);
        if (backup[key] && Array.isArray(backup[key])) {
          for (const item of backup[key]) {
            await dbPut(store, item);
          }
        }
      } catch (re) {}
    }
    throw new Error('导入失败，已恢复原数据: ' + e.message);
  }
}

async function resetAllData() {
  for (const store of Object.values(STORES)) {
    try { await dbClear(store); } catch (e) {}
  }
}

// ===== 诊断信息 =====
function getDBDiagnostics() {
  var diag = {
    fallbackMode: _fallbackMode,
    fallbackReason: _fallbackReason || null,
    dbReady: !!dbInstance,
    indexedDBAvailable: typeof indexedDB !== 'undefined' && !!indexedDB
  };
  if (_fallbackMode) {
    var storeInfo = {};
    for (var store of Object.values(STORES)) {
      storeInfo[store] = (_fallbackStores[store] || new Map()).size;
    }
    diag.fallbackStoreCounts = storeInfo;
  }
  return diag;
}
