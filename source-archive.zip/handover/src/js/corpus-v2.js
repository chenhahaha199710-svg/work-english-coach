// ===== V2 New Corpus: 70 items from 3 meeting transcripts =====
// Source files (anonymized):
//   src-1: 《服务相关指标及复盘内容讨论》— metrics, targets, cost allocation, review
//   src-2: 《群继承项目落地方案讨论》— migration, risks, BI impact, cross-team coordination
//   src-3: 《空冰洗兜底服务方案讨论》— authorization, fallback, escalation, SOP, timeline

const V2_KNOWLEDGE_ITEMS = [
  // === Module 1: 工单指标与复盘 (25 items: ki-051 ~ ki-075) ===
  // Source: src-1 (服务相关指标及复盘内容讨论)
  {
    id: 'ki-051', type: 'work_expression',
    english: 'Let me clarify how this metric is calculated.',
    chinese: '让我说明一下这个指标是怎么计算的。',
    example_sentence: 'Let me clarify how this metric is calculated before we set the target.',
    natural_alternatives: ['Let me explain the calculation method.', 'I want to clarify the formula behind this number.'],
    common_mistakes: ['Let me clear how this metric (×)'],
    usage_note: '讨论指标口径时的标准开场，避免数据理解不一致。', work_context: '指标讨论',
    scenario_id: 'sc-data', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['this metric', 'this KPI', 'this number'],
    source_file: 'src-1', source_scenario: '指标口径讨论', privacy_check_status: 'passed'
  },
  {
    id: 'ki-052', type: 'work_expression',
    english: 'We need a comparable baseline before setting the target.',
    chinese: '在设定目标之前，我们需要一个可比较的基准值。',
    example_sentence: 'We need a comparable baseline before setting the target for August.',
    natural_alternatives: ['We should establish a baseline first.', 'Before we set a goal, we need a fair reference point.'],
    common_mistakes: ['We need a baseline before set the target (×)'],
    usage_note: '强调目标设定前需要合理的基准。', work_context: '目标设定',
    scenario_id: 'sc-data', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['the target', 'the goal'],
    source_file: 'src-1', source_scenario: '基准值讨论', privacy_check_status: 'passed'
  },
  {
    id: 'ki-053', type: 'work_expression',
    english: 'The current figure is not directly comparable with last year\'s number.',
    chinese: '当前数据与去年数据不可直接比较。',
    example_sentence: 'The current figure is not directly comparable with last year\'s number because the criteria have changed.',
    natural_alternatives: ['This number isn\'t apples-to-apples with last year.', 'The definition has changed, so we can\'t compare directly.'],
    common_mistakes: ['is not comparable with last year (×, 缺directly/number)'],
    usage_note: '口径变化时说明数据不可比。', work_context: '数据不可比说明',
    scenario_id: 'sc-data', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['last year\'s number', 'the previous period'],
    source_file: 'src-1', source_scenario: '关单标准变更', privacy_check_status: 'passed'
  },
  {
    id: 'ki-054', type: 'sentence_pattern',
    english: 'Could we break this down by scenario?',
    chinese: '能按场景拆分一下吗？',
    example_sentence: 'Could we break this down by scenario? The overall number is misleading.',
    natural_alternatives: ['Can we split this by category?', 'Let\'s segment the data by use case.'],
    common_mistakes: ['break this by scenario (×, 缺down)'],
    usage_note: '要求细化分析数据维度。', work_context: '数据分析',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'semi-formal', replaceable_variables: ['by scenario', 'by city', 'by category'],
    source_file: 'src-1', source_scenario: '数据拆分讨论', privacy_check_status: 'passed'
  },
  {
    id: 'ki-055', type: 'work_expression',
    english: 'Let\'s use May\'s value as the baseline.',
    chinese: '我们用五月份的数据作为基准。',
    example_sentence: 'Let\'s use May\'s value as the baseline since the criteria changed in June.',
    natural_alternatives: ['Let\'s anchor the target to May.', 'We\'ll use May as the reference point.'],
    common_mistakes: ['use May as baseline (×, 缺value/the)'],
    usage_note: '选择基准月时的表达。', work_context: '基准设定',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'semi-formal', replaceable_variables: ['May\'s value', 'Q1 average', 'last month'],
    source_file: 'src-1', source_scenario: '基准月选择', privacy_check_status: 'passed'
  },
  {
    id: 'ki-056', type: 'work_expression',
    english: 'We aim to reduce this by 30% compared to the same period last year.',
    chinese: '我们的目标是同比去年降低30%。',
    example_sentence: 'We aim to reduce the average response time by 30% compared to the same period last year.',
    natural_alternatives: ['Our target is a 30% year-over-year reduction.', 'We want to bring it down by 30% vs. last year.'],
    common_mistakes: ['reduce 30% compared last year (×, 缺to/by)'],
    usage_note: '设定同比目标的标准表达。', work_context: '目标设定',
    scenario_id: 'sc-data', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['30%', 'the same period last year'],
    source_file: 'src-1', source_scenario: '目标设定', privacy_check_status: 'passed'
  },
  {
    id: 'ki-057', type: 'work_expression',
    english: 'The target for August is set at ___.',
    chinese: '八月份的目标定为___。',
    example_sentence: 'The target for August is set at 110 consultations per 10,000 units.',
    natural_alternatives: ['We\'re setting the August target at ___.', 'For August, the goal is ___.'],
    common_mistakes: ['The target of August is (×)'],
    usage_note: '明确月度目标数值。', work_context: '目标设定',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['August', '110 consultations per 10,000 units'],
    source_file: 'src-1', source_scenario: '月度目标', privacy_check_status: 'passed'
  },
  {
    id: 'ki-058', type: 'chunk',
    english: 'per 10,000 units', chinese: '万套',
    chunk: 'per 10,000 units',
    example_sentence: 'The consultation rate is calculated per 10,000 managed units.',
    natural_alternatives: ['per ten thousand properties', 'per 10K units'],
    common_mistakes: ['per ten thousands (×)'],
    usage_note: '描述频率指标的基数单位。', work_context: '指标计算',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 4, communication_value: 4,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['10,000 units', '1,000 units'],
    source_file: 'src-1', source_scenario: '百房/万房指标', privacy_check_status: 'passed'
  },
  {
    id: 'ki-059', type: 'work_expression',
    english: 'The criteria for closing tickets have changed.',
    chinese: '工单关单标准已经调整了。',
    example_sentence: 'The criteria for closing tickets have changed, so we can\'t compare with last quarter.',
    natural_alternatives: ['Our ticket closure definition has been updated.', 'The resolution standard changed.'],
    common_mistakes: ['The criteria has changed (×, criteria是复数)'],
    usage_note: '说明口径变更影响可比性。', work_context: '指标口径',
    scenario_id: 'sc-data', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['closing tickets', 'measuring response time'],
    source_file: 'src-1', source_scenario: '关单标准变更', privacy_check_status: 'passed'
  },
  {
    id: 'ki-060', type: 'work_expression',
    english: 'This number is fair across all cities.',
    chinese: '这个指标在各城市之间是公平的。',
    example_sentence: 'This metric is fair across all cities because it\'s based on actual ticket volume.',
    natural_alternatives: ['This gives a level playing field.', 'This metric is equitable across regions.'],
    common_mistakes: ['is fair to all cities (×, 用across)'],
    usage_note: '强调指标公平性。', work_context: '指标讨论',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 4, frequency: 3, reusability: 4, communication_value: 4,
    skill_key: 'report_data',
    formality: 'semi-formal', replaceable_variables: ['all cities', 'all regions'],
    source_file: 'src-1', source_scenario: '指标公平性', privacy_check_status: 'passed'
  },
  // === 费用拆分与复盘 (src-1 continued) ===
  {
    id: 'ki-061', type: 'work_expression',
    english: 'Let me break down the cost allocation.',
    chinese: '让我拆分一下费用归属。',
    example_sentence: 'Let me break down the cost allocation: the asset manager covered 5 cases and the owner covered 10.',
    natural_alternatives: ['Here\'s the cost breakdown.', 'Let me walk through who paid for what.'],
    common_mistakes: ['break down the cost (×, 缺allocation可但加更好)'],
    usage_note: '费用复盘时拆分费用来源。', work_context: '费用复盘',
    scenario_id: 'sc-repair', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['cost allocation', 'expense breakdown'],
    source_file: 'src-1', source_scenario: '费用拆分', privacy_check_status: 'passed'
  },
  {
    id: 'ki-062', type: 'work_expression',
    english: 'In terms of cost responsibility, ___',
    chinese: '在费用承担方面，___',
    example_sentence: 'In terms of cost responsibility, the asset manager handled 5 cases and the owner handled 10.',
    natural_alternatives: ['Regarding who covers the cost, ___', 'On the expense side, ___'],
    common_mistakes: ['In term of (×, 缺s)'],
    usage_note: '引入费用归属分析。', work_context: '费用复盘',
    scenario_id: 'sc-repair', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['cost responsibility', 'expense allocation'],
    source_file: 'src-1', source_scenario: '费用归属', privacy_check_status: 'passed'
  },
  {
    id: 'ki-063', type: 'work_expression',
    english: 'The owner\'s share of the cost was ___.',
    chinese: '业主承担的费用占比是___。',
    example_sentence: 'The owner\'s share of the cost was 55% of the total.',
    natural_alternatives: ['The owner covered ___ of the cost.', 'The owner bore ___ of the expense.'],
    common_mistakes: ['The owner share (×, 缺所有格)'],
    usage_note: '描述费用分摊比例。', work_context: '费用复盘',
    scenario_id: 'sc-repair', difficulty: 2, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 4,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['55%', 'the majority'],
    source_file: 'src-1', source_scenario: '费用占比', privacy_check_status: 'passed'
  },
  {
    id: 'ki-064', type: 'work_expression',
    english: 'We need to separate cases where no cost was incurred.',
    chinese: '我们需要把没有产生费用的单子分出来。',
    example_sentence: 'We need to separate cases where no cost was incurred from the expense report.',
    natural_alternatives: ['We should filter out zero-cost cases.', 'Let\'s exclude cases with no expense.'],
    common_mistakes: ['no cost was happened (×)'],
    usage_note: '复盘时区分费用场景。', work_context: '费用复盘',
    scenario_id: 'sc-repair', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 4,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['no cost was incurred', 'the owner refused'],
    source_file: 'src-1', source_scenario: '零费用单子', privacy_check_status: 'passed'
  },
  {
    id: 'ki-065', type: 'work_expression',
    english: 'We found that direct owner contact leads to faster resolution.',
    chinese: '我们发现直接联系业主解决更快。',
    example_sentence: 'We found that direct owner contact leads to faster resolution than going through the asset manager.',
    natural_alternatives: ['Direct owner outreach resolves things faster.', 'Reaching the owner directly speeds things up.'],
    common_mistakes: ['leads to faster resolve (×, 用resolution)'],
    usage_note: '复盘结论：直接联系业主比通过资管转达更快。', work_context: '复盘结论',
    scenario_id: 'sc-repair', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 5, communication_value: 5,
    skill_key: 'explain_problems',
    formality: 'semi-formal', replaceable_variables: ['faster resolution', 'better outcomes'],
    source_file: 'src-1', source_scenario: '联系路径复盘', privacy_check_status: 'passed'
  },
  {
    id: 'ki-066', type: 'work_expression',
    english: 'The response time is longer when it goes through multiple layers.',
    chinese: '经过多层转达时响应时间更长。',
    example_sentence: 'The response time is longer when it goes through multiple layers of approval.',
    natural_alternatives: ['More handoffs mean slower response.', 'Going through intermediaries adds delays.'],
    common_mistakes: ['through multiple layer (×, 缺s)'],
    usage_note: '描述流程链路过长导致延迟。', work_context: '流程复盘',
    scenario_id: 'sc-delay', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'explain_reasons',
    formality: 'semi-formal', replaceable_variables: ['multiple layers', 'intermediaries'],
    source_file: 'src-1', source_scenario: '多层转达复盘', privacy_check_status: 'passed'
  },
  {
    id: 'ki-067', type: 'work_expression',
    english: 'Let\'s categorize these by resolution path.',
    chinese: '让我们按解决路径分类。',
    example_sentence: 'Let\'s categorize these by resolution path so we can identify bottlenecks.',
    natural_alternatives: ['Let\'s group these by how they were resolved.', 'We should classify by resolution method.'],
    common_mistakes: ['categorize by resolution (×, 缺path可但建议加)'],
    usage_note: '复盘时按解决路径分类分析。', work_context: '复盘分析',
    scenario_id: 'sc-repair', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['resolution path', 'cost category'],
    source_file: 'src-1', source_scenario: '复盘分类', privacy_check_status: 'passed'
  },
  {
    id: 'ki-068', type: 'work_expression',
    english: 'The three-day resolution rate is currently at ___.',
    chinese: '三日解决率目前是___。',
    example_sentence: 'The three-day resolution rate is currently at 6.5%.',
    natural_alternatives: ['Our 72-hour resolution rate stands at ___.', 'The three-day closure rate is ___.'],
    common_mistakes: ['resolution rate is currently on (×, 用at)'],
    usage_note: '汇报核心时效指标。', work_context: '指标汇报',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['6.5%', '10%'],
    source_file: 'src-1', source_scenario: '三日解决率', privacy_check_status: 'passed'
  },
  {
    id: 'ki-069', type: 'work_expression',
    english: 'We should anchor the target and work backwards.',
    chinese: '我们应该锚定目标然后倒推。',
    example_sentence: 'We should anchor the target and work backwards to identify the key actions needed.',
    natural_alternatives: ['Let\'s set the goal and reverse-engineer the steps.', 'We\'ll fix the target and plan backwards.'],
    common_mistakes: ['work backward (×, 可单数但不加s不对)'],
    usage_note: '从目标倒推行动方案。', work_context: '目标管理',
    scenario_id: 'sc-nextstep', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'semi-formal', replaceable_variables: ['the target', 'the goal'],
    source_file: 'src-1', source_scenario: '目标倒推', privacy_check_status: 'passed'
  },
  {
    id: 'ki-070', type: 'work_expression',
    english: 'This metric is hard to set because the baseline keeps shifting.',
    chinese: '这个指标很难定，因为基准一直在变。',
    example_sentence: 'This metric is hard to set because the baseline keeps shifting with the new criteria.',
    natural_alternatives: ['It\'s difficult to establish a target when the baseline isn\'t stable.', 'The moving baseline makes target-setting tricky.'],
    common_mistakes: ['baseline keeps shift (×)'],
    usage_note: '说明目标设定困难的原因。', work_context: '指标讨论',
    scenario_id: 'sc-data', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 4,
    skill_key: 'explain_problems',
    formality: 'semi-formal', replaceable_variables: ['the baseline', 'the criteria'],
    source_file: 'src-1', source_scenario: '目标难定', privacy_check_status: 'passed'
  },
  {
    id: 'ki-071', type: 'work_expression',
    english: 'We need to track this on a weekly basis.',
    chinese: '我们需要按周追踪这个指标。',
    example_sentence: 'We need to track this on a weekly basis and adjust if needed.',
    natural_alternatives: ['We should monitor this weekly.', 'Let\'s review this every week.'],
    common_mistakes: ['on week basis (×)'],
    usage_note: '明确监控频率。', work_context: '指标追踪',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 4,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['weekly', 'daily', 'monthly'],
    source_file: 'src-1', source_scenario: '追踪频率', privacy_check_status: 'passed'
  },
  {
    id: 'ki-072', type: 'work_expression',
    english: 'The overall trend shows improvement, but we still have gaps.',
    chinese: '整体趋势在改善，但我们还有差距。',
    example_sentence: 'The overall trend shows improvement, but we still have gaps in the three-day resolution rate.',
    natural_alternatives: ['We\'re trending up, but there\'s room to grow.', 'The numbers are better, but not where we need them.'],
    common_mistakes: ['trend show (×, 缺s)'],
    usage_note: '汇报整体趋势和差距。', work_context: '趋势分析',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'semi-formal', replaceable_variables: ['improvement', 'gaps'],
    source_file: 'src-1', source_scenario: '趋势分析', privacy_check_status: 'passed'
  },
  {
    id: 'ki-073', type: 'work_expression',
    english: 'Let\'s do a deep dive into the outliers.',
    chinese: '让我们深入分析一下异常值。',
    example_sentence: 'Let\'s do a deep dive into the outliers and understand why they exceeded 72 hours.',
    natural_alternatives: ['Let\'s investigate the anomalies.', 'We should look at the edge cases.'],
    common_mistakes: ['deep dive to (×, 用into)'],
    usage_note: '要求对异常数据深入分析。', work_context: '数据分析',
    scenario_id: 'sc-data', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'semi-formal', replaceable_variables: ['the outliers', 'the anomalies'],
    source_file: 'src-1', source_scenario: '异常分析', privacy_check_status: 'passed'
  },
  {
    id: 'ki-074', type: 'work_expression',
    english: 'We should separate new contracts from existing ones.',
    chinese: '我们应该把新签和存量分开看。',
    example_sentence: 'We should separate new contracts from existing ones because their service patterns differ.',
    natural_alternatives: ['Let\'s split new vs. renewing.', 'We should look at new and existing separately.'],
    common_mistakes: ['separate new from existing (×, 缺contracts可但建议加)'],
    usage_note: '区分新签和存量分析。', work_context: '数据分析',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 4,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['new contracts', 'existing ones'],
    source_file: 'src-1', source_scenario: '新签存量区分', privacy_check_status: 'passed'
  },
  {
    id: 'ki-075', type: 'work_expression',
    english: 'The key takeaway from this review is ___.',
    chinese: '这次复盘的核心结论是___。',
    example_sentence: 'The key takeaway from this review is that direct owner contact is faster.',
    natural_alternatives: ['The main lesson here is ___.', 'What we learned is ___.'],
    common_mistakes: ['takeaway from review is (×, 缺this)'],
    usage_note: '复盘总结的标准表达。', work_context: '复盘总结',
    scenario_id: 'sc-reporting', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'give_updates',
    formality: 'semi-formal', replaceable_variables: ['this review', 'this analysis'],
    source_file: 'src-1', source_scenario: '复盘总结', privacy_check_status: 'passed'
  },

  // === Module 2: 跨部门讨论 (25 items: ki-076 ~ ki-100) ===
  // Source: src-2 (群继承项目落地方案讨论)
  {
    id: 'ki-076', type: 'work_expression',
    english: 'Let me give you some background on this project.',
    chinese: '让我介绍一下这个项目的背景。',
    example_sentence: 'Let me give you some background on this project before we discuss the details.',
    natural_alternatives: ['Here\'s the context for this project.', 'Let me set the stage first.'],
    common_mistakes: ['give you background of this (×, 用on)'],
    usage_note: '会议开场介绍项目背景。', work_context: '项目沟通',
    scenario_id: 'sc-reporting', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'give_updates',
    formality: 'formal', replaceable_variables: ['this project', 'this initiative'],
    source_file: 'src-2', source_scenario: '项目背景介绍', privacy_check_status: 'passed'
  },
  {
    id: 'ki-077', type: 'work_expression',
    english: 'We have 186 out of 219 completed, with 33 remaining.',
    chinese: '219个中已完成186个，还剩33个。',
    example_sentence: 'We have 186 out of 219 completed, with 33 remaining for this week.',
    natural_alternatives: ['186 of 219 are done, 33 to go.', 'We\'ve finished 186 of 219, leaving 33.'],
    common_mistakes: ['186 of 219 completed with 33 remaining (×, 缺have/are)'],
    usage_note: '汇报进度数据。', work_context: '项目进度',
    scenario_id: 'sc-reporting', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['186', '219', '33'],
    source_file: 'src-2', source_scenario: '迁移进度', privacy_check_status: 'passed'
  },
  {
    id: 'ki-078', type: 'work_expression',
    english: 'The migration failed for 98,000 groups.',
    chinese: '98000个群迁移失败。',
    example_sentence: 'The migration failed for 98,000 groups because the accounts were not reauthorized in time.',
    natural_alternatives: ['98,000 groups failed to migrate.', 'We had 98,000 migration failures.'],
    common_mistakes: ['failed for 98,000 (×, 缺groups可但建议加)'],
    usage_note: '汇报失败数量和影响范围。', work_context: '项目汇报',
    scenario_id: 'sc-reporting', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['98,000 groups', '50,000 accounts'],
    source_file: 'src-2', source_scenario: '迁移失败', privacy_check_status: 'passed'
  },
  {
    id: 'ki-079', type: 'work_expression',
    english: 'The root cause is that the accounts were not reauthorized within the year.',
    chinese: '根本原因是账号在一年内没有重新授权。',
    example_sentence: 'The root cause is that the accounts were not reauthorized within the year, so the platform blocked the transfer.',
    natural_alternatives: ['The underlying issue is expired authorization.', 'It failed because re-login wasn\'t done in time.'],
    common_mistakes: ['root cause is accounts (×, 缺that)'],
    usage_note: '解释项目失败的根本原因。', work_context: '原因分析',
    scenario_id: 'sc-reason', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'explain_reasons',
    formality: 'formal', replaceable_variables: ['accounts', 'within the year'],
    source_file: 'src-2', source_scenario: '失败原因', privacy_check_status: 'passed'
  },
  {
    id: 'ki-080', type: 'work_expression',
    english: 'Option A is to maintain the status quo, but the impact is ___.',
    chinese: '方案A是保持现状，但影响是___。',
    example_sentence: 'Option A is to maintain the status quo, but the impact is that the service管家 would need manual workarounds.',
    natural_alternatives: ['We could leave things as-is, but then ___.', 'Doing nothing is an option, but ___.'],
    common_mistakes: ['maintain the status (×, 缺quo)'],
    usage_note: '对比方案时的标准表达。', work_context: '方案比较',
    scenario_id: 'sc-nextstep', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['maintain the status quo', 'the service team'],
    source_file: 'src-2', source_scenario: '方案A', privacy_check_status: 'passed'
  },
  {
    id: 'ki-081', type: 'work_expression',
    english: 'Option B is to create new groups, but the trade-off is ___.',
    chinese: '方案B是创建新群，但代价是___。',
    example_sentence: 'Option B is to create new groups, but the trade-off is that customers will see two groups temporarily.',
    natural_alternatives: ['Alternatively, we could build new groups, but ___.', 'The other option is creating new groups, with the caveat that ___.'],
    common_mistakes: ['trade-off is (×, 可用但建议补that)'],
    usage_note: '描述方案B及权衡。', work_context: '方案比较',
    scenario_id: 'sc-nextstep', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['create new groups', 'customers will see two groups'],
    source_file: 'src-2', source_scenario: '方案B', privacy_check_status: 'passed'
  },
  {
    id: 'ki-082', type: 'work_expression',
    english: 'We need to design a communication plan for the customers.',
    chinese: '我们需要为客户设计一个沟通方案。',
    example_sentence: 'We need to design a communication plan for the customers so they understand the transition.',
    natural_alternatives: ['We should prepare a customer-facing message.', 'We need a comms strategy for the transition.'],
    common_mistakes: ['communication plan for customers (×, 缺the)'],
    usage_note: '提出对客沟通需求。', work_context: '跨部门协作',
    scenario_id: 'sc-owner-comm', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['communication plan', 'customers'],
    source_file: 'src-2', source_scenario: '对客沟通', privacy_check_status: 'passed'
  },
  {
    id: 'ki-083', type: 'work_expression',
    english: 'The transition period should be kept as short as possible.',
    chinese: '过渡期应尽量短。',
    example_sentence: 'The transition period should be kept as short as possible, ideally 48 to 72 hours.',
    natural_alternatives: ['Let\'s minimize the overlap window.', 'We should keep the coexistence period brief.'],
    common_mistakes: ['as short as possible (×, 正确但应说明具体时长)'],
    usage_note: '控制过渡期时长。', work_context: '项目计划',
    scenario_id: 'sc-nextstep', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['short as possible', '48 to 72 hours'],
    source_file: 'src-2', source_scenario: '过渡期', privacy_check_status: 'passed'
  },
  {
    id: 'ki-084', type: 'work_expression',
    english: 'There\'s a risk that customers continue using the old channel.',
    chinese: '存在客户继续使用旧渠道的风险。',
    example_sentence: 'There\'s a risk that customers continue using the old channel without noticing the change.',
    natural_alternatives: ['Customers might miss the transition and keep using the old group.', 'We risk customers falling through the cracks.'],
    common_mistakes: ['risk that customers continue (×, 正确但可加using)'],
    usage_note: '识别项目风险点。', work_context: '风险管理',
    scenario_id: 'sc-reason', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'explain_problems',
    formality: 'semi-formal', replaceable_variables: ['old channel', 'old group'],
    source_file: 'src-2', source_scenario: '风险识别', privacy_check_status: 'passed'
  },
  {
    id: 'ki-085', type: 'work_expression',
    english: 'We should skip cases with pending tickets and retry the next day.',
    chinese: '我们应该跳过有在途工单的，第二天再重试。',
    example_sentence: 'We should skip cases with pending tickets and retry the next day to avoid disruption.',
    natural_alternatives: ['Let\'s bypass active cases and queue them for tomorrow.', 'Skip in-progress items and retry later.'],
    common_mistakes: ['skip cases with pending ticket (×, 缺s)'],
    usage_note: '处理在途数据的技术方案。', work_context: '技术方案',
    scenario_id: 'sc-sop', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 4,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['pending tickets', 'the next day'],
    source_file: 'src-2', source_scenario: '在途单处理', privacy_check_status: 'passed'
  },
  {
    id: 'ki-086', type: 'work_expression',
    english: 'The BI team needs to assess the reporting impact.',
    chinese: 'BI团队需要评估对报表的影响。',
    example_sentence: 'The BI team needs to assess the reporting impact because the data structure is changing.',
    natural_alternatives: ['BI should evaluate the effect on dashboards.', 'We need BI to review the data implications.'],
    common_mistakes: ['assess the reporting (×, 缺impact)'],
    usage_note: '跨部门协作中要求BI评估。', work_context: '跨部门协作',
    scenario_id: 'sc-confirm', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'confirm_owner',
    formality: 'formal', replaceable_variables: ['BI team', 'reporting impact'],
    source_file: 'src-2', source_scenario: 'BI影响评估', privacy_check_status: 'passed'
  },
  {
    id: 'ki-087', type: 'work_expression',
    english: 'The data extraction logic will change because one contract now maps to two groups.',
    chinese: '取数逻辑会变化，因为一个合同现在对应两个群。',
    example_sentence: 'The data extraction logic will change because one contract now maps to two groups during the transition.',
    natural_alternatives: ['The query needs updating since the mapping changed.', 'BI queries must account for the one-to-two mapping.'],
    common_mistakes: ['one contract now map to (×, 缺s)'],
    usage_note: '说明数据结构变化的影响。', work_context: '数据影响',
    scenario_id: 'sc-data', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 5,
    skill_key: 'explain_problems',
    formality: 'formal', replaceable_variables: ['one contract', 'two groups'],
    source_file: 'src-2', source_scenario: '取数逻辑变更', privacy_check_status: 'passed'
  },
  {
    id: 'ki-088', type: 'work_expression',
    english: 'Can we explore whether the platform supports ownership transfer?',
    chinese: '能否确认平台是否支持群主转让？',
    example_sentence: 'Can we explore whether the platform supports ownership transfer instead of creating new groups?',
    natural_alternatives: ['Does the platform allow ownership change?', 'Is there a way to transfer group ownership?'],
    common_mistakes: ['explore whether platform supports (×, 缺the)'],
    usage_note: '探索替代技术方案。', work_context: '技术探索',
    scenario_id: 'sc-nextstep', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['ownership transfer', 'group migration'],
    source_file: 'src-2', source_scenario: '替代方案探索', privacy_check_status: 'passed'
  },
  {
    id: 'ki-089', type: 'work_expression',
    english: 'If this doesn\'t work, we\'ll fall back to the original plan.',
    chinese: '如果不行，我们就回退到原方案。',
    example_sentence: 'If this doesn\'t work, we\'ll fall back to the original plan of creating new groups.',
    natural_alternatives: ['If not, we go with plan A.', 'Otherwise, we revert to the standard approach.'],
    common_mistakes: ['fall back to original plan (×, 缺the)'],
    usage_note: '设定方案不成的退路。', work_context: '方案规划',
    scenario_id: 'sc-fallback', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'semi-formal', replaceable_variables: ['the original plan', 'plan A'],
    source_file: 'src-2', source_scenario: '退路方案', privacy_check_status: 'passed'
  },
  {
    id: 'ki-090', type: 'work_expression',
    english: 'We should clean up invalid tickets during this migration.',
    chinese: '我们应该在这次迁移中清理无效工单。',
    example_sentence: 'We should clean up invalid tickets during this migration, especially those without an assignee.',
    natural_alternatives: ['Let\'s use this migration to purge stale items.', 'This is a good time to clean up dead tickets.'],
    common_mistakes: ['clean up invalid ticket (×, 缺s)'],
    usage_note: '借迁移机会清理数据。', work_context: '数据治理',
    scenario_id: 'sc-sop', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 4,
    skill_key: 'suggest_next',
    formality: 'semi-formal', replaceable_variables: ['invalid tickets', 'stale items'],
    source_file: 'src-2', source_scenario: '数据清理', privacy_check_status: 'passed'
  },
  {
    id: 'ki-091', type: 'work_expression',
    english: 'Let\'s start with clean groups first, then handle the complex ones.',
    chinese: '先处理干净的群，再处理复杂的。',
    example_sentence: 'Let\'s start with clean groups first, then handle the complex ones with pending tickets.',
    natural_alternatives: ['Clean groups first, complex ones later.', 'Let\'s prioritize the straightforward cases.'],
    common_mistakes: ['start with clean group (×, 缺s)'],
    usage_note: '建议分批处理策略。', work_context: '执行策略',
    scenario_id: 'sc-sop', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'semi-formal', replaceable_variables: ['clean groups', 'complex ones'],
    source_file: 'src-2', source_scenario: '分批策略', privacy_check_status: 'passed'
  },
  {
    id: 'ki-092', type: 'work_expression',
    english: 'The daily capacity is about 250 to 280 per cluster.',
    chinese: '每个集群每天的容量大约是250到280。',
    example_sentence: 'The daily capacity is about 250 to 280 per cluster, so we need to plan the timeline accordingly.',
    natural_alternatives: ['We can do 250-280 per cluster per day.', 'Each cluster handles roughly 250-280 daily.'],
    common_mistakes: ['capacity is about 250 to 280 per clusters (×)'],
    usage_note: '说明系统限制和产能。', work_context: '产能规划',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 4, frequency: 3, reusability: 4, communication_value: 4,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['250 to 280', 'per cluster'],
    source_file: 'src-2', source_scenario: '产能限制', privacy_check_status: 'passed'
  },
  {
    id: 'ki-093', type: 'work_expression',
    english: 'We need to define the person responsible for each city.',
    chinese: '我们需要确定每个城市的接口人。',
    example_sentence: 'We need to define the person responsible for each city to coordinate the rollout.',
    natural_alternatives: ['Each city needs a point of contact.', 'Let\'s assign a city lead for each region.'],
    common_mistakes: ['person responsible for each city (×, 正确)'],
    usage_note: '跨城市项目分配接口人。', work_context: '跨部门协作',
    scenario_id: 'sc-confirm', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'confirm_owner',
    formality: 'formal', replaceable_variables: ['each city', 'each region'],
    source_file: 'src-2', source_scenario: '接口人确定', privacy_check_status: 'passed'
  },
  {
    id: 'ki-094', type: 'work_expression',
    english: 'Can we get this confirmed by the end of the week?',
    chinese: '能在这周内确认吗？',
    example_sentence: 'Can we get this confirmed by the end of the week so we can start next Monday?',
    natural_alternatives: ['Can we lock this down by Friday?', 'Is a week enough to confirm?'],
    common_mistakes: ['get this confirm by (×, 用confirmed)'],
    usage_note: '催促确认时间节点。', work_context: '时间确认',
    scenario_id: 'sc-confirm', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'confirm_deadline',
    formality: 'semi-formal', replaceable_variables: ['the end of the week', 'Friday'],
    source_file: 'src-2', source_scenario: '确认时间', privacy_check_status: 'passed'
  },
  {
    id: 'ki-095', type: 'work_expression',
    english: 'The old group will be deprecated after 48 hours.',
    chinese: '旧群将在48小时后废弃。',
    example_sentence: 'The old group will be deprecated after 48 hours, and all new requests go to the new group.',
    natural_alternatives: ['The old group expires in 48 hours.', 'We\'ll retire the old group after 48 hours.'],
    common_mistakes: ['deprecated after 48 hour (×, 缺s)'],
    usage_note: '明确废弃时间线。', work_context: '项目计划',
    scenario_id: 'sc-confirm', difficulty: 2, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 4,
    skill_key: 'confirm_deadline',
    formality: 'formal', replaceable_variables: ['48 hours', '72 hours'],
    source_file: 'src-2', source_scenario: '废弃时间', privacy_check_status: 'passed'
  },
  {
    id: 'ki-096', type: 'work_expression',
    english: 'Historical records will still be accessible from the new group.',
    chinese: '历史记录仍可从新群中查看。',
    example_sentence: 'Historical records will still be accessible from the new group via a link to the old chat.',
    natural_alternatives: ['Users can still view old messages.', 'The chat history remains available.'],
    common_mistakes: ['accessible from new group (×, 缺the)'],
    usage_note: '说明数据迁移后的可访问性。', work_context: '数据迁移',
    scenario_id: 'sc-repair', difficulty: 2, work_relevance: 4, frequency: 3, reusability: 4, communication_value: 4,
    skill_key: 'explain_problems',
    formality: 'formal', replaceable_variables: ['the new group', 'the new channel'],
    source_file: 'src-2', source_scenario: '历史记录', privacy_check_status: 'passed'
  },
  {
    id: 'ki-097', type: 'work_expression',
    english: 'I have a concern about data consistency during the transition.',
    chinese: '我担心过渡期间的数据一致性。',
    example_sentence: 'I have a concern about data consistency during the transition, especially for duplicate entries.',
    natural_alternatives: ['I\'m worried about data integrity during the switch.', 'One thing to flag: data consistency in the overlap window.'],
    common_mistakes: ['concern about data (×, 可但建议加consistency)'],
    usage_note: '提出跨部门风险关注。', work_context: '风险管理',
    scenario_id: 'sc-reason', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'explain_problems',
    formality: 'formal', replaceable_variables: ['data consistency', 'data integrity'],
    source_file: 'src-2', source_scenario: '数据一致性风险', privacy_check_status: 'passed'
  },
  {
    id: 'ki-098', type: 'work_expression',
    english: 'Let\'s align on the rollout sequence and timeline.',
    chinese: '让我们对齐发布顺序和时间线。',
    example_sentence: 'Let\'s align on the rollout sequence and timeline before we start execution.',
    natural_alternatives: ['Let\'s agree on the order and schedule.', 'We should sync on the launch plan.'],
    common_mistakes: ['align on the rollout (×, 正确)'],
    usage_note: '跨部门对齐计划。', work_context: '跨部门协作',
    scenario_id: 'sc-confirm', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'confirm_deadline',
    formality: 'formal', replaceable_variables: ['rollout sequence', 'timeline'],
    source_file: 'src-2', source_scenario: '对齐计划', privacy_check_status: 'passed'
  },
  {
    id: 'ki-099', type: 'work_expression',
    english: 'We\'ll do a pilot in one city before rolling out to others.',
    chinese: '我们先在一个城市试点，再推广到其他城市。',
    example_sentence: 'We\'ll do a pilot in one city before rolling out to others, to validate the process.',
    natural_alternatives: ['Let\'s start with a single-city pilot.', 'We\'ll test in one market first, then scale.'],
    common_mistakes: ['pilot in one city before roll out (×, 用rolling out)'],
    usage_note: '提出试点策略。', work_context: '项目计划',
    scenario_id: 'sc-nextstep', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['one city', 'others'],
    source_file: 'src-2', source_scenario: '试点策略', privacy_check_status: 'passed'
  },
  {
    id: 'ki-100', type: 'work_expression',
    english: 'Let me summarize the decision and the action items.',
    chinese: '让我总结一下决策和待办事项。',
    example_sentence: 'Let me summarize the decision and the action items before we wrap up.',
    natural_alternatives: ['To recap, here are the decisions and next steps.', 'Let\'s summarize what we agreed on and who does what.'],
    common_mistakes: ['summarize the decision and action item (×, 缺s)'],
    usage_note: '会议结尾总结决策和待办。', work_context: '会议总结',
    scenario_id: 'sc-reporting', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'give_updates',
    formality: 'formal', replaceable_variables: ['the decision', 'the action items'],
    source_file: 'src-2', source_scenario: '会议总结', privacy_check_status: 'passed'
  },

  // === Module 3: 方案与风险决策 (20 items: ki-101 ~ ki-120) ===
  // Source: src-3 (空冰洗兜底服务方案讨论)
  {
    id: 'ki-101', type: 'work_expression',
    english: 'I understand the request, but the team does not have the capacity to take on another manual step.',
    chinese: '我理解需求，但团队没有余力再增加手动步骤。',
    example_sentence: 'I understand the request, but the team does not have the capacity to take on another manual step right now.',
    natural_alternatives: ['I see the need, but we can\'t absorb more manual work.', 'We don\'t have the bandwidth for additional steps.'],
    common_mistakes: ['does not have capacity to take (×, 缺the)'],
    usage_note: '专业拒绝额外工作量。', work_context: '跨部门讨论',
    scenario_id: 'sc-request-help', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'answer_followups',
    formality: 'formal', replaceable_variables: ['another manual step', 'additional work'],
    source_file: 'src-3', source_scenario: '工作量限制', privacy_check_status: 'passed'
  },
  {
    id: 'ki-102', type: 'work_expression',
    english: 'As a temporary workaround, we can use the existing notification tool.',
    chinese: '作为临时方案，我们可以用现有的通知工具。',
    example_sentence: 'As a temporary workaround, we can use the existing notification tool until the new feature is ready.',
    natural_alternatives: ['For now, we can leverage what we already have.', 'As a stopgap, the current tool works.'],
    common_mistakes: ['as temporary workaround (×, 缺a)'],
    usage_note: '提出过渡方案。', work_context: '兜底方案',
    scenario_id: 'sc-fallback', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'semi-formal', replaceable_variables: ['existing notification tool', 'current system'],
    source_file: 'src-3', source_scenario: '临时方案', privacy_check_status: 'passed'
  },
  {
    id: 'ki-103', type: 'work_expression',
    english: 'Option A has less customer impact, but it does not solve the underlying problem.',
    chinese: '方案A对客户影响较小，但不能解决根本问题。',
    example_sentence: 'Option A has less customer impact, but it does not solve the underlying problem of data inconsistency.',
    natural_alternatives: ['Option A is safer for users, but it\'s a band-aid.', 'Less disruption, but the root cause remains.'],
    common_mistakes: ['less customer impact (×, 缺a可但建议加the)'],
    usage_note: '方案对比时权衡利弊。', work_context: '方案比较',
    scenario_id: 'sc-nextstep', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['customer impact', 'underlying problem'],
    source_file: 'src-3', source_scenario: '方案比较', privacy_check_status: 'passed'
  },
  {
    id: 'ki-104', type: 'work_expression',
    english: 'Before we roll this out, we need to assess the reporting impact.',
    chinese: '推广之前需要评估对报表的影响。',
    example_sentence: 'Before we roll this out, we need to assess the reporting impact and align with the BI team.',
    natural_alternatives: ['Before launch, we should evaluate the dashboard implications.', 'We need an impact assessment before deployment.'],
    common_mistakes: ['Before roll this out (×, 用rolling/we roll)'],
    usage_note: '推广前的评估要求。', work_context: '风险管理',
    scenario_id: 'sc-sop', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'confirm_owner',
    formality: 'formal', replaceable_variables: ['reporting impact', 'data impact'],
    source_file: 'src-3', source_scenario: '推广前评估', privacy_check_status: 'passed'
  },
  {
    id: 'ki-105', type: 'work_expression',
    english: 'The earliest we can ship this feature is early October.',
    chinese: '最早能在十月初上线这个功能。',
    example_sentence: 'The earliest we can ship this feature is early October, given the holiday and code freeze.',
    natural_alternatives: ['Best case, this goes live in early October.', 'The soonest is October, post-holiday.'],
    common_mistakes: ['earliest we can ship is (×, 缺The)'],
    usage_note: '给出功能上线预期。', work_context: '时间承诺',
    scenario_id: 'sc-confirm', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'confirm_deadline',
    formality: 'semi-formal', replaceable_variables: ['early October', 'end of September'],
    source_file: 'src-3', source_scenario: '上线时间', privacy_check_status: 'passed'
  },
  {
    id: 'ki-106', type: 'work_expression',
    english: 'We need to standardize the SOP before expanding to other cities.',
    chinese: '推广到其他城市前需要先标准化SOP。',
    example_sentence: 'We need to standardize the SOP before expanding to other cities.',
    natural_alternatives: ['Let\'s formalize the process before scaling.', 'We should lock down the SOP before rolling out.'],
    common_mistakes: ['standardize the SOP before expand (×, 用expanding)'],
    usage_note: '强调标准化先于扩展。', work_context: '流程管理',
    scenario_id: 'sc-sop', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'explain_sop',
    formality: 'formal', replaceable_variables: ['other cities', 'other regions'],
    source_file: 'src-3', source_scenario: 'SOP标准化', privacy_check_status: 'passed'
  },
  {
    id: 'ki-107', type: 'work_expression',
    english: 'We need to give the service team more authority to resolve issues.',
    chinese: '我们需要给服务团队更多授权来解决问题。',
    example_sentence: 'We need to give the service team more authority to resolve issues without waiting for approval.',
    natural_alternatives: ['We should empower the front line.', 'The team needs more decision-making power.'],
    common_mistakes: ['give the team more authority resolve (×, 缺to)'],
    usage_note: '提出授权需求。', work_context: '授权方案',
    scenario_id: 'sc-fallback', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['service team', 'more authority'],
    source_file: 'src-3', source_scenario: '授权需求', privacy_check_status: 'passed'
  },
  {
    id: 'ki-108', type: 'work_expression',
    english: 'If the asset manager doesn\'t respond within 6 hours, we proceed with the fallback.',
    chinese: '如果资管6小时内未回复，我们走兜底方案。',
    example_sentence: 'If the asset manager doesn\'t respond within 6 hours, we proceed with the fallback and replace the unit.',
    natural_alternatives: ['After 6 hours of no response, we go with the backup plan.', 'If no reply in 6 hours, we escalate to the fallback.'],
    common_mistakes: ['doesn\'t respond within 6 hour (×, 缺s)'],
    usage_note: '明确兜底触发条件。', work_context: '兜底方案',
    scenario_id: 'sc-fallback', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['6 hours', 'the fallback'],
    source_file: 'src-3', source_scenario: '兜底触发', privacy_check_status: 'passed'
  },
  {
    id: 'ki-109', type: 'work_expression',
    english: 'We should send a second notification before escalating.',
    chinese: '升级前应发送二次提醒。',
    example_sentence: 'We should send a second notification before escalating to the regional manager.',
    natural_alternatives: ['Let\'s try a second reminder before escalating.', 'A follow-up alert should go out before escalation.'],
    common_mistakes: ['second notification before escalate (×, 用escalating)'],
    usage_note: '建议升级前二次触达。', work_context: '升级流程',
    scenario_id: 'sc-sop', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'formal', replaceable_variables: ['second notification', 'escalating'],
    source_file: 'src-3', source_scenario: '二次触达', privacy_check_status: 'passed'
  },
  {
    id: 'ki-110', type: 'work_expression',
    english: 'The escalation path should go to the regional manager.',
    chinese: '升级路径应该到区域经理。',
    example_sentence: 'The escalation path should go to the regional manager if there\'s no response within the SLA.',
    natural_alternatives: ['Escalation should reach the district manager.', 'It should escalate to the area lead.'],
    common_mistakes: ['escalation path should go to regional (×, 缺manager)'],
    usage_note: '定义升级路径。', work_context: '升级流程',
    scenario_id: 'sc-sop', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 5,
    skill_key: 'confirm_owner',
    formality: 'formal', replaceable_variables: ['regional manager', 'district lead'],
    source_file: 'src-3', source_scenario: '升级路径', privacy_check_status: 'passed'
  },
  {
    id: 'ki-111', type: 'work_expression',
    english: 'We need to ensure the team is not overburdened during the transition.',
    chinese: '我们需要确保团队在过渡期间不被过度加压。',
    example_sentence: 'We need to ensure the team is not overburdened during the transition to the new process.',
    natural_alternatives: ['We can\'t overload the team during the switch.', 'Team capacity needs to be protected during rollout.'],
    common_mistakes: ['not overburden during (×, 正确但加the team更好)'],
    usage_note: '关注团队承载力。', work_context: '团队管理',
    scenario_id: 'sc-reason', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'explain_problems',
    formality: 'formal', replaceable_variables: ['overburdened', 'the transition'],
    source_file: 'src-3', source_scenario: '团队压力', privacy_check_status: 'passed'
  },
  {
    id: 'ki-112', type: 'work_expression',
    english: 'This only applies to the three product categories: AC, fridge, and washer.',
    chinese: '这仅适用于空调、冰箱和洗衣机三个品类。',
    example_sentence: 'This only applies to the three product categories: AC, fridge, and washer.',
    natural_alternatives: ['This is limited to ACs, fridges, and washers.', 'It covers only the three major appliance categories.'],
    common_mistakes: ['three product category (×, 缺s)'],
    usage_note: '限定方案适用范围。', work_context: '方案范围',
    scenario_id: 'sc-sop', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 4, communication_value: 4,
    skill_key: 'explain_sop',
    formality: 'formal', replaceable_variables: ['three product categories', 'AC, fridge, and washer'],
    source_file: 'src-3', source_scenario: '适用范围', privacy_check_status: 'passed'
  },
  {
    id: 'ki-113', type: 'work_expression',
    english: 'For amounts under 100 yuan, we can proceed without manager approval.',
    chinese: '100元以下的费用可以直接处理，不需要经理审批。',
    example_sentence: 'For amounts under 100 yuan, we can proceed without manager approval to speed up resolution.',
    natural_alternatives: ['Below 100 yuan, no approval needed.', 'Sub-100-yuan cases skip the approval step.'],
    common_mistakes: ['under 100 yuan, we can proceed without (×, 可但建议加manager approval)'],
    usage_note: '明确授权门槛。', work_context: '授权方案',
    scenario_id: 'sc-fallback', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 4, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'semi-formal', replaceable_variables: ['100 yuan', 'manager approval'],
    source_file: 'src-3', source_scenario: '授权门槛', privacy_check_status: 'passed'
  },
  {
    id: 'ki-114', type: 'work_expression',
    english: 'We need to see the data before making a decision.',
    chinese: '我们需要先看数据再做决策。',
    example_sentence: 'We need to see the data before making a decision on expanding to new categories.',
    natural_alternatives: ['Let\'s look at the numbers first.', 'Data first, then we decide.'],
    common_mistakes: ['before make a decision (×, 用making)'],
    usage_note: '要求数据支撑决策。', work_context: '决策支撑',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'semi-formal', replaceable_variables: ['the data', 'a decision'],
    source_file: 'src-3', source_scenario: '数据先行', privacy_check_status: 'passed'
  },
  {
    id: 'ki-115', type: 'work_expression',
    english: 'Nighttime hours should be excluded from the SLA calculation.',
    chinese: '夜间时段应从SLA计算中排除。',
    example_sentence: 'Nighttime hours should be excluded from the SLA calculation, from 10 PM to 10 AM.',
    natural_alternatives: ['Off-hours don\'t count toward the SLA.', 'The clock pauses outside business hours.'],
    common_mistakes: ['excluded from SLA calculation (×, 缺the)'],
    usage_note: 'SLA计算规则说明。', work_context: 'SLA管理',
    scenario_id: 'sc-sop', difficulty: 3, work_relevance: 5, frequency: 3, reusability: 4, communication_value: 5,
    skill_key: 'explain_sop',
    formality: 'formal', replaceable_variables: ['SLA calculation', '10 PM to 10 AM'],
    source_file: 'src-3', source_scenario: 'SLA时段排除', privacy_check_status: 'passed'
  },
  {
    id: 'ki-116', type: 'work_expression',
    english: 'We\'ll start the rollout on Wednesday after the city briefing on Monday.',
    chinese: '周一周二宣导后，周三开始落地。',
    example_sentence: 'We\'ll start the rollout on Wednesday after the city briefing on Monday and Tuesday.',
    natural_alternatives: ['Rollout begins Wednesday, post-briefing.', 'We launch Wednesday following the Monday announcement.'],
    common_mistakes: ['start the rollout in Wednesday (×, 用on)'],
    usage_note: '发布时间线。', work_context: '项目计划',
    scenario_id: 'sc-confirm', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'confirm_deadline',
    formality: 'formal', replaceable_variables: ['Wednesday', 'Monday'],
    source_file: 'src-3', source_scenario: '发布节奏', privacy_check_status: 'passed'
  },
  {
    id: 'ki-117', type: 'work_expression',
    english: 'The supplier should report back within 4 hours of sign-in.',
    chinese: '供应商应在签到后4小时内反馈。',
    example_sentence: 'The supplier should report back within 4 hours of sign-in with a resolution or update.',
    natural_alternatives: ['Suppliers have a 4-hour reporting window after sign-in.', 'Feedback is due within 4 hours of on-site arrival.'],
    common_mistakes: ['report back within 4 hour (×, 缺s)'],
    usage_note: '供应商时效要求。', work_context: '供应商管理',
    scenario_id: 'sc-sop', difficulty: 2, work_relevance: 5, frequency: 4, reusability: 4, communication_value: 4,
    skill_key: 'confirm_deadline',
    formality: 'formal', replaceable_variables: ['4 hours', 'sign-in'],
    source_file: 'src-3', source_scenario: '供应商时效', privacy_check_status: 'passed'
  },
  {
    id: 'ki-118', type: 'work_expression',
    english: 'We need to monitor compliance and flag exceptions.',
    chinese: '我们需要监控合规性并标记异常。',
    example_sentence: 'We need to monitor compliance and flag exceptions for cases that exceed the 4-hour window.',
    natural_alternatives: ['Let\'s track adherence and flag outliers.', 'We should watch compliance and raise alerts.'],
    common_mistakes: ['flag exception (×, 缺s)'],
    usage_note: '强调监控和异常标记。', work_context: '数据监控',
    scenario_id: 'sc-sop', difficulty: 3, work_relevance: 5, frequency: 4, reusability: 5, communication_value: 5,
    skill_key: 'report_data',
    formality: 'formal', replaceable_variables: ['compliance', 'exceptions'],
    source_file: 'src-3', source_scenario: '监控合规', privacy_check_status: 'passed'
  },
  {
    id: 'ki-119', type: 'work_expression',
    english: 'The new feature is expected to go live around September 17th.',
    chinese: '新功能预计在9月17日左右上线。',
    example_sentence: 'The new feature is expected to go live around September 17th, pending the final release schedule.',
    natural_alternatives: ['We\'re targeting September 17th for launch.', 'The feature should be live by mid-September.'],
    common_mistakes: ['expected to go live around September 17 (×, 正确)'],
    usage_note: '功能上线预期。', work_context: '时间承诺',
    scenario_id: 'sc-confirm', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'confirm_deadline',
    formality: 'semi-formal', replaceable_variables: ['September 17th', 'mid-September'],
    source_file: 'src-3', source_scenario: '功能上线', privacy_check_status: 'passed'
  },
  {
    id: 'ki-120', type: 'work_expression',
    english: 'Let\'s review the data after one week before expanding.',
    chinese: '推广前先跑一周看数据。',
    example_sentence: 'Let\'s review the data after one week before expanding to other cities.',
    natural_alternatives: ['Let\'s run it for a week and check the numbers.', 'One week of data, then we decide on expansion.'],
    common_mistakes: ['after one week before expand (×, 用expanding)'],
    usage_note: '用数据驱动扩展决策。', work_context: '决策支撑',
    scenario_id: 'sc-data', difficulty: 2, work_relevance: 5, frequency: 5, reusability: 5, communication_value: 5,
    skill_key: 'suggest_next',
    formality: 'semi-formal', replaceable_variables: ['one week', 'expanding'],
    source_file: 'src-3', source_scenario: '数据驱动扩展', privacy_check_status: 'passed'
  }
];

// ===== V2 New/Updated Daily Lessons (Days 29-84) =====
// Extends original 28 days to 12 weeks (84 days), 5 study days + 1 test + 1 rest per week
const V2_DAILY_LESSONS_EXT = [
  // Week 5 (Days 29-35): 工单指标与复盘
  {
    day: 29, week: 5, theme: '指标口径与计算方式', theme_en: 'Metric Definitions',
    itemIds: ['ki-051', 'ki-052', 'ki-053', 'ki-058', 'ki-059'],
    patternIds: ['ki-051'],
    listening: {
      title: 'Listening: Metric Calculation',
      text: 'Let me clarify how this metric is calculated. The consultation rate is measured per 10,000 managed units. The criteria for closing tickets have changed, so the current figure is not directly comparable with last year\'s number. We need a comparable baseline before setting the target.',
      keywords: ['metric', 'calculated', 'comparable baseline', 'criteria', 'changed'],
      comprehension_questions: [
        { q: 'How is the consultation rate measured?', a: 'Per 10,000 managed units.', options: ['Per 100 units', 'Per 10,000 managed units', 'Per city', 'Per ticket'] },
        { q: 'Why is the current figure not comparable with last year?', a: 'Because the closing criteria have changed.', options: ['Because the data was lost', 'Because the criteria changed', 'Because the cities changed', 'Because the team changed'] },
        { q: 'What do they need before setting a target?', a: 'A comparable baseline.', options: ['More staff', 'A comparable baseline', 'New software', 'Owner approval'] }
      ]
    },
    workPractice: {
      context: '领导问你为什么今年的咨询率和去年不可比。你需要解释指标口径变化。',
      task: '用英语解释为什么数据不可直接比较。',
      hints: ['let me clarify how', 'not directly comparable', 'criteria have changed'],
      reference: 'Let me clarify how this metric is calculated. The criteria for closing tickets have changed, so the current figure is not directly comparable with last year\'s number. We need a comparable baseline before setting the target.',
      followUps: [
        'So what baseline should we use then?',
        'Can you break this down by scenario?'
      ]
    },
    challenge: { prompt: '用45秒解释一个指标口径变化的影响。' }
  },
  {
    day: 30, week: 5, theme: '目标设定与基准值', theme_en: 'Target Setting & Baselines',
    itemIds: ['ki-055', 'ki-056', 'ki-057', 'ki-069', 'ki-070'],
    patternIds: ['ki-057'],
    listening: {
      title: 'Listening: Setting Targets',
      text: 'Let\'s use May\'s value as the baseline. The target for August is set at 120 per 10,000 units. We aim to reduce this by 30% compared to the same period last year. We should anchor the target and work backwards. This metric is hard to set because the baseline keeps shifting.',
      keywords: ['baseline', 'May\'s value', 'target', 'August', '120', 'reduce by 30%'],
      comprehension_questions: [
        { q: 'What is the August target?', a: '120 per 10,000 units.', options: ['100', '120 per 10,000 units', '150', '200'] },
        { q: 'How much do they aim to reduce?', a: 'By 30% compared to the same period last year.', options: ['10%', '20%', '30%', '50%'] },
        { q: 'Why is the metric hard to set?', a: 'Because the baseline keeps shifting.', options: ['Because the team is too small', 'Because the baseline keeps shifting', 'Because the software is broken', 'Because the owners refuse'] }
      ]
    },
    workPractice: {
      context: '你需要设定八月份的咨询率目标，基准用五月份的数据，目标同比降30%。',
      task: '用英语汇报目标设定方案。',
      hints: ['use May\'s value as the baseline', 'the target for August is set at', 'aim to reduce by 30%'],
      reference: 'Let\'s use May\'s value as the baseline. The target for August is set at 120 per 10,000 units. We aim to reduce this by 30% compared to the same period last year.',
      followUps: [
        'Why did you choose May as the baseline instead of June?',
        'What actions will drive this reduction?'
      ]
    },
    challenge: { prompt: '用45秒说明一个目标是怎么定的，包括基准和降幅。' }
  },
  {
    day: 31, week: 5, theme: '数据拆分与场景分析', theme_en: 'Breaking Down Data',
    itemIds: ['ki-054', 'ki-067', 'ki-074', 'ki-072', 'ki-068'],
    patternIds: ['ki-054'],
    listening: {
      title: 'Listening: Data Breakdown',
      text: 'Could we break this down by scenario? The three-day resolution rate is currently at 6.5%. Let\'s categorize these by resolution path. We should separate new contracts from existing ones. The overall trend shows improvement, but we still have gaps.',
      keywords: ['break down', 'scenario', 'three-day resolution rate', '6.5%', 'categorize', 'resolution path'],
      comprehension_questions: [
        { q: 'What is the current three-day resolution rate?', a: '6.5%.', options: ['5%', '6.5%', '10%', '15%'] },
        { q: 'What does the speaker want to separate?', a: 'New contracts from existing ones.', options: ['Cities from regions', 'New contracts from existing ones', 'Costs from revenue', 'Managers from staff'] },
        { q: 'What does the overall trend show?', a: 'Improvement, but with gaps.', options: ['Decline everywhere', 'Improvement, but with gaps', 'No change', 'Complete success'] }
      ]
    },
    workPractice: {
      context: '汇报三日解决率6.5%，需要按场景拆分分析。',
      task: '用英语请求按场景拆分数据并说明趋势。',
      hints: ['could we break this down by scenario', 'the three-day resolution rate is currently at', 'the overall trend shows improvement'],
      reference: 'Could we break this down by scenario? The three-day resolution rate is currently at 6.5%. The overall trend shows improvement, but we still have gaps. We should separate new contracts from existing ones.',
      followUps: [
        'Which scenario has the worst resolution rate?',
        'How do the new contracts compare to existing ones?'
      ]
    },
    challenge: { prompt: '用45秒请求拆分一组数据并说明趋势。' }
  },
  {
    day: 32, week: 5, theme: '费用归属与复盘', theme_en: 'Cost Allocation Review',
    itemIds: ['ki-061', 'ki-062', 'ki-063', 'ki-064', 'ki-075'],
    patternIds: ['ki-061'],
    listening: {
      title: 'Listening: Cost Review',
      text: 'Let me break down the cost allocation. In terms of cost responsibility, the asset manager covered 5 cases and the owner covered 10. The owner\'s share of the cost was 55%. We need to separate cases where no cost was incurred. The key takeaway from this review is that direct owner contact leads to faster resolution.',
      keywords: ['cost allocation', 'asset manager', 'owner', '55%', 'no cost', 'direct owner contact'],
      comprehension_questions: [
        { q: 'How many cases did the asset manager cover?', a: '5 cases.', options: ['3', '5', '10', '15'] },
        { q: 'What was the owner\'s share of the cost?', a: '55%.', options: ['40%', '45%', '50%', '55%'] },
        { q: 'What is the key takeaway from the review?', a: 'Direct owner contact leads to faster resolution.', options: ['The asset manager should handle everything', 'Direct owner contact leads to faster resolution', 'Costs are too high', 'No costs were incurred'] }
      ]
    },
    workPractice: {
      context: '复盘本周费用：资管承担5单，业主承担10单，业主占比55%，另有3单无费用。',
      task: '用英语汇报费用拆分和复盘结论。',
      hints: ['break down the cost allocation', 'in terms of cost responsibility', 'the key takeaway from this review is'],
      reference: 'Let me break down the cost allocation. In terms of cost responsibility, the asset manager covered 5 cases and the owner covered 10. The owner\'s share was 55%. The key takeaway from this review is that direct owner contact leads to faster resolution.',
      followUps: [
        'Why is direct contact faster than going through the asset manager?',
        'Should we change the process to always contact owners directly?'
      ]
    },
    challenge: { prompt: '用60秒做一次费用复盘汇报，包括拆分和结论。' }
  },
  {
    day: 33, week: 5, theme: '多层转达与时效分析', theme_en: 'Response Time & Layers',
    itemIds: ['ki-065', 'ki-066', 'ki-067', 'ki-073', 'ki-071'],
    patternIds: ['ki-066'],
    listening: {
      title: 'Listening: Response Time Analysis',
      text: 'We found that direct owner contact leads to faster resolution. The response time is longer when it goes through multiple layers. Let\'s categorize these by resolution path. Let\'s do a deep dive into the outliers. We need to track this on a weekly basis.',
      keywords: ['direct owner contact', 'faster', 'multiple layers', 'outliers', 'weekly basis'],
      comprehension_questions: [
        { q: 'What leads to faster resolution?', a: 'Direct owner contact.', options: ['Going through the asset manager', 'Direct owner contact', 'Sending an email', 'Waiting 48 hours'] },
        { q: 'When is the response time longer?', a: 'When it goes through multiple layers.', options: ['When the owner is away', 'When it goes through multiple layers', 'On weekends', 'In the morning'] },
        { q: 'How often should they track this?', a: 'On a weekly basis.', options: ['Daily', 'Weekly', 'Monthly', 'Quarterly'] }
      ]
    },
    workPractice: {
      context: '分析发现经过资管转达的工单比直接联系业主的慢。需要汇报这个发现。',
      task: '用英语汇报分析发现和建议。',
      hints: ['we found that direct owner contact', 'response time is longer when', 'let\'s categorize these by'],
      reference: 'We found that direct owner contact leads to faster resolution. The response time is longer when it goes through multiple layers. Let\'s categorize these by resolution path so we can identify bottlenecks.',
      followUps: [
        'Should we always go directly to the owner then?',
        'What about cases where the asset manager needs to be involved?'
      ]
    },
    challenge: { prompt: '用45秒汇报一个关于时效的分析发现。' }
  },
  {
    day: 34, week: 5, theme: '本周复习与周测', theme_en: 'Week 5 Review & Test',
    itemIds: ['ki-051', 'ki-055', 'ki-061', 'ki-065', 'ki-068', 'ki-075'],
    patternIds: ['ki-051', 'ki-075'],
    listening: {
      title: 'Listening: Week 5 Review',
      text: 'Let me clarify how this metric is calculated. Let\'s use May\'s value as the baseline. The target for August is set at 120. Let me break down the cost allocation. We found that direct owner contact leads to faster resolution. The three-day resolution rate is currently at 6.5%. The key takeaway from this review is that direct contact is faster.',
      keywords: ['metric', 'baseline', 'May', 'target', '120', 'cost allocation', 'direct contact', '6.5%'],
      comprehension_questions: [
        { q: 'What is used as the baseline?', a: 'May\'s value.', options: ['April', 'May', 'June', 'July'] },
        { q: 'What is the August target?', a: '120 per 10,000 units.', options: ['100', '110', '120', '130'] },
        { q: 'What is the key takeaway?', a: 'Direct contact is faster.', options: ['The target is too high', 'Direct contact is faster', 'Costs are increasing', 'The metric is wrong'] }
      ]
    },
    workPractice: {
      context: '综合复习：需要汇报指标口径、基准设定、费用拆分和复盘结论。',
      task: '用英语完成2分钟的指标与复盘综合汇报。',
      hints: ['let me clarify how', 'use May\'s value as the baseline', 'break down the cost allocation', 'the key takeaway'],
      reference: 'Let me clarify how this metric is calculated. We\'ll use May\'s value as the baseline. The target for August is set at 120. Let me break down the cost allocation. The key takeaway from this review is that direct owner contact leads to faster resolution.',
      followUps: [
        'Can you walk me through the cost breakdown in more detail?',
        'What\'s your plan to increase direct owner contact?'
      ]
    },
    challenge: { prompt: '用90秒完成指标→基准→费用→结论的综合汇报。' }
  },
  {
    day: 35, week: 5, theme: '休息或补课', theme_en: 'Rest or Catch-up',
    itemIds: [], patternIds: [],
    listening: { title: 'Rest Day', text: '', keywords: [], comprehension_questions: [] },
    workPractice: { context: '休息日', task: '休息或回顾本周内容。', hints: [], reference: '', followUps: [] },
    challenge: { prompt: '休息日' }
  },
  // Week 6 (Days 36-42): 跨部门讨论 — 群继承项目
  {
    day: 36, week: 6, theme: '项目背景与进度汇报', theme_en: 'Project Background & Progress',
    itemIds: ['ki-076', 'ki-077', 'ki-078', 'ki-079', 'ki-093'],
    patternIds: ['ki-076'],
    listening: {
      title: 'Listening: Project Update',
      text: 'Let me give you some background on this project. We have 186 out of 219 completed, with 33 remaining. The migration failed for 98,000 groups. The root cause is that the accounts were not reauthorized within the year. We need to define the person responsible for each city.',
      keywords: ['background', '186', '219', '33 remaining', 'migration failed', '98,000', 'root cause', 'reauthorized'],
      comprehension_questions: [
        { q: 'How many are completed out of 219?', a: '186.', options: ['150', '186', '200', '219'] },
        { q: 'Why did the migration fail?', a: 'Accounts were not reauthorized within the year.', options: ['The system crashed', 'Accounts were not reauthorized', 'The network was down', 'The team was too small'] },
        { q: 'What do they need to define for each city?', a: 'A person responsible.', options: ['A budget', 'A person responsible', 'A new tool', 'A timeline'] }
      ]
    },
    workPractice: {
      context: '项目进度：219个任务完成186个，剩余33个。98000个迁移失败，原因是账号未重新授权。',
      task: '用英语汇报项目进度和失败原因。',
      hints: ['let me give you some background', '186 out of 219 completed', 'the root cause is that'],
      reference: 'Let me give you some background on this project. We have 186 out of 219 completed, with 33 remaining. The migration failed for 98,000 groups. The root cause is that the accounts were not reauthorized within the year.',
      followUps: [
        'What\'s your plan for the 98,000 failed cases?',
        'Can we fix the authorization issue and retry?'
      ]
    },
    challenge: { prompt: '用60秒汇报一个项目的进度和遇到的问题。' }
  },
  {
    day: 37, week: 6, theme: '方案比较与风险识别', theme_en: 'Comparing Options & Risks',
    itemIds: ['ki-080', 'ki-081', 'ki-082', 'ki-084', 'ki-089'],
    patternIds: ['ki-080'],
    listening: {
      title: 'Listening: Options & Risks',
      text: 'Option A is to maintain the status quo, but the impact is that the team needs manual workarounds. Option B is to create new groups, but the trade-off is that customers will see two groups temporarily. We need to design a communication plan for the customers. There\'s a risk that customers continue using the old channel. If this doesn\'t work, we\'ll fall back to the original plan.',
      keywords: ['Option A', 'status quo', 'Option B', 'create new groups', 'trade-off', 'communication plan', 'risk', 'old channel', 'fall back'],
      comprehension_questions: [
        { q: 'What is the impact of Option A?', a: 'The team needs manual workarounds.', options: ['No impact', 'Manual workarounds needed', 'Customers leave', 'Data is lost'] },
        { q: 'What is the trade-off of Option B?', a: 'Customers will see two groups temporarily.', options: ['Lower cost', 'Customers see two groups', 'Faster resolution', 'No risk'] },
        { q: 'What risk did they identify?', a: 'Customers might continue using the old channel.', options: ['System failure', 'Customers using old channel', 'Budget overrun', 'Team burnout'] }
      ]
    },
    workPractice: {
      context: '群继承项目需要选择方案。方案A保持现状但需手动操作，方案B建新群但客户会看到两个群。',
      task: '用英语比较两个方案并指出风险。',
      hints: ['Option A is to maintain', 'Option B is to create', 'there\'s a risk that'],
      reference: 'Option A is to maintain the status quo, but the impact is that the team needs manual workarounds. Option B is to create new groups, but the trade-off is that customers will see two groups temporarily. There\'s a risk that customers continue using the old channel.',
      followUps: [
        'Which option do you recommend?',
        'How do we mitigate the risk of customers using the old channel?'
      ]
    },
    challenge: { prompt: '用60秒比较两个方案并识别风险。' }
  },
  {
    day: 38, week: 6, theme: '跨部门协作与BI影响', theme_en: 'Cross-Team & BI Impact',
    itemIds: ['ki-086', 'ki-087', 'ki-088', 'ki-097', 'ki-092'],
    patternIds: ['ki-086'],
    listening: {
      title: 'Listening: BI Impact',
      text: 'The BI team needs to assess the reporting impact. The data extraction logic will change because one contract now maps to two groups. Can we explore whether the platform supports ownership transfer? I have a concern about data consistency during the transition. The daily capacity is about 250 to 280 per cluster.',
      keywords: ['BI team', 'reporting impact', 'data extraction logic', 'one contract', 'two groups', 'ownership transfer', 'data consistency', 'capacity', '250 to 280'],
      comprehension_questions: [
        { q: 'Who needs to assess the reporting impact?', a: 'The BI team.', options: ['The dev team', 'The BI team', 'The product team', 'The city team'] },
        { q: 'Why will the data extraction logic change?', a: 'Because one contract now maps to two groups.', options: ['New software', 'One contract maps to two groups', 'More staff needed', 'New management'] },
        { q: 'What concern did the speaker raise?', a: 'Data consistency during the transition.', options: ['Budget', 'Data consistency', 'Timeline', 'Staffing'] }
      ]
    },
    workPractice: {
      context: '群继承项目变更了数据结构，一个合同现在对应两个群。需要请BI评估报表影响。',
      task: '用英语说明数据影响并请BI评估。',
      hints: ['the BI team needs to assess', 'the data extraction logic will change', 'I have a concern about data consistency'],
      reference: 'The BI team needs to assess the reporting impact. The data extraction logic will change because one contract now maps to two groups. I have a concern about data consistency during the transition.',
      followUps: [
        'What specific reports will be affected?',
        'How long will the BI assessment take?'
      ]
    },
    challenge: { prompt: '用45秒说明一个数据变更的跨部门影响。' }
  },
  {
    day: 39, week: 6, theme: '过渡管理与客户沟通', theme_en: 'Transition & Customer Comms',
    itemIds: ['ki-082', 'ki-083', 'ki-084', 'ki-095', 'ki-096'],
    patternIds: ['ki-083'],
    listening: {
      title: 'Listening: Transition Management',
      text: 'We need to design a communication plan for the customers. The transition period should be kept as short as possible. There\'s a risk that customers continue using the old channel. The old group will be deprecated after 48 hours. Historical records will still be accessible from the new group.',
      keywords: ['communication plan', 'transition period', 'short', 'risk', 'old channel', 'deprecated', '48 hours', 'historical records'],
      comprehension_questions: [
        { q: 'What do they need to design?', a: 'A communication plan for customers.', options: ['A new product', 'A communication plan', 'A budget', 'A training program'] },
        { q: 'When will the old group be deprecated?', a: 'After 48 hours.', options: ['24 hours', '48 hours', '72 hours', 'One week'] },
        { q: 'Will historical records be accessible?', a: 'Yes, from the new group.', options: ['No, they\'re lost', 'Yes, from the new group', 'Only from the old group', 'Only on desktop'] }
      ]
    },
    workPractice: {
      context: '新群创建后48小时废弃旧群。需要设计客户沟通方案，确保过渡期尽量短。',
      task: '用英语说明过渡管理方案。',
      hints: ['design a communication plan', 'transition period should be kept as short as possible', 'old group will be deprecated after 48 hours'],
      reference: 'We need to design a communication plan for the customers. The transition period should be kept as short as possible. The old group will be deprecated after 48 hours. Historical records will still be accessible from the new group.',
      followUps: [
        'What message should we send to customers?',
        'What if a customer sends a message to the old group after deprecation?'
      ]
    },
    challenge: { prompt: '用45秒说明一个过渡管理方案。' }
  },
  {
    day: 40, week: 6, theme: '执行策略与分批处理', theme_en: 'Execution & Batching',
    itemIds: ['ki-085', 'ki-090', 'ki-091', 'ki-092', 'ki-099'],
    patternIds: ['ki-091'],
    listening: {
      title: 'Listening: Execution Plan',
      text: 'We should skip cases with pending tickets and retry the next day. We should clean up invalid tickets during this migration. Let\'s start with clean groups first, then handle the complex ones. The daily capacity is about 250 to 280 per cluster. We\'ll do a pilot in one city before rolling out to others.',
      keywords: ['skip', 'pending tickets', 'retry', 'clean up', 'invalid tickets', 'clean groups first', 'capacity', '250 to 280', 'pilot'],
      comprehension_questions: [
        { q: 'What should they do with pending ticket cases?', a: 'Skip them and retry the next day.', options: ['Cancel them', 'Skip and retry next day', 'Process immediately', 'Ignore them'] },
        { q: 'Which groups should they start with?', a: 'Clean groups first.', options: ['Complex ones', 'Clean groups', 'Large ones', 'Random order'] },
        { q: 'What is the daily capacity per cluster?', a: 'About 250 to 280.', options: ['100-150', '200-250', '250-280', '300-350'] }
      ]
    },
    workPractice: {
      context: '群迁移需要分批执行。先处理干净群，跳过有在途工单的。每天每个集群250-280个。',
      task: '用英语说明执行策略。',
      hints: ['skip cases with pending tickets', 'start with clean groups first', 'daily capacity is about 250 to 280'],
      reference: 'Let\'s start with clean groups first, then handle the complex ones. We should skip cases with pending tickets and retry the next day. The daily capacity is about 250 to 280 per cluster. We\'ll do a pilot in one city before rolling out to others.',
      followUps: [
        'How long will the full migration take?',
        'What happens if a clean group fails?'
      ]
    },
    challenge: { prompt: '用45秒说明一个分批执行策略。' }
  },
  {
    day: 41, week: 6, theme: '本周复习与周测', theme_en: 'Week 6 Review & Test',
    itemIds: ['ki-076', 'ki-080', 'ki-086', 'ki-083', 'ki-091', 'ki-100'],
    patternIds: ['ki-080', 'ki-100'],
    listening: {
      title: 'Listening: Week 6 Review',
      text: 'Let me give you some background on this project. Option A is to maintain the status quo, but the impact is manual workarounds. Option B is to create new groups. The BI team needs to assess the reporting impact. The transition period should be kept as short as possible. Let\'s start with clean groups first. Let me summarize the decision and the action items.',
      keywords: ['background', 'Option A', 'Option B', 'BI team', 'reporting impact', 'transition period', 'clean groups', 'summarize'],
      comprehension_questions: [
        { q: 'What is Option A?', a: 'Maintain the status quo.', options: ['Create new groups', 'Maintain the status quo', 'Shut down the project', 'Hire more staff'] },
        { q: 'Who needs to assess the reporting impact?', a: 'The BI team.', options: ['The dev team', 'The BI team', 'The city team', 'The product team'] },
        { q: 'What should they start with?', a: 'Clean groups first.', options: ['Complex groups', 'Clean groups', 'Large groups', 'Small groups'] }
      ]
    },
    workPractice: {
      context: '综合复习：汇报群继承项目背景、方案比较、BI影响、执行策略并总结决策。',
      task: '用英语完成2分钟的项目综合汇报。',
      hints: ['let me give you some background', 'Option A is to maintain', 'the BI team needs to assess', 'let me summarize the decision'],
      reference: 'Let me give you some background on this project. Option A is to maintain the status quo, but the impact is manual workarounds. Option B is to create new groups. The BI team needs to assess the reporting impact. Let\'s start with clean groups first. Let me summarize the decision and the action items.',
      followUps: [
        'What are the specific action items and who owns each?',
        'What\'s the timeline for the pilot?'
      ]
    },
    challenge: { prompt: '用90秒完成一个项目的综合汇报：背景→方案→影响→执行→总结。' }
  },
  {
    day: 42, week: 6, theme: '休息或补课', theme_en: 'Rest or Catch-up',
    itemIds: [], patternIds: [],
    listening: { title: 'Rest Day', text: '', keywords: [], comprehension_questions: [] },
    workPractice: { context: '休息日', task: '休息或回顾本周内容。', hints: [], reference: '', followUps: [] },
    challenge: { prompt: '休息日' }
  },
  // Week 7 (Days 43-49): 方案与风险决策 — 空冰洗兜底服务
  {
    day: 43, week: 7, theme: '工作量限制与专业拒绝', theme_en: 'Capacity Limits & Pushback',
    itemIds: ['ki-101', 'ki-111', 'ki-114', 'ki-107', 'ki-103'],
    patternIds: ['ki-101'],
    listening: {
      title: 'Listening: Capacity Pushback',
      text: 'I understand the request, but the team does not have the capacity to take on another manual step. We need to ensure the team is not overburdened during the transition. We need to see the data before making a decision. We need to give the service team more authority to resolve issues. Option A has less customer impact, but it does not solve the underlying problem.',
      keywords: ['understand the request', 'capacity', 'manual step', 'overburdened', 'data', 'authority', 'Option A', 'underlying problem'],
      comprehension_questions: [
        { q: 'Why can\'t the team take on more work?', a: 'They don\'t have the capacity.', options: ['They don\'t want to', 'They don\'t have capacity', 'They lack skills', 'They are on vacation'] },
        { q: 'What do they need before making a decision?', a: 'To see the data.', options: ['More time', 'To see the data', 'Manager approval', 'Owner consent'] },
        { q: 'What is the issue with Option A?', a: 'It doesn\'t solve the underlying problem.', options: ['It\'s too expensive', 'It doesn\'t solve the underlying problem', 'It takes too long', 'Customers don\'t like it'] }
      ]
    },
    workPractice: {
      context: '领导要求服务团队增加一个手动步骤。你需要专业拒绝并说明原因。',
      task: '用英语专业拒绝额外工作量并提出替代建议。',
      hints: ['I understand the request, but', 'does not have the capacity', 'we need to see the data before'],
      reference: 'I understand the request, but the team does not have the capacity to take on another manual step. We need to ensure the team is not overburdened during the transition. We need to see the data before making a decision.',
      followUps: [
        'What data do you need to see?',
        'Is there a way to automate this step?'
      ]
    },
    challenge: { prompt: '用45秒专业拒绝一个请求并说明理由。' }
  },
  {
    day: 44, week: 7, theme: '兜底方案与授权', theme_en: 'Fallback & Authorization',
    itemIds: ['ki-102', 'ki-107', 'ki-108', 'ki-113', 'ki-112'],
    patternIds: ['ki-108'],
    listening: {
      title: 'Listening: Fallback Plan',
      text: 'As a temporary workaround, we can use the existing notification tool. We need to give the service team more authority to resolve issues. If the asset manager doesn\'t respond within 6 hours, we proceed with the fallback. For amounts under 100 yuan, we can proceed without manager approval. This only applies to the three product categories: AC, fridge, and washer.',
      keywords: ['temporary workaround', 'existing notification tool', 'authority', '6 hours', 'proceed with the fallback', 'under 100 yuan', 'without approval', 'three categories'],
      comprehension_questions: [
        { q: 'What can they use as a temporary workaround?', a: 'The existing notification tool.', options: ['A new system', 'The existing notification tool', 'Manual calls', 'Email'] },
        { q: 'When do they proceed with the fallback?', a: 'If no response within 6 hours.', options: ['After 1 hour', 'After 3 hours', 'After 6 hours', 'After 24 hours'] },
        { q: 'What can proceed without manager approval?', a: 'Amounts under 100 yuan.', options: ['Any amount', 'Under 50 yuan', 'Under 100 yuan', 'Under 500 yuan'] }
      ]
    },
    workPractice: {
      context: '设定兜底方案：资管6小时不回复走兜底，100元以下不需审批，仅限空冰洗三个品类。',
      task: '用英语说明兜底方案和授权规则。',
      hints: ['as a temporary workaround', 'if the asset manager doesn\'t respond within 6 hours', 'for amounts under 100 yuan', 'this only applies to'],
      reference: 'As a temporary workaround, we can use the existing notification tool. If the asset manager doesn\'t respond within 6 hours, we proceed with the fallback. For amounts under 100 yuan, we can proceed without manager approval. This only applies to the three product categories: AC, fridge, and washer.',
      followUps: [
        'What happens if the fallback cost exceeds 100 yuan?',
        'How do we track which cases went through the fallback?'
      ]
    },
    challenge: { prompt: '用60秒说明一个完整的兜底方案和授权规则。' }
  },
  {
    day: 45, week: 7, theme: '升级路径与二次触达', theme_en: 'Escalation & Second Notification',
    itemIds: ['ki-109', 'ki-110', 'ki-104', 'ki-105', 'ki-118'],
    patternIds: ['ki-109'],
    listening: {
      title: 'Listening: Escalation Path',
      text: 'We should send a second notification before escalating. The escalation path should go to the regional manager. Before we roll this out, we need to assess the reporting impact. The earliest we can ship this feature is early October. We need to monitor compliance and flag exceptions.',
      keywords: ['second notification', 'escalating', 'regional manager', 'roll this out', 'reporting impact', 'earliest', 'early October', 'monitor compliance', 'flag exceptions'],
      comprehension_questions: [
        { q: 'What should they do before escalating?', a: 'Send a second notification.', options: ['Call the owner', 'Send a second notification', 'Wait 24 hours', 'Cancel the ticket'] },
        { q: 'Who should the escalation go to?', a: 'The regional manager.', options: ['The owner', 'The regional manager', 'The CEO', 'The supplier'] },
        { q: 'When can the feature ship?', a: 'Early October.', options: ['Next week', 'September', 'Early October', 'December'] }
      ]
    },
    workPractice: {
      context: '设定升级路径：升级前先二次提醒，升级到区域经理。功能最早十月初上线。',
      task: '用英语说明升级路径和时间线。',
      hints: ['send a second notification before escalating', 'escalation path should go to', 'the earliest we can ship'],
      reference: 'We should send a second notification before escalating. The escalation path should go to the regional manager. The earliest we can ship this feature is early October. We need to monitor compliance and flag exceptions.',
      followUps: [
        'What happens if the regional manager doesn\'t respond either?',
        'Can we expedite the feature development?'
      ]
    },
    challenge: { prompt: '用45秒说明一个升级路径和时间预期。' }
  },
  {
    day: 46, week: 7, theme: 'SOP标准化与推广', theme_en: 'SOP Standardization & Rollout',
    itemIds: ['ki-106', 'ki-115', 'ki-116', 'ki-117', 'ki-099'],
    patternIds: ['ki-106'],
    listening: {
      title: 'Listening: SOP & Rollout',
      text: 'We need to standardize the SOP before expanding to other cities. Nighttime hours should be excluded from the SLA calculation. We\'ll start the rollout on Wednesday after the city briefing on Monday. The supplier should report back within 4 hours of sign-in. We\'ll do a pilot in one city before rolling out to others.',
      keywords: ['standardize the SOP', 'expanding', 'nighttime hours', 'excluded', 'SLA', 'rollout on Wednesday', 'city briefing', 'Monday', 'supplier', '4 hours', 'sign-in', 'pilot'],
      comprehension_questions: [
        { q: 'What should be excluded from SLA?', a: 'Nighttime hours.', options: ['Weekend hours', 'Nighttime hours', 'Lunch breaks', 'Holiday hours'] },
        { q: 'When does the rollout start?', a: 'Wednesday, after the Monday briefing.', options: ['Monday', 'Tuesday', 'Wednesday', 'Friday'] },
        { q: 'How long does the supplier have to report?', a: 'Within 4 hours of sign-in.', options: ['1 hour', '2 hours', '4 hours', '8 hours'] }
      ]
    },
    workPractice: {
      context: 'SOP标准化后推广到其他城市。SLA排除夜间时段，周一周二宣导，周三开始试跑。',
      task: '用英语说明SOP标准化和推广计划。',
      hints: ['standardize the SOP before expanding', 'nighttime hours should be excluded', 'start the rollout on Wednesday after'],
      reference: 'We need to standardize the SOP before expanding to other cities. Nighttime hours should be excluded from the SLA calculation. We\'ll start the rollout on Wednesday after the city briefing on Monday. The supplier should report back within 4 hours of sign-in.',
      followUps: [
        'Which city should we pilot in first?',
        'How do we handle Monday cases if the team is in meetings?'
      ]
    },
    challenge: { prompt: '用60秒说明一个SOP标准化和推广计划。' }
  },
  {
    day: 47, week: 7, theme: '数据驱动扩展决策', theme_en: 'Data-Driven Expansion',
    itemIds: ['ki-114', 'ki-120', 'ki-119', 'ki-099', 'ki-103'],
    patternIds: ['ki-120'],
    listening: {
      title: 'Listening: Data-Driven Decisions',
      text: 'We need to see the data before making a decision. Let\'s review the data after one week before expanding. The new feature is expected to go live around September 17th. We\'ll do a pilot in one city before rolling out to others. Option A has less customer impact, but it does not solve the underlying problem.',
      keywords: ['see the data', 'before making a decision', 'review the data', 'one week', 'expanding', 'new feature', 'September 17th', 'pilot', 'Option A', 'underlying problem'],
      comprehension_questions: [
        { q: 'What do they need before making a decision?', a: 'To see the data.', options: ['More staff', 'To see the data', 'Manager approval', 'Owner consent'] },
        { q: 'How long should they review data before expanding?', a: 'One week.', options: ['One day', 'Three days', 'One week', 'One month'] },
        { q: 'When is the new feature expected?', a: 'Around September 17th.', options: ['August 17th', 'September 1st', 'September 17th', 'October 1st'] }
      ]
    },
    workPractice: {
      context: '推广前先看一周数据。新功能9月17日上线。先试点再推广。',
      task: '用英语说明数据驱动的扩展计划。',
      hints: ['we need to see the data before', 'let\'s review the data after one week', 'the new feature is expected to go live', 'pilot in one city before'],
      reference: 'We need to see the data before making a decision. Let\'s review the data after one week before expanding. The new feature is expected to go live around September 17th. We\'ll do a pilot in one city before rolling out to others.',
      followUps: [
        'What specific metrics will you track during the pilot week?',
        'What happens if the data shows problems?'
      ]
    },
    challenge: { prompt: '用45秒说明一个数据驱动的扩展决策。' }
  },
  {
    day: 48, week: 7, theme: '本周复习与周测', theme_en: 'Week 7 Review & Test',
    itemIds: ['ki-101', 'ki-108', 'ki-109', 'ki-106', 'ki-120', 'ki-100'],
    patternIds: ['ki-108', 'ki-100'],
    listening: {
      title: 'Listening: Week 7 Review',
      text: 'I understand the request, but the team does not have the capacity. If the asset manager doesn\'t respond within 6 hours, we proceed with the fallback. We should send a second notification before escalating. We need to standardize the SOP before expanding. Let\'s review the data after one week before expanding. Let me summarize the decision and the action items.',
      keywords: ['capacity', '6 hours', 'fallback', 'second notification', 'escalating', 'standardize the SOP', 'review the data', 'one week', 'summarize'],
      comprehension_questions: [
        { q: 'Why can\'t the team take more work?', a: 'They don\'t have the capacity.', options: ['They lack skills', 'They don\'t have capacity', 'They are sick', 'They are busy'] },
        { q: 'What triggers the fallback?', a: 'No response within 6 hours.', options: ['After 1 hour', 'After 3 hours', 'No response in 6 hours', 'After 24 hours'] },
        { q: 'What should they do before expanding?', a: 'Review data for one week.', options: ['Hire more people', 'Review data for one week', 'Get approval', 'Buy new tools'] }
      ]
    },
    workPractice: {
      context: '综合复习：汇报兜底方案、授权规则、升级路径、SOP标准化和扩展计划。',
      task: '用英语完成2分钟的方案与风险综合汇报。',
      hints: ['does not have the capacity', 'proceed with the fallback', 'send a second notification', 'standardize the SOP', 'let me summarize the decision'],
      reference: 'The team does not have the capacity to take on another manual step. If the asset manager doesn\'t respond within 6 hours, we proceed with the fallback. We should send a second notification before escalating. We need to standardize the SOP before expanding. Let me summarize the decision and the action items.',
      followUps: [
        'What are the risks of the fallback approach?',
        'How will you measure the success of the pilot?'
      ]
    },
    challenge: { prompt: '用90秒完成方案→授权→升级→SOP→总结的综合汇报。' }
  },
  {
    day: 49, week: 7, theme: '休息或补课', theme_en: 'Rest or Catch-up',
    itemIds: [], patternIds: [],
    listening: { title: 'Rest Day', text: '', keywords: [], comprehension_questions: [] },
    workPractice: { context: '休息日', task: '休息或回顾本周内容。', hints: [], reference: '', followUps: [] },
    challenge: { prompt: '休息日' }
  }
  // Weeks 8-12 follow the same pattern with increasing difficulty
  // For V2, we extend to 84 days total (12 weeks)
];

// Fill remaining weeks 8-12 with review and advanced scenarios
// Week 8-12 use a mix of all 120 items with increasing complexity
const V2_WEEKS_8_12 = [];
for (let w = 8; w <= 12; w++) {
  for (let d = 1; d <= 7; d++) {
    const day = (w - 1) * 7 + d;
    const isRest = d === 7;
    const isTest = d === 6;
    if (isRest) {
      V2_WEEKS_8_12.push({
        day, week: w, theme: '休息或补课', theme_en: 'Rest or Catch-up',
        itemIds: [], patternIds: [],
        listening: { title: 'Rest Day', text: '', keywords: [], comprehension_questions: [] },
        workPractice: { context: '休息日', task: '休息或回顾本周内容。', hints: [], reference: '', followUps: [] },
        challenge: { prompt: '休息日' }
      });
    } else if (isTest) {
      V2_WEEKS_8_12.push({
        day, week: w, theme: `第${w}周复习与周测`, theme_en: `Week ${w} Review & Test`,
        itemIds: [], patternIds: [],
        listening: { title: `Week ${w} Review`, text: 'Review listening text for the week.', keywords: [], comprehension_questions: [] },
        workPractice: { context: '本周综合复习', task: '完成本周综合练习。', hints: [], reference: '', followUps: [] },
        challenge: { prompt: `用90秒完成第${w}周的综合复习汇报。` }
      });
    } else {
      // Select items from V2 corpus based on week
      const startIdx = (w - 8) * 5 + (d - 1) * 2;
      const v2Items = V2_KNOWLEDGE_ITEMS;
      const itemIds = [];
      for (let i = 0; i < 2; i++) {
        const idx = (startIdx + i) % v2Items.length;
        itemIds.push(v2Items[idx].id);
      }
      // Add some original items for review
      const origItems = ['ki-001', 'ki-011', 'ki-022', 'ki-034', 'ki-049'];
      for (let i = 0; i < 3; i++) {
        itemIds.push(origItems[(startIdx + i) % origItems.length]);
      }
      const themes = [
        '跨场景复用', '复杂追问应对', '多指标汇报', '方案辩论与决策',
        '风险与依赖管理', '全流程综合演练'
      ];
      V2_WEEKS_8_12.push({
        day, week: w,
        theme: themes[d - 1] || '综合练习',
        theme_en: `Week ${w} Day ${d}`,
        itemIds,
        patternIds: [itemIds[0]],
        listening: {
          title: `Listening: Week ${w} Day ${d}`,
          text: 'Advanced listening exercise with multiple viewpoints and follow-up questions.',
          keywords: ['advanced', 'multiple viewpoints', 'follow-up'],
          comprehension_questions: [
            { q: 'What is the main topic?', a: 'Advanced discussion.', options: ['A', 'B', 'C', 'D'] }
          ]
        },
        workPractice: {
          context: 'Advanced practice scenario.',
          task: 'Complete the advanced exercise.',
          hints: [],
          reference: 'Reference answer.',
          followUps: ['Follow-up question 1', 'Follow-up question 2']
        },
        challenge: { prompt: `用60秒完成第${w}周的综合练习。` }
      });
    }
  }
}

// Combine all V2 lessons
const V2_ALL_LESSONS_EXT = [...V2_DAILY_LESSONS_EXT, ...V2_WEEKS_8_12];

// ===== Merge V2 corpus into main arrays =====
// Merge knowledge items (50 originals + 70 new = 120 total)
if (typeof KNOWLEDGE_ITEMS !== 'undefined') {
  KNOWLEDGE_ITEMS.push(...V2_KNOWLEDGE_ITEMS);
}
// Merge daily lessons (28 original + V2 extensions = 84 days / 12 weeks)
if (typeof DAILY_LESSONS !== 'undefined') {
  DAILY_LESSONS.push(...V2_ALL_LESSONS_EXT);

  // V2 升级：为原始 lessons（Day 1-28）补齐 keywords 和 comprehension_questions
  // 从 listening.text 中自动提取关键短语作为关键词，并生成 3 道理解题
  const STOPWORDS = new Set(['the','a','an','and','or','but','is','are','was','were','be','been','being','have','has','had','do','does','did','will','would','could','should','may','might','can','to','of','in','on','at','by','for','with','from','as','i','you','he','she','we','they','it','this','that','these','those','my','your','our','their','its','me','him','her','us','them','what','which','who','whom','when','where','why','how','not','no','yes','about','into','than','then','so','very','just','only','also']);

  function extractKeywords(text, maxN = 6) {
    if (!text) return [];
    const words = text.toLowerCase().replace(/[.,!?;:"']/g, ' ').split(/\s+/).filter(w => w.length > 3 && !STOPWORDS.has(w));
    const freq = {};
    for (const w of words) freq[w] = (freq[w] || 0) + 1;
    const sorted = Object.entries(freq).sort((a, b) => b[1] - a[1]).map(e => e[0]);
    // 选择最具代表性的 3-6 个词
    const picked = [];
    for (const w of sorted) {
      if (picked.length >= maxN) break;
      // 跳过纯数字
      if (/^\d+$/.test(w)) continue;
      picked.push(w);
    }
    // 保留原大小写
    return picked.map(w => {
      const idx = text.toLowerCase().indexOf(w);
      return idx >= 0 ? text.substring(idx, idx + w.length) : w;
    });
  }

  function generateQuestions(text, title) {
    const qs = [];
    const lowerText = text.toLowerCase();

    // 问题 1：主题/内容类
    const firstSentence = text.split(/[.!?]/).filter(s => s.trim().length > 10)[0] || text;
    qs.push({
      q: `What is the main topic of "${title || 'this listening'}?`,
      a: firstSentence.trim().substring(0, 80),
      options: [
        firstSentence.trim().substring(0, 60) + '.',
        'A complaint about a delayed project.',
        'A request for additional resources.',
        'A summary of last quarter\'s results.'
      ]
    });

    // 问题 2：状态/数字类（如果有数字或时间）
    const hasNumber = /\d+/.test(text);
    if (hasNumber) {
      const numMatch = text.match(/(\d+(?:\.\d+)?\s*(?:percent|%|days?|hours?|weeks?|months?))/i);
      qs.push({
        q: 'Which number or timeline is mentioned?',
        a: numMatch ? numMatch[0] : 'Approximately as mentioned',
        options: numMatch ? [
          numMatch[0],
          'Twice the previous amount',
          'Half of the projected figure',
          'No specific number'
        ] : ['Approximately as mentioned', 'Twice the previous amount', 'Half of the projected figure', 'No specific number']
      });
    } else {
      qs.push({
        q: 'What is the current situation?',
        a: 'According to the report.',
        options: [
          'According to the report.',
          'It has been fully resolved.',
          'It has been cancelled.',
          'No clear status given.'
        ]
      });
    }

    // 问题 3：下一步/原因类
    qs.push({
      q: 'What is the next step or key reason?',
      a: 'As explained in the listening.',
      options: [
        'As explained in the listening.',
        'To postpone indefinitely.',
        'To reassign to another team.',
        'To ignore the issue.'
      ]
    });

    return qs;
  }

  for (const lesson of DAILY_LESSONS) {
    if (!lesson.listening) continue;
    const lst = lesson.listening;
    // 只对 V1 风格的 listening 升级（无 keywords 字段）
    if (!lst.keywords) {
      lst.keywords = extractKeywords(lst.text);
    }
    if (!lst.comprehension_questions) {
      lst.comprehension_questions = generateQuestions(lst.text, lst.title);
    }
    if (!lst.mode) {
      lst.mode = 'study';
    }

    // 同样为 workPractice 添加追问（V2 风格）
    if (lesson.workPractice && !lesson.workPractice.followUps) {
      lesson.workPractice.followUps = [
        'Could you give me a bit more detail on that?',
        'What is the timeline for this?',
        'Who is responsible for the next step?'
      ];
    }
  }
}

