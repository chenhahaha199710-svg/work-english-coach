// ===== Spaced Review Algorithm =====
// 独立、可测试的复习排程模块

const REVIEW_INTERVALS = [0, 1, 3, 7, 14, 30, 60]; // 天

// 四级掌握模型状态
const MASTERY_STATES = ['New', 'Learning', 'Reviewing', 'Mastered'];

// 四个维度
const MASTERY_DIMENSIONS = ['recognition', 'recall', 'usage', 'transfer'];

// 用户反馈等级
const RATINGS = {
  again: { multiplier: 0, label: '忘记', interval: 0 },
  hard: { multiplier: 0.5, label: '困难', interval: 1 },
  good: { multiplier: 1, label: '掌握', interval: 3 },
  easy: { multiplier: 1.5, label: '轻松', interval: 7 }
};

// ===== 初始化掌握记录 =====
function initMastery(itemId) {
  const record = {
    item_id: itemId,
    recognition_score: 0,
    recall_score: 0,
    usage_score: 0,
    transfer_score: 0,
    recognition_evidence_count: 0,
    recall_evidence_count: 0,
    usage_evidence_count: 0,
    transfer_evidence_count: 0,
    recognition_correct: 0,
    recognition_incorrect: 0,
    recall_correct: 0,
    recall_incorrect: 0,
    usage_correct: 0,
    usage_incorrect: 0,
    transfer_correct: 0,
    transfer_incorrect: 0,
    last_attempt_at: null,
    average_response_time: 0,
    hint_usage_count: 0,
    correct_count: 0,
    incorrect_count: 0,
    mastery_state: 'New',
    review_count: 0,
    interval_days: 0,
    next_review_at: Date.now(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };
  return record;
}

// ===== 更新掌握记录 =====
function updateMastery(record, rating, opts = {}) {
  const { dimension = 'recognition', responseTime = 0, hintUsed = false, answerMode = 'text' } = opts;

  record.review_count++;
  record.last_attempt_at = Date.now();
  record.updated_at = new Date().toISOString();

  // 更新反应时间
  const totalTime = record.average_response_time * (record.review_count - 1) + responseTime;
  record.average_response_time = Math.round(totalTime / record.review_count);

  // 更新提示使用
  if (hintUsed) record.hint_usage_count++;

  // 更新维度分数
  const dimKey = dimension; // recognition / recall / usage / transfer
  const evidenceKey = `${dimKey}_evidence_count`;
  const correctKey = `${dimKey}_correct`;
  const incorrectKey = `${dimKey}_incorrect`;
  const scoreKey = `${dimKey}_score`;

  record[evidenceKey]++;

  const isCorrect = rating === 'good' || rating === 'easy';
  const isAgain = rating === 'again';

  if (isCorrect) {
    record[correctKey]++;
    record.correct_count++;
  } else {
    record[incorrectKey]++;
    record.incorrect_count++;
  }

  // 计算维度分数（0-100）
  // 分数 = 正确率 * 60 + 连续性 * 20 - 提示依赖 * 10 + 速度 * 10 + 证据深度 * 20
  const totalAttempts = record[correctKey] + record[incorrectKey];
  const accuracy = totalAttempts > 0 ? record[correctKey] / totalAttempts : 0;
  const hintPenalty = record.hint_usage_count > 0 ? Math.min(0.15, record.hint_usage_count * 0.03) : 0;
  const speedScore = responseTime > 0 ? Math.max(0, 1 - responseTime / 30000) : 0.5; // 30秒为基准
  const evidenceBonus = Math.min(1, record[evidenceKey] / 5); // 5次证据为满分

  // 不同维度的权重不同
  let dimWeight = 1;
  if (dimKey === 'recall') dimWeight = 1.1;
  if (dimKey === 'usage') dimWeight = 1.2;
  if (dimKey === 'transfer') dimWeight = 1.3;

  const rawScore = (accuracy * 50 + evidenceBonus * 25 + speedScore * 15 - hintPenalty * 15) * dimWeight;
  record[scoreKey] = Math.max(0, Math.min(100, Math.round(rawScore)));

  // 更新整体掌握状态
  record.mastery_state = computeMasteryState(record);

  // 更新间隔
  record.interval_days = computeInterval(record, rating, dimension, hintUsed);
  record.next_review_at = Date.now() + record.interval_days * 86400000;

  return record;
}

// ===== 计算掌握状态 =====
function computeMasteryState(record) {
  const usageScore = record.usage_score || 0;
  const transferScore = record.transfer_score || 0;
  const totalEvidence = (record.recognition_evidence_count || 0) +
                        (record.recall_evidence_count || 0) +
                        (record.usage_evidence_count || 0) +
                        (record.transfer_evidence_count || 0);

  // Mastered 需要 Usage 和 Transfer 多次稳定通过
  if (usageScore >= 70 && transferScore >= 60 &&
      record.usage_evidence_count >= 3 && record.transfer_evidence_count >= 2) {
    return 'Mastered';
  }

  // Reviewing: 有足够的 recognition 和 recall 证据
  if (record.recall_score >= 50 && record.recall_evidence_count >= 2) {
    return 'Reviewing';
  }

  // Learning: 有开始学习
  if (totalEvidence >= 1) {
    return 'Learning';
  }

  return 'New';
}

// ===== 计算复习间隔 =====
function computeInterval(record, rating, dimension, hintUsed) {
  const ratingData = RATINGS[rating];

  // Again: 当天或次日
  if (rating === 'again') return 0;

  // 获取当前间隔索引
  let intervalIdx = 0;
  for (let i = REVIEW_INTERVALS.length - 1; i >= 0; i--) {
    if (record.interval_days >= REVIEW_INTERVALS[i]) { intervalIdx = i; break; }
  }

  // 根据评分调整
  let newIdx;
  if (rating === 'hard') {
    newIdx = Math.max(0, intervalIdx); // 不前进
  } else if (rating === 'good') {
    newIdx = Math.min(REVIEW_INTERVALS.length - 1, intervalIdx + 1);
  } else { // easy
    newIdx = Math.min(REVIEW_INTERVALS.length - 1, intervalIdx + 2);
  }

  let interval = REVIEW_INTERVALS[newIdx];

  // 使用提示后答对：间隔减少
  if (hintUsed && rating !== 'again') {
    interval = Math.max(1, Math.round(interval * 0.5));
  }

  // 主动回忆（recall）比识别（recognition）提升更高
  if (dimension === 'recall' && rating === 'good') {
    interval = Math.round(interval * 1.2);
  }

  // Usage 成功：间隔提升
  if (dimension === 'usage' && (rating === 'good' || rating === 'easy')) {
    interval = Math.round(interval * 1.3);
  }

  // Transfer 成功：最高质量提升
  if (dimension === 'transfer' && (rating === 'good' || rating === 'easy')) {
    interval = Math.round(interval * 1.5);
  }

  // 连续正确：逐步延长
  const recentCorrect = Math.min(5, record.correct_count - record.incorrect_count);
  if (recentCorrect > 2) {
    interval = Math.round(interval * (1 + recentCorrect * 0.05));
  }

  return Math.max(0, interval);
}

// ===== Learning Priority Score =====
function computePriority(item, mastery, opts = {}) {
  const {
    workRelevance = 3,
    frequency = 2,
    reusability = 3,
    communicationValue = 3,
    reviewUrgency = 0,
    errorIntensity = 0,
    currentTime = 25,
    userWeakSkills = []
  } = opts;

  // 权重
  const w = {
    workRelevance: 0.28,
    frequency: 0.14,
    reusability: 0.18,
    communicationValue: 0.18,
    reviewUrgency: 0.12,
    errorIntensity: 0.10
  };

  // 归一化到 0-5
  const wr = Math.min(5, workRelevance);
  const fr = Math.min(5, frequency);
  const ru = Math.min(5, reusability);
  const cv = Math.min(5, communicationValue);

  // 复习紧迫度
  const isDue = mastery && Date.now() >= mastery.next_review_at;
  const overdueDays = isDue && mastery.next_review_at ?
    Math.floor((Date.now() - mastery.next_review_at) / 86400000) : 0;
  const ru_score = Math.min(5, reviewUrgency + (isDue ? 2 : 0) + Math.min(2, overdueDays * 0.5));

  // 错误强度
  const ei_score = Math.min(5, errorIntensity);

  // 掌握度惩罚（已掌握的降低优先级）
  const masteryState = mastery ? mastery.mastery_state : 'New';
  const masteryPenalty = masteryState === 'Mastered' ? 0.3 : masteryState === 'Reviewing' ? 0.7 : 1;

  // 难度适配
  const difficultyFit = item.difficulty && item.difficulty <= 3 ? 1 : 0.8;

  let score = (wr * w.workRelevance + fr * w.frequency + ru * w.reusability +
               cv * w.communicationValue + ru_score * w.reviewUrgency +
               ei_score * w.errorIntensity) * masteryPenalty * difficultyFit;

  // 弱项加成
  if (item.skill_key && userWeakSkills.includes(item.skill_key)) {
    score *= 1.15;
  }

  return Math.round(score * 100) / 100;
}

// ===== 获取今日到期复习 =====
// 只返回已经学过(review_count > 0)且到期的项目
// 新项目(New)不进入复习队列，而是通过 Learn 阶段学习
async function getDueReviewItems() {
  const allSchedule = await dbGetAll(STORES.reviewSchedule);
  const allMastery = await dbGetAll(STORES.masteryRecords);
  const masteryMap = {};
  allMastery.forEach(m => masteryMap[m.item_id] = m);
  const now = Date.now();
  return allSchedule
    .filter(s => {
      const m = masteryMap[s.item_id];
      // 只复习已经学过的（review_count > 0 且非 New 状态）
      if (!m || m.mastery_state === 'New') return false;
      return s.next_review_at <= now;
    })
    .sort((a, b) => a.next_review_at - b.next_review_at);
}

// ===== 获取今日新内容 =====
async function getNewItemsForToday(settings, count) {
  const allItems = await dbGetAll(STORES.knowledgeItems);
  const allMastery = await dbGetAll(STORES.masteryRecords);
  const masteryMap = {};
  allMastery.forEach(m => masteryMap[m.item_id] = m);

  // 过滤：未学习或非Mastered
  const candidates = allItems.filter(item => {
    const m = masteryMap[item.id];
    return !m || m.mastery_state !== 'Mastered';
  });

  // 计算优先级排序
  const scored = candidates.map(item => {
    const m = masteryMap[item.id] || initMastery(item.id);
    const score = computePriority(item, m);
    return { item, mastery: m, score };
  });

  scored.sort((a, b) => b.score - a.score);

  return scored.slice(0, count);
}

// ===== 算法模块导出 =====
window.WEC_Algo = {
  REVIEW_INTERVALS,
  MASTERY_STATES,
  MASTERY_DIMENSIONS,
  RATINGS,
  initMastery,
  updateMastery,
  computeMasteryState,
  computeInterval,
  computePriority,
  getDueReviewItems,
  getNewItemsForToday
};
