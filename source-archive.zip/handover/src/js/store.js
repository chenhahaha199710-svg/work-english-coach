// ===== LocalStorage Settings & App State =====

const SETTINGS_KEY = 'wec_settings';
const STATE_KEY = 'wec_state';

const DEFAULT_SETTINGS = {
  dailyMinutes: 25,
  dailyNewItems: 2,
  dailyPatterns: 2,
  speechRate: 1.0,
  feedbackLang: 'zh',
  aiRole: 'manager',
  weekTestDay: 7,
  studyStartDate: null,
  currentDay: 1,
  streakDays: 0,
  lastStudyDate: null,
  totalStudyMinutes: 0,
  assessmentCompleted: false,
  listeningMode: 'study',
  listeningSlowRate: 0.8
};

const DEFAULT_STATE = {
  currentPage: 'today',
  sessionActive: false,
  sessionStep: 0,
  sessionData: null
};

function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : { ...DEFAULT_SETTINGS };
  } catch { return { ...DEFAULT_SETTINGS }; }
}

function saveSettings(settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function updateSettings(patch) {
  const s = loadSettings();
  Object.assign(s, patch);
  saveSettings(s);
  return s;
}

function loadState() {
  try {
    const raw = localStorage.getItem(STATE_KEY);
    return raw ? { ...DEFAULT_STATE, ...JSON.parse(raw) } : { ...DEFAULT_STATE };
  } catch { return { ...DEFAULT_STATE }; }
}

function saveState(state) {
  localStorage.setItem(STATE_KEY, JSON.stringify(state));
}

function updateState(patch) {
  const s = loadState();
  Object.assign(s, patch);
  saveState(s);
  return s;
}

// ===== Date Helpers =====
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

function daysBetween(date1, date2) {
  const d1 = new Date(date1); d1.setHours(0,0,0,0);
  const d2 = new Date(date2); d2.setHours(0,0,0,0);
  return Math.round((d2 - d1) / 86400000);
}

function getStudyDay(settings) {
  if (!settings.studyStartDate) return 1;
  const start = new Date(settings.studyStartDate);
  start.setHours(0,0,0,0);
  const today = new Date(); today.setHours(0,0,0,0);
  const day = daysBetween(start, today) + 1;
  return Math.max(1, Math.min(day, 168));
}

function getWeek(studyDay) {
  return Math.ceil(studyDay / 7);
}

function getWeekPhase(week) {
  if (week <= 4) return { name: 'English Reactivation', range: 'Week 1-4' };
  if (week <= 8) return { name: 'Core Work Scenarios', range: 'Week 5-8' };
  if (week <= 12) return { name: 'Active Production', range: 'Week 9-12' };
  if (week <= 16) return { name: 'Meeting Communication', range: 'Week 13-16' };
  if (week <= 20) return { name: 'Problem Solving', range: 'Week 17-20' };
  return { name: 'Work Simulation', range: 'Week 21-24' };
}

// ===== Streak Tracking =====
function updateStreak(settings) {
  const today = todayStr();
  if (settings.lastStudyDate === today) return settings;

  if (settings.lastStudyDate) {
    const gap = daysBetween(settings.lastStudyDate, today);
    if (gap === 1) {
      settings.streakDays = (settings.streakDays || 0) + 1;
    } else if (gap > 1) {
      settings.streakDays = 1;
    }
  } else {
    settings.streakDays = 1;
  }
  settings.lastStudyDate = today;
  saveSettings(settings);
  return settings;
}

// ===== UUID =====
function uuid() {
  return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 9);
}
